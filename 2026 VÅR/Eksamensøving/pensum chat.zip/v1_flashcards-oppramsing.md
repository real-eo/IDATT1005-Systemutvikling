# IDATT1005 – Oppramsbare elementer for flashcards

Denne filen samler **prinsipper, faser, dimensjoner, regler, seremonier, nivåer, typer, fordeler/ulemper og andre oppramsbare elementer** fra pensum, formulert så konsist og presist som mulig for automatiske flashcards.

---

## Interaksjonsdesign

### Prosess for interaksjonsdesign
1. Definer krav
2. Design alternativer
3. Lag prototype
4. Evaluer

### De fem dimensjonene i interaksjonsdesign
1. Ord
2. Visuelle representasjoner
3. Fysiske objekter og rom
4. Tid
5. Atferd

### Don Normans prinsipper
1. Synlighet
2. Feedback
3. Begrensninger
4. Avbilding (mapping)
5. Konsistens
6. Tilbydelser / affordances

---

## Prototyping

### Dimensjoner ved prototyping
1. Utseende
2. Innhold
3. Funksjonalitet
4. Interaktivitet
5. Romlig struktur

### Klasser av prototyping
- Horisontal prototype
- Vertikal prototype

### Aspekter ved utvikling av prototyper
- Evolusjonær prototype
- Bruk-og-kast-prototype
- Lavoppløselig prototype
- Høyoppløselig prototype

---

## Evaluering

### Forskjell: testing vs evaluering
- Testing: verifisering – bygger vi produktet riktig?
- Evaluering: validering – bygger vi riktig produkt?

### Evalueringsformer
- Formativ evaluering
- Summativ evaluering

### Evaluering som involverer brukere
- Brukertest
- A/B-test
- Feltstudie
- Opportunistisk evaluering

### Evaluering som ikke involverer brukere
- Heuristisk gjennomgang
- Prediktive modeller

### Evaluering som kan involvere både eksperter og brukere
- Pluralistisk gjennomgang

### Evalueringsmetoder
- Observasjon
- Spørre brukere
- Direkte testing
- Spørre eksperter
- Modellering

### Evalueringsteknikker / hva man kan teste
- Kodevalidering
- Testing i ulike nettlesere og på ulike plattformer
- Testing av fleksibiliteten til et design
- Testing av grad av universell utforming / brukskvalitet
- Testing av feilmeldinger

---

## Brukertesting

### Kjennetegn ved god brukertesting
- Konkret hensikt
- Avgrenset formål
- Realistiske oppgaver
- Observasjon av brukeren

---

## Universell utforming

### Prinsipper for universell utforming
1. Enkel og intuitiv i bruk
2. Forståelig informasjon
3. Toleranse for feil
4. Like muligheter for alle
5. Fleksibel i bruk
6. Lav fysisk anstrengelse
7. Størrelse og plass for tilgang og bruk

### Hva “størrelse og plass for tilgang og bruk” skal muliggjøre
1. Tilgang
2. Rekkevidde
3. Betjening og bruk

### Gode argumenter for universell utforming
- Mer inkluderende
- Enklere å bruke
- Mer mobiltilpasset
- Mer synlig for Google / bedre SEO
- Mer lønnsomt

---

## WCAG

### De fire prinsippene i WCAG
1. Mulig å oppfatte (Perceivable)
2. Mulig å betjene (Operable)
3. Forståelig (Understandable)
4. Robust (Robust)

### Eksempler på krav i WCAG
- Innhold skal være tilgjengelig via tastatur
- Bilder skal ha alternativ tekst
- Video skal ha teksting eller alternativ lyd
- Skjema og formater skal være lette å forstå
- Innhold skal være lett å forstå

---

## UML

### Vanlige UML-modeller / diagramtyper i pensum
- Use case-diagram
- Domenemodell
- Sekvensdiagram
- Aktivitetsdiagram
- Klassediagram
- Pakkediagram
- Tilstandsmaskindiagram

### Elementer i sekvensdiagram
- Deltakere
- Meldinger / funksjonskall
- Levetidslinje
- Aktiveringsboks
- Rammer (f.eks. løkke/alt)

### Elementer i aktivitetsdiagram
- Aksjoner
- Initial node
- Final node
- Decision node
- Fork node
- Join node
- Merge node
- Overganger / piler

### Elementer i klassediagram
- Klasse
- Attributter
- Metoder

### Relasjoner i klassediagram
- Avhengighet (dependency)
- Assosiasjon
- Aggregering
- Komposisjon
- Arv / generalisering
- Realisering

### Hovedelementer i tilstandsmaskindiagram
- Starttilstand
- Sluttilstand
- Tilstander
- Overganger
- Triggere / hendelser

---

## Brukerhistorier

### Standardformat for brukerhistorier
- Som [rolle]
- vil jeg [mål/ønske]
- slik at [nytte/verdi]

---

## Programvarearkitektur

### Hvorfor programvarearkitektur er viktig
- Forstå systemet tidlig
- Redusere kostnader
- Unngå duplisering av ressurser
- Øke kvalitet
- Hjelpe risikostyring
- Støtte kommunikasjon mellom interessenter
- Gi retningslinjer for utviklere

### Kompleksitetshåndtering
- Splitt og hersk
- Lav kobling
- Mer testbar kode
- Mer robust kode
- Enklere delegering av ansvar

---

## Trelagsarkitektur

### De tre lagene
1. Presentasjonslag
2. Forretningslogikklag
3. Data access-lag

### Hovedidé i lagdeling
- Hvert lag har spesifikt ansvar
- Hvert lag yter tjenester til laget over / bruker laget under
- Gir lav kobling

---

## Master-slave pattern

### Hoveddeler
- Master
- Slaver

### Fordeler
- Tydelig oversikt i master
- Slavene kan enhetstestes separat
- Master kan integrasjonstestes mot slavene

---

## Event-bus pattern

### Fire hovedkomponenter
1. Event listener
2. Event source
3. Channel
4. Event bus

---

## MVC

### Tre deler i MVC
1. Model
2. View
3. Controller

### Fordeler
- Høyere kohesjon
- Gjenbrukbarhet
- Skiller ansvar

---

## Mikrotjenester

### Mikrotjenester er basert på
- Single Responsibility Principle

### Kjennetegn
- Selvstendige tjenester
- Én hovedoppgave per tjeneste
- Egen data
- Eget kjøremiljø

### Fordeler
- Skalerbart
- Modulært
- Fleksibel teknologibruk
- Høy tilgjengelighet / feil isoleres
- Støtter kontinuerlig levering (CI/CD)
- Passer DevOps

### Ulemper
- Kompleks debugging
- Kompleks logging på tvers av tjenester
- Krever automatisering
- Vanskelig å teste distribuerte systemer
- Datainkonsistens kan oppstå
- Økt ressursforbruk

---

## Monolittarkitektur

### Fordeler
- God gjennomstrømning / lite overhead
- Enklere å teste og debugge i starten

### Ulemper
- Vanskeligere å vedlikeholde ved vekst
- Lite skalerbar
- Lite utvidbar sammenlignet med modulære løsninger
- Tett koblet
- Feil i én del kan stoppe hele systemet

---

## Plugin-basert arkitektur

### Hoveddeler
- Kjerne-system
- Plugin-moduler / extensions

### Fordeler
- Lav kobling
- Høy isolasjon mellom funksjoner
- Fleksibelt
- Utvidbart

### Ulemper
- Endringer i kjernen kan ødelegge plugins
- Mange plugins kan redusere ytelsen
- Kompleks testing av hele systemet

### Eksempler
- Chrome Web Store
- IntelliJ
- VS Code
- Eclipse

---

## Deployment-arkitekturer

### Tradisjonell deployment
- Applikasjoner kjøres direkte på fysiske servere

### Utfordringer ved tradisjonell deployment
- Ressursallokering kan bli ineffektiv
- Én applikasjon kan ta for mye kapasitet

### Virtualisering (VMs)
- Flere virtuelle maskiner på én fysisk server
- Hver VM har eget operativsystem

### Ulempe ved virtualisering
- Ressurser reserveres selv om de ikke brukes

### Container-deployment
- Containere deler OS, men er isolerte
- Lettere enn virtuelle maskiner

### Nøkkelteknologier i container-deployment
- Docker
- Kubernetes

### Fordeler med containere
- Enkel distribusjon
- Konsistent kjøremiljø
- Løst koblet
- Distribuert
- Elastisk

---

## Systemutviklingsmetodikk

### Før smidige metoder
- Vannfallsmodellen
- Unified Process (UP)

### Grunnleggende prinsipper i smidig metode
1. Problem based
2. Collaborative
3. Iterativ
4. Adaptiv

### Agile Manifesto – fire hovedverdier
1. Individer og interaksjoner fremfor prosesser og verktøy
2. Fungerende programvare fremfor omfattende dokumentasjon
3. Kundesamarbeid fremfor kontraktsforhandlinger
4. Reagere på endring fremfor å følge en plan

---

## Extreme Programming (XP)

### Kjennetegn
- Lite dokumentasjon
- Lite modellering
- Tett feedback-loop
- Kort iterasjonstid

### Antall faste regler i XP
- 29 regler

### Eksempler på XP-regler
- Parprogrammering
- Skriv enhetstester før kode
- Integrer én liten endring av gangen
- Enkel og tydelig kode
- Hyppig refaktorering
- Korte feedback-looper
- Hyppige tester
- Hyppige leveranser

### Fem sentrale verdier i XP
1. Communication
2. Simplicity
3. Feedback
4. Courage
5. Respect

---

## Test-Driven Development (TDD)

### Grunnidé
1. Skriv test først
2. Kjør testen og se at den feiler
3. Skriv kode som får testen til å bestå
4. Refaktorer

### Fokus i TDD
- Primært enhetstesting
- Noen ganger integrasjonstesting
- Sjelden systemtesting

### Fordeler
- Bedre kodekvalitet
- Høyere testdekning
- Rask tilbakemelding
- Økt tillit
- Testene fungerer som dokumentasjon

### Ulemper
- Lærekurve
- Tidsbruk til å skrive tester
- Vedlikehold av tester

---

## Behavior-Driven Development (BDD)

### Hovedidé
- Kobler forretningsmål og teknologi
- Beskriver systematferd fra brukerens perspektiv
- Bruker naturlig språk

### Given-When-Then-formatet
1. Given (Gitt) – starttilstand / kontekst
2. When (Når) – handling / hendelse
3. Then (Så) – forventet resultat

### Nøkkelelementer i Gherkin
- Feature
- Scenario
- Given
- When
- Then
- And

### Hva BDD bidrar til
- Tydeligere akseptkriterier
- Felles forståelse mellom forretning og utvikling
- Testbar spesifikasjon
- Høyere fokus på brukerens perspektiv

---

## Scrum

### Hva Scrum er
- Tidsboksbasert smidig rammeverk

### Fokus i Scrum
- Kryssfunksjonelle team
- Sprinter
- Inkrementell fremgang

### Scrum-seremonier
1. Sprint planning
2. Daily standup / daily scrum
3. Sprint review
4. Retrospektiv

### Typiske artefakter / objekter i Scrum
- Product backlog
- Sprint backlog
- Product backlog items (PBI)
- Scrum board

---

## Lean

### Lean-prinsipper
1. Eliminate waste
2. Build quality in
3. Create knowledge
4. Defer commitment
5. Deliver fast
6. Respect people
7. Optimize the whole

---

## Kanban

### Kjennetegn
- Flytbasert
- Kontinuerlig levering
- Ingen faste iterasjoner
- Visuell styring

### Viktige elementer
- Kanban-board
- Begrensning av arbeid i prosess (WIP)
- Fokus på flaskehalser

### Formål med WIP-begrensning
- Synliggjøre flaskehalser
- Forbedre flyt
- Hjelpe teammedlemmer å bidra der det stopper opp

---

## Domain-Driven Design (DDD)

### Kjennetegn
- Høyt fokus på domenet
- Koden skal gjenspeile virkeligheten
- Egnet for skalering og endring
- Fokus på det viktigste i domenet

---

## DevOps

### Hva DevOps kombinerer
- Utvikling (Dev)
- Drift (Ops)

### DevOps skal sikre
- Kontinuerlig integrasjon
- Kontinuerlig levering / deploy
- Tettere samarbeid mellom utvikling og drift

### CI (Continuous Integration)
- Hyppig integrasjon til felles gren
- Automatisk bygging
- Automatisk testing

### CD (Continuous Delivery / Deployment)
- Automatisk levering / deploy av kodeendringer

### DevOps-verktøy i pensum
- GitLab / GitHub
- Jira / Confluence
- Maven
- Gradle
- Jenkins
- JUnit
- Selenium
- Kubernetes
- Helm
- Docker
- Kibana
- Grafana

---

## REST

### REST-prinsipper i pensum
- Klient-tjener
- Ressurser identifiseres via URI-er
- Ressurser manipuleres via HTTP-metoder

### HTTP-metoder i pensum
- GET
- POST
- PUT
- DELETE

---

## Testing

### Hvorfor teste
- Sikre riktig respons ved input/interaksjon
- Finne bugs
- Verifisere ytelse under edge cases
- Vurdere brukervennlighet
- Kontrollere at krav er oppfylt
- Kontrollere at systemet kan installeres i riktig miljø
- Kontrollere at systemet tåler endringer

### Testing principles
1. Testing shows the presence of defects
2. Exhaustive testing is impossible
3. Early testing
4. Defects clustering
5. Pesticide paradox
6. Testing is context dependent
7. Absence of error fallacy

### Tradisjonell testing
- Utvikling og testing skjer separat
- QA-team kvalitetssikrer etter utvikling

### Ulempe ved tradisjonell testing
- Mye tid går til kommunikasjon og overlevering

### Smidig testing
- Utviklere tester egen kode kontinuerlig
- Små inkrementer
- Automatiserte tester brukes mye

### Fordeler ved smidig testing
- Raskere feedback
- Tettere kobling mellom utvikling og kvalitet
- QA kan fokusere på viktige scenarioer

---

## Automatiserte tester

### Når de ofte kjøres
- Ved opprettelse av pull request
- I CI-pipelines
- Ved nye kodeendringer

### Kjennetegn
- Enhetstester og integrasjonstester kjøres automatisk
- Resultater rapporteres raskt

### Fordeler
- Rask feedback
- Høy hastighet
- Kontinuerlig kontroll
- Forutsigbar kvalitet
- Kostnadsbesparende over tid

### Ulemper / utfordringer
- Høy oppstarts- og vedlikeholdskostnad
- Krever riktig fokus og god testdesign

---

## Egne test-/staging-miljøer

### Kjennetegn
- Testmiljø speiler produksjonsmiljø
- Hele applikasjonen kan testes før release

### Fordeler
- Mer realistisk testing
- QA kan teste hele applikasjonen
- Infrastructure as Code gjør oppsett enklere

---

## CI og små endringer

### Fordeler
- Mindre diff mellom gammel og ny versjon
- Enklere isolering av feil
- Enklere sporing av endringer
- Lavere sannsynlighet for feil
- Enklere rollback

---

## Prioritering av testing

### Viktige prinsipper
- Finn riktig nivå på testdekning basert på risiko
- Prioriter tester som gir størst verdi
- Prioriter tester som reduserer mest usikkerhet

---

## Risk poker

### Hva man vurderer
- Risiko
- Konsekvens
- Risikofaktorer

### Fordeler
- Hele teamet deltar
- Bedre treffsikkerhet
- Felles forståelse av risiko

---

## Testdata

### Egenskaper ved gode testdata
- Samme data hver gang
- Deterministisk prosess
- Forutsigbart testmiljø

### Fordeler
- Enklere å isolere feil
- Mer presise testresultater
- Bedre analyse av testutfall

---

## Mocking

### Hva mocking brukes til
- Erstatte ekte og komplekse avhengigheter
- Isolere klasser / moduler i test

### Typiske avhengigheter som kan mocket
- Database
- Eksternt API
- Betalingstjeneste

### Hva som gjør mocking ideelt
- Deterministiske svar
- Samme grensesnitt som ekte avhengighet
- Kombineres godt med dependency injection

### Fordeler
- Muliggjør isolert testing
- Gjør automatiserte tester mulige i flere situasjoner
- Gir kontroll over testmiljøet

---

## Testfaser

### Faser i en test
1. Oppsett
2. Gjennomføring
3. Verifisering
4. Opprydding

---

## Enhetstesting

### Kjennetegn
- Tester individuelle klasser / funksjoner
- Fokus på små enheter
- Ofte utviklers ansvar

### Fordeler
- Automatisert
- Repeterbar
- Kjøres i byggeprosessen

### Mål
- Finne feil tidlig
- Stoppe feil før integrasjon med andre deler

---

## Integrasjonstesting

### Kjennetegn
- Tester samspill mellom komponenter
- Bygger på at delene allerede er testet individuelt

### Mål
- Oppdage feil i grensesnitt og samhandling

### Valg
- Kan automatiseres
- Bør automatiseres der det er hensiktsmessig

---

## Systemtesting

### Kjennetegn
- Tester hele systemet
- Sjekker at alle deler fungerer sammen

### Fordeler
- Finner feil mellom deler av systemet
- Gir trygghet før levering

### Mål
- Sjekke at systemet oppfyller krav
- Finne feil før bruk

### Valg
- Kan utføres med verktøy som Selenium
- Kan være vanskelig å gjøre helt repeterbar

---

## Akseptansetesting

### Kjennetegn
- Type systemtesting
- Utføres for å verifisere at krav er oppfylt

### Viktig i BDD
- Bygger på user stories
- Kan utvikles sammen med kunden

### Kan være
- Manuell
- Automatisert

---

## Regresjonstesting

### Hva det er
- Tester at endringer ikke ødelegger eksisterende funksjonalitet

### Når det skjer
- Før og etter endringer
- Kontinuerlig i CI ved innsjekk av kode

### Hvilke nivåer det kan finnes på
- Enhetstestnivå
- Integrasjonsnivå
- Akseptansenivå

### Valg
- Egner seg godt for automatisering

---

## Smoke-testing og sanity-testing

### Smoke-testing
- Tester kritisk funksjonalitet
- Rask sjekk av om systemet “i det hele tatt fungerer”

### Sanity-testing
- Tester ny eller endret funksjonalitet
- Rask sjekk av om en spesifikk endring virker fornuftig

### Hvorfor de er nyttige
- Avdekker tidlig om videre testing er hensiktsmessig

---

## Destruktiv testing og utforskende testing

### Destruktiv testing
- Kreativ testing for å få systemet til å feile
- Kan ikke automatiseres
- Krever menneskelig erfaring og kreativitet

### Utforskende testing
- Tester med aktiv læring og utforsking underveis
- Bygger på innsikt i systemet og nye hypoteser

### Forskjell
- Destruktiv testing: fokus på å bryte systemet
- Utforskende testing: bredere utforsking og læring

---

## Usabilitytesting

### Hva det tester
- Brukervennlighet
- GUI
- Om brukeren / kunden er fornøyd

---

## Ytelsestesting

### Hva ytelsestesting undersøker
- Hvor mye last systemet tåler
- Hvor mye plutselig last systemet tåler
- Ytelse over tid
- Lekkasjer / ressursproblemer

### Hvordan ytelse måles
- Antall samtidige brukere
- Transaksjoner per tidsenhet
- Throughput
- Responstid

### Hva flaskehalser er
- Systemets svakeste / tregeste punkt
- Det som begrenser total ytelse

### Vanlige årsaker til flaskehalser
- CPU
- Minne
- Tråder
- Databasetilkobling

### Typer ytelsestester
1. Lasttest
2. Stresstest
3. Spike-test
4. Utholdenhetstest

---

## Black-box og white-box testing

### Black-box testing
- Ingen innsikt i intern kode
- Bygger på krav, spesifikasjoner og forventet oppførsel

### White-box testing
- Full innsikt i intern kode og struktur
- Tester intern logikk og oppbygning

---

## Automatisk vs manuell testing

### Fordeler ved automatiske tester
- Raske
- Nøyaktige
- Repeterbare
- Gode for kjente forventninger

### Typiske automatiserte tester
- Enhetstester
- Regresjonstester
- Mange integrasjonstester
- Mange ytelsestester

### Ulemper ved automatiske tester
- Krever vedlikehold
- Fanger ikke alt
- Dårligere på kreative og uventede problemer

### Fordeler ved manuelle tester
- Kreative
- Fanger ofte naturlige brukerfeil og uventede problemer
- Gode for utforsking og opplevelse

### Typiske manuelle tester
- Utforskende testing
- Destruktiv testing
- Mye usabilitytesting

### Testtyper som kan være både manuelle og automatiske
- Smoke-testing
- Sanity-testing
- Integrasjonstesting
- Systemtesting
- Akseptansetesting
- Ytelsestesting

---

## GDPR

### Grunnleggende prinsipper i GDPR
1. Lovlighet, rimelighet og gjennomsiktighet
2. Formålsbegrensning
3. Dataminimering
4. Riktighet
5. Lagringsbegrensning
6. Integritet og konfidensialitet
7. Ansvarliggjøring

### De registrertes rettigheter
1. Rett til informasjon
2. Rett til innsyn
3. Rett til retting
4. Rett til sletting
5. Rett til begrensning
6. Rett til å protestere
7. Rett til dataportabilitet

### Typiske unntak / begrensninger
- Juridisk forpliktelse
- Offentlig sikkerhet
- Forskning

---

## Profesjonsetikk

### Ingeniørens ansvar omfatter blant annet
- Sosialt ansvar
- Sikkerhet og pålitelighet
- Brukeres velferd
- AI og militær bruk / alvorlige konsekvenser av teknologi

### Eksempler på NITO-prinsipper i pensum
- Vise respekt for kolleger
- Vedkjenne seg faglig ansvar
- Følge anerkjente kvalitetsnormer
- Bidra til åpenhet om teknologiske konsekvenser

### IEEE/ACM Code of Ethics – hovedområder
1. Samfunn
2. Kunde og arbeidsgiver
3. Produkt
4. Vurdering
5. Ledelse
6. Profesjon
7. Kolleger
8. Egen utvikling / livslang læring

### Nøkkelprinsipper i profesjonsetikken
- Ærlighet og integritet
- Respekt for personvern
- Kvalitetsbevissthet
- Ansvar for konsekvenser
- Kontinuerlig vurdering

### Hvorfor profesjonsetikk henger sammen med kvalitet
- Mer robuste systemer
- Færre sikkerhets- og personvernbrudd
- Høyere brukertilfredshet
- Beskytter omdømme
- Reduserer risiko for bias og tillitsbrudd

---

## Prosjektplanlegging

### Visjonsdokument – hva det typisk inneholder
- Formål
- Omfang
- Hensikt
- Målgruppe
- Funksjonelle krav
- Ikke-funksjonelle krav
- Interessenter
- Brukerbehov

### Risikoanalyse – hva den brukes til
- Identifisere risiko
- Prioritere risiko
- Definere tiltak
- Forbedre beslutningsprosesser
- Øke prosjektets robusthet

---