# Copilot Chat Conversation Export: t allmennheten. For eksempel må en

**User:** @real-eo
**Thread URL:** https://github.com/copilot/c/dcf24de5-5331-485d-82de-b3bdaae2a9cc

## @real-eo

her er HELE listen med ALL pensum jeg skal kunne. 

Forklar meg alle sammenhenger- og kryssreferanser fra stoffet. Forklar hvordan de ulike temaene og begrepene brukes i samspill ved å eksemplifisere. Jeg må kunne alt som står på denne .md filen, og kunne anvende informasjonen korrekt. Hjelp meg med å forstå hvordan jeg anvender fagstoffet korrekt. rett også opp i feil/presiser der det er nødvendig. Det er ok å bruke lister, men jeg foretrekker sammenhengede paragrafer ettersom at jeg skal kunne forstå hvordan jeg bruker fagstoffet og skjønne sammenhengene 

## Copilot

Ja — den riktige måten å lære dette på er **ikke** å pugge hvert punkt isolert, men å forstå **hvordan temaene henger sammen i en faktisk systemutviklingsprosess**. Under går jeg derfor gjennom stoffet som ett helhetlig fagkart: fra idé, krav og brukerbehov, via modellering og arkitektur, til utviklingsmetodikk, testing, lovkrav og profesjonsetikk. Samtidig retter og presiserer jeg noen formuleringer i notatene dine.

---

# 1. Det store bildet: hvordan hele pensum henger sammen

Hele faget kan forstås som spørsmålet: **Hvordan utvikler vi programvare som er nyttig, korrekt, brukbar, trygg, testbar, vedlikeholdbar og forsvarlig?**

De forskjellige delene av pensum svarer på ulike deler av dette:

- **MMI / interaksjonsdesign / prototyping / evaluering / brukertesting / universell utforming / WCAG** handler om:  
  **Lager vi riktig løsning for mennesker?**
- **UML / brukerhistorier / domenemodell / use case / sekvens / aktivitet / klasse / tilstand** handler om:  
  **Hvordan beskriver og kommuniserer vi løsningen før og under utvikling?**
- **Programvarearkitektur / arkitekturmønstre / REST / deployment** handler om:  
  **Hvordan bygger vi løsningen teknisk slik at den fungerer og kan utvikles videre?**
- **Systemutviklingsmetodikk / smidig / Scrum / Kanban / XP / TDD / BDD / DDD / DevOps** handler om:  
  **Hvordan organiserer vi arbeidet for å få framgang og kvalitet?**
- **Testing** handler om:  
  **Hvordan verifiserer og validerer vi at systemet virker og oppfyller behovene?**
- **GDPR / profesjonsetikk / lovkrav for universell utforming** handler om:  
  **Hva er vi juridisk og etisk forpliktet til å ta hensyn til?**
- **Prosjektplanlegging / vision / risikoanalyse** handler om:  
  **Hvordan setter vi retning og håndterer usikkerhet?**

Det viktigste er å se at disse **ikke er separate siloer**. De påvirker hverandre hele tiden. Hvis du for eksempel gjør gode brukerundersøkelser, påvirker det brukerhistorier og krav. Kravene påvirker UML-modellene. Modellene påvirker arkitekturvalg. Arkitekturvalg påvirker hva som er lett å teste. Teststrategien påvirker hvilke utviklingsmetoder som passer. Lovkrav og etikk setter grenser for hva som er akseptabelt å lage. Og alt dette må passe inn i prosjektplanlegging og risikostyring.

---

# 2. Fra behov til løsning: kjeden fra bruker til kode

En veldig viktig sammenheng i pensum er denne:

**Brukerbehov → krav → brukerhistorier / use case → modeller → arkitektur / design → implementasjon → testing / evaluering → forbedring**

Dette er egentlig hele systemutvikling i én linje.

Tenk deg at du skal lage en app for timebestilling hos fastlege.

Først må du forstå **brukeren og konteksten**. Dette er MMI og interaksjonsdesign. Hvem er brukerne? Eldre? Unge? Personer med redusert syn? Folk som bruker mobil? Hva prøver de å få gjort raskt og uten feil? Da er fokuset ikke primært teknologi, men **menneskelig måloppnåelse**.

Så oversetter du dette til **krav**. For eksempel: “Brukeren skal kunne bestille time på under 2 minutter”, “løsningen skal fungere med tastatur”, “brukeren skal få tydelig tilbakemelding ved feil”. Disse kravene er både funksjonelle og ikke-funksjonelle.

Deretter kan du uttrykke behovene som **brukerhistorier**:  
“Som pasient vil jeg se ledige timer slik at jeg kan bestille en time som passer meg.”  
Eller som **use cases**: “Bestille time”, “Logge inn”, “Avbestille time”.

Så modellerer du systemet. I en **domenemodell** kan du vise begreper som Pasient, Lege, Timeavtale, Kalender. I et **sekvensdiagram** viser du hva som skjer når pasienten bestiller time. I et **klassediagram** viser du hvilke klasser systemet kan bestå av. I et **aktivitetsdiagram** viser du prosessflyten. I et **tilstandsmaskindiagram** kan du vise hvordan en timeavtale går fra “ledig” til “reservert” til “bekreftet” til “avbestilt”.

Deretter velger du **arkitektur**. Kanskje klient-tjener eller trelagsarkitektur. Kanskje REST-API mellom frontend og backend. Kanskje monolitt hvis systemet er lite, eller mikrotjenester hvis systemet er stort og komplekst.

Så implementerer du. Men hvordan du implementerer påvirkes av metodikk: Scrum, Kanban, XP, TDD, BDD, DevOps.

Til slutt tester og evaluerer du. Merk at her møtes to store deler av pensum:
- **Testing**: fungerer systemet teknisk korrekt?
- **Evaluering / brukertesting**: fungerer systemet godt for brukeren?

Og basert på resultatene går du tilbake og forbedrer systemet. Derfor er interaksjonsdesign og smidig utvikling begge **iterative**.

---

# 3. MMI, interaksjonsdesign, prototyping og evaluering: sammenhengen

Disse temaene henger ekstremt tett sammen. De beskriver egentlig én sammenhengende prosess:

**Forstå bruker → lag designforslag → bygg prototype → evaluer → forbedre**

Interaksjonsdesign handler om å utforme hvordan brukeren samhandler med et system. Målet er ikke bare at systemet “fungerer”, men at det oppleves som **intuitivt, effektivt, forståelig og tilfredsstillende**. Derfor kan vi si at interaksjonsdesign er en bro mellom teknologi og psykologi: systemet skal være teknisk mulig, men også menneskelig brukbart.

Prototyping er et verktøy i denne prosessen. En prototype er en tidlig representasjon av løsningen som brukes til å utforske ideer, få tilbakemeldinger og redusere risiko. Sammenhengen er altså at **prototyping brukes for å gjøre interaksjonsdesign konkret og testbart**.

Hvis du designer en innloggingsflyt, kan du først lage en **lavoppløselig prototype** på papir eller i Figma for å utforske struktur og rekkefølge. Senere kan du lage en **høyoppløselig prototype** med mer realistisk interaksjon. Dermed ser du hvordan valg i design faktisk påvirker brukerens opplevelse.

Evaluering er det som forteller deg om designet faktisk er bra. Her er det viktig å rydde i et begrep: notatene dine sier at evaluering er bredere enn testing, og det er riktig. **Testing** er ofte mer fokusert på feil og korrekthet; **evaluering** vurderer verdi, brukskvalitet og om løsningen oppfyller behov. Brukertesting er én type evaluering.

Så sammenhengen er:
- **Interaksjonsdesign** lager forslag
- **Prototyping** konkretiserer forslagene
- **Evaluering** undersøker om de fungerer
- **Brukertesting** er evaluering med faktiske brukere

Et eksempel: Hvis brukerne ofte klikker feil knapp i prototypen, er ikke problemet nødvendigvis en “bug”. Det kan være et **interaksjonsdesignproblem** relatert til Don Normans prinsipper: dårlig synlighet, svak feedback, dårlig avbilding, manglende konsistens eller uklare affordances/tilbydelser.

---

# 4. Don Norman + universell utforming + WCAG: tre perspektiver på god brukeropplevelse

Dette er et viktig krysspunkt i stoffet.

Don Normans prinsipper handler om **hvordan et grensesnitt blir forståelig og brukbart**. Universell utforming handler om **at flest mulig skal kunne bruke løsningen**. WCAG handler om **konkrete retningslinjer for digital tilgjengelighet**.

Disse tre er altså ikke det samme, men de støtter hverandre.

Hvis du har en knapp for “Send inn”, så sier Norman at knappen må være synlig, forståelig og gi feedback. Universell utforming sier at løsningen må kunne brukes av personer med ulike forutsetninger. WCAG gjør dette konkret, for eksempel ved at knappen må kunne brukes med tastatur, ha tilstrekkelig kontrast, tydelig fokusmarkering og forståelig tekst.

Et godt eksamenspoeng er derfor:
- **Norman**: beskriver prinsipper for god interaksjon
- **Universell utforming**: beskriver inkluderende designmål
- **WCAG**: gir konkrete målbare krav for webtilgjengelighet

Eksempel: Et skjema med rød tekst som eneste feilmelding bryter ofte med flere perspektiver samtidig.
- Dårlig **feedback** etter Norman
- Dårlig **forståelig informasjon** i universell utforming
- Kan bryte WCAG fordi informasjon ikke må formidles bare med farge

---

# 5. Viktig presisering om universell utforming og lovverk

Her bør notatene dine justeres litt.

Du skriver “Lov om likestilling og forbud mot diskriminering (§18, §19a, §41)” og lister deretter §17, §18 og §41. Her må du være mer presis og konsekvent. Hvis du skal svare på eksamen, bør du heller si noe slikt:

**Likestillings- og diskrimineringsloven** stiller krav om universell utforming, og for IKT-løsninger er det særlig bestemmelsene om universell utforming av IKT som er sentrale. I tillegg konkretiseres kravene gjennom **forskrift om universell utforming av IKT**, og disse bygger i praksis på WCAG-krav.

Du bør også være forsiktig med å ramse opp paragrafer hvis du ikke er helt sikker på nummereringen. På eksamen er det ofte bedre å si:
- offentlige og private virksomheter rettet mot allmennheten har plikt til universell utforming
- IKT-løsninger som støtter virksomhetens alminnelige funksjoner omfattes
- forskriften konkretiserer kravene
- WCAG brukes som praktisk standard

Det viktigste er å forstå sammenhengen:  
**Lov → forskrift → tekniske standarder/retningslinjer (WCAG)**

WAD, altså Web Accessibility Directive, er relevant fordi EU-regler påvirker kravene som innføres nasjonalt. Men bruk det som **bakgrunn for regelutvikling**, ikke som erstatning for norske lovkrav.

---

# 6. UML og modeller: hvordan de henger sammen

En annen hovedsammenheng i pensum er at UML-diagrammer viser **samme system fra ulike perspektiver**.

Mange studenter lærer diagrammene hver for seg, men det riktige er å se dem som et sett av briller:

- **Use case-diagram**: hva brukeren/systemet vil oppnå
- **Domenemodell**: hvilke begreper som finnes i problemområdet
- **Aktivitetsdiagram**: hvilke steg/prosesser som skjer
- **Sekvensdiagram**: hvem som snakker med hvem over tid
- **Klassediagram**: hvordan systemet er bygd statisk
- **Tilstandsmaskindiagram**: hvordan et objekt endrer tilstand
- **Pakkediagram**: hvordan systemet organiseres på høyere nivå

Eksempel med nettbutikk:

Et **use case-diagram** viser at kunden kan søke varer, legge i handlekurv og betale.  
En **domenemodell** viser begreper som Kunde, Produkt, Ordre, Betaling.  
Et **aktivitetsdiagram** viser prosessen fra “legg i handlekurv” til “bekreftet betaling”.  
Et **sekvensdiagram** viser meldingene mellom KundeUI, CheckoutController, PaymentService og OrderRepository.  
Et **klassediagram** viser klassene og relasjonene.  
Et **tilstandsmaskindiagram** kan vise at en ordre går fra Opprettet → Betalt → Sendt → Levert / Kansellert.  
Et **pakkediagram** kan gruppere systemet i UI, Domene, Tjenester og Data.

Dette betyr at diagrammene **ikke konkurrerer**, men **utfyller hverandre**.

---

# 7. Use case, brukerhistorier og BDD: forskjell og samspill

Dette er et sted mange blander begreper.

En **brukerhistorie** er en kort, smidig formulering av verdi for en bruker:  
“Som kunde vil jeg kunne lagre handlekurven slik at jeg kan fortsette senere.”

Et **use case** er mer strukturert og beskriver et scenario eller en interaksjon mellom aktør og system, ofte mer detaljert.

**BDD** bygger videre på dette ved å gjøre krav testbare gjennom atferdsbeskrivelser i naturlig språk, ofte Gherkin.

Sammenhengen kan være slik:
1. Produktansvarlig skriver brukerhistorie
2. Teamet diskuterer akseptkriterier
3. Akseptkriteriene uttrykkes som BDD-scenarier
4. Scenariene kan brukes i akseptansetesting

Eksempel:

Brukerhistorie:  
Som kunde vil jeg kunne logge inn slik at jeg får tilgang til mine bestillinger.

BDD-scenario:
- Gitt at jeg er registrert bruker
- Når jeg logger inn med gyldig e-post og passord
- Så skal jeg komme til min kontooversikt

Her ser du samspillet:
- **brukerhistorie** gir mål
- **use case** kan vise interaksjonen
- **BDD** konkretiserer forventet oppførsel
- **akseptansetesting** verifiserer at dette faktisk virker

Presisering: notatene dine sier at akseptkriterier skrives vha domenespesifikt språk “som UML”. Det er litt misvisende. UML er ikke et språk for akseptkriterier i BDD-forstand. BDD bruker heller **naturlig språk i strukturert form**, typisk Gherkin. Domenespråk er mer knyttet til at teamet bruker samme begreper om domenet.

---

# 8. Domenemodell, DDD og arkitektur

Her er det en veldig fin sammenheng som ofte gir gode eksamenssvar.

**Domenemodell** i UML beskriver sentrale begreper og relasjoner i problemområdet.  
**Domain-Driven Design (DDD)** er en utviklingstilnærming der programvaren bygges rundt en dyp forståelse av domenet.  

Så domenemodellen kan ses som et tidlig uttrykk for den forståelsen DDD ønsker å bygge videre på.

Hvis du lager et system for bibliotek, og i domenemodellen har du Bok, Låner, Utlån, Reservasjon og Gebyr, så hjelper det teamet å snakke presist om problemet. I DDD ønsker man at **koden gjenspeiler domenet**, altså at disse begrepene også får plass i designet og koden. Dette reduserer gapet mellom “forretning” og “teknologi”.

Dette påvirker også arkitektur. Hvis du har god domeneforståelse, er det lettere å dele systemet i riktige moduler eller tjenester. Dårlig domeneforståelse gir ofte dårlig arkitektur.

---

# 9. Arkitektur: hvordan mønstrene brukes og når

Arkitekturstoffet ditt handler egentlig om ett spørsmål:  
**Hvordan organiserer vi systemet slik at det håndterer kompleksitet?**

Kompleksitetshåndtering er selve begrunnelsen for arkitektur. Når systemer blir store, må vi dele dem opp. Det er her prinsipper som lav kobling og høy kohesjon blir viktige.

Noen viktige sammenhenger:

## Standalone → klient-tjener → trelags
Dette kan sees som en utvikling i kompleksitet.

En **standalone-applikasjon** passer når alt er lite og samlet.  
Når du trenger flere brukere eller sentral datahåndtering, går du mot **klient-tjener**.  
Når du vil skille ansvar tydeligere, bruker du ofte **trelagsarkitektur**: presentasjon, forretningslogikk og dataaksess.

Dette henger tett sammen med testing:
- Trelagsarkitektur gjør det lettere å enhetsteste logikk uten GUI og database
- Dependency injection og mocking blir lettere når ansvar er tydelig separert

## MVC og trelags
Mange blander disse. MVC og trelags er beslektet, men ikke identiske.

- **MVC** er ofte et mønster for å strukturere interaktiv applikasjonslogikk, spesielt i UI-laget
- **trelagsarkitektur** er en bredere lagdeling av hele systemet

Så MVC kan leve **inni** presentasjonslaget i en trelagsarkitektur.

## Monolitt vs mikrotjenester
Dette er ikke “gammelt vs moderne”, men ulike kompromisser.

En **monolitt** kan være enklest å utvikle, teste og drifte i starten.  
**Mikrotjenester** gir bedre uavhengig skalering og organisatorisk fleksibilitet, men øker kompleksiteten i distribusjon, logging, feilsøking og datakonsistens.

Krysskobling til DevOps og testing:
- Mikrotjenester krever ofte mer moden **CI/CD**, observability og automatisert testing
- Monolitter kan være enklere med mindre team og begrenset domene

## Plugin-arkitektur
Dette passer når du vil ha en stabil kjerne og utvidbar funksjonalitet, som i IDE-er eller nettlesere. Dette henger sammen med **lav kobling** og modularitet.

## Broker, event-bus, pipe-filter, peer-to-peer, master-slave
Disse er mer spesialiserte arkitekturmønstre.

- **Broker** brukes når komponenter ikke skal kjenne hverandre direkte
- **Event-bus** brukes når hendelser skal publiseres og håndteres løst koblet
- **Pipe-filter** passer ved databehandlingskjeder
- **Master-slave** passer ved koordinering og replikering
- **Peer-to-peer** passer når noder er mer likeverdige

Eksempel: I et moderne system kan du faktisk kombinere flere:
- frontend/backend via klient-tjener
- backend som mikrotjenester
- intern kommunikasjon via event-bus
- dataanalyse med pipe-filter
- databasekopier med master-replika

Så arkitektur handler ikke om å velge ett mønster for alltid, men om å velge passende struktur for ulike deler.

---

# 10. REST som kobling mellom arkitektur og implementasjon

REST passer naturlig inn i klient-tjener- og webarkitektur. Det er altså ikke bare et API-format, men en måte å modellere systemets ressurser på.

Sammenhengen er:
- klienten trenger data og tjenester
- serveren eksponerer ressurser
- REST gir et standardisert grensesnitt mellom dem

Du har skrevet at data og funksjonalitet behandles som ressurser tilgjengelig via URI-er. Det er en god hovedidé. Presiseringen er at **ressurser representerer ting eller konsepter**, mens operasjoner utføres gjennom HTTP-metoder.

For eksempel i en timebestillingsløsning:
- `GET /appointments` henter timeavtaler
- `POST /appointments` oppretter ny avtale
- `PUT /appointments/123` oppdaterer en avtale
- `DELETE /appointments/123` sletter den

REST henger også sammen med testing:
- API-er kan integrasjonstestes
- BDD-scenarier kan ofte formuleres rundt API-oppførsel
- DevOps og CI kan kjøre automatiske API-tester

---

# 11. Utviklingsmetodikk: hvordan arbeidet organiseres

Dette stoffet henger sammen som en utvikling i hvordan man tenker om usikkerhet og endring.

## Vannfall og UP
Vannfall passer til en verden der krav antas å være stabile og arbeid kan planlegges sekvensielt. Problemet er at programvareutvikling sjelden er så forutsigbar.

**UP** forsøkte å forbedre dette med iterasjoner, og UML ble sentralt for å modellere systemet.

## Smidige metoder
Smidig oppstod som reaksjon mot tunge prosesser og høy endringsmotstand. Det betyr ikke “ingen struktur”, men at man aksepterer at læring skjer underveis.

Dette knytter seg tett til interaksjonsdesign:
- interaksjonsdesign er iterativt
- smidig utvikling er iterativ
- begge bygger på tilbakemeldinger og forbedring

## Scrum og Kanban
Scrum og Kanban er to måter å styre arbeid på.

Scrum passer når du vil jobbe i tidsbokser med faste seremonier og tydelig sprintmål.  
Kanban passer når du vil optimalisere flyt og redusere flaskehalser uten faste sprinter.

Sammenhengen til testing og leveranse:
- Scrum passer godt med sprintdemo, review og inkrementell levering
- Kanban passer godt med kontinuerlig levering og DevOps-tankegang

## XP, TDD og BDD
Dette er mer konkrete kvalitets- og utviklingspraksiser.

- **XP** fokuserer sterkt på teknisk kvalitet, enkelhet, feedback og hyppige leveranser
- **TDD** er en praksis der tester skrives før kode
- **BDD** bygger videre på tanken om at tester også kan uttrykke forventet atferd på et forretningsnært språk

Sammenhengen kan beskrives slik:
- XP gir kultur og praksiser
- TDD styrker kodekvalitet og design
- BDD knytter krav og tester tettere sammen

## DevOps
DevOps kobler utvikling og drift. Det er viktig å forstå at DevOps ikke erstatter Agile, men utvider det. Agile handler mye om **hvordan vi utvikler riktig programvare**, mens DevOps handler mye om **hvordan vi leverer og drifter den effektivt og trygt**.

Et godt samspillseksempel:
- Scrum-team utvikler funksjonalitet i små inkrementer
- TDD brukes i utviklingen
- CI kjører automatiske tester ved hver commit/PR
- CD sørger for trygg deploy til test/staging/produksjon
- drift og utvikling samarbeider om logging, overvåkning og feilretting

---

# 12. Testing: hvordan hele teststoffet henger sammen

Testing-delen er mye lettere å forstå hvis du deler den i tre hovedspørsmål:

1. **Hva slags feil eller risiko prøver vi å finne?**
2. **På hvilket nivå tester vi?**
3. **Er testingen manuell eller automatisert?**

## Verifisering vs validering
Her er en superviktig sammenheng:
- **Verifisering**: bygger vi produktet riktig?
- **Validering**: bygger vi riktig produkt?

Dette kobler testing til evaluering og MMI. En teknisk korrekt løsning kan fortsatt være feil løsning for brukeren.

## Testnivåene
- **Enhetstest**: én liten del isolert
- **Integrasjonstest**: samspill mellom deler
- **Systemtest**: hele systemet
- **Akseptansetest**: møter systemet bruker-/kundekrav?

Dette henger også sammen med arkitektur:
- god lagdeling gjør enhetstesting lettere
- løst koblede tjenester krever mer integrasjonstesting
- distribuerte systemer gjør systemtesting vanskeligere

## TDD, mocking og dependency injection
Disse tre henger veldig tett sammen.

TDD krever at koden er lett å teste. For at en klasse skal være lett å teste, må avhengighetene kunne isoleres. Derfor bruker man ofte **dependency injection**. Når avhengighetene er injisert, kan de erstattes med **mocks** i testene.

Eksempel:
En `OrderService` bruker `PaymentGateway`. I en enhetstest vil du ikke snakke med ekte betalingssystem. Derfor injiserer du en mock av `PaymentGateway` som returnerer kontrollerte svar.

Sammenhengen er altså:
- arkitektur/design for testbarhet
- dependency injection for løs kobling
- mocking for kontrollert testmiljø
- TDD for å styre utvikling gjennom tester

## Regresjon, CI og små endringer
Regresjonstesting blir i smidig/DevOps ofte en naturlig konsekvens av at testene kjøres kontinuerlig. Når du gjør små endringer og har CI, blir det lettere å se hva som brøt noe. Derfor henger disse begrepene tett sammen:
- små inkrementer
- hyppige commits/PR-er
- automatiserte tester
- rask feedback
- enklere rollback

## Risiko og prioritering
Risk poker, prioritering av testing og testdata henger sammen med prosjektstyring. Du kan ikke teste absolutt alt. Derfor må du prioritere ut fra risiko og konsekvens. Det er egentlig samme tankegang som risikoanalyse i prosjektplanlegging.

Hvis feil i betalingsflyt er kritisk, tester du den mer enn fargevalg på en sekundærsida. Dermed kobles testing til forretningsverdi.

---

# 13. Manuell vs automatisk testing: viktig nyansering

Notatene dine for “automatisk eller manuell testing” er litt for grove og bør presiseres.

Det er ikke helt riktig å si at bestemte testtyper “er” automatiske og andre “er” manuelle. Mange testtyper kan være begge deler, avhengig av hvordan de gjennomføres.

Mer presist:
- **Enhetstester** er nesten alltid automatiserte
- **Integrasjonstester** er ofte automatiserte, men kan også være manuelle
- **Systemtester** kan være både manuelle og automatiserte
- **Akseptansetester** kan være begge deler
- **Smoke/sanity** kan være begge deler
- **Usabilitytesting** er ofte manuell
- **Utforskende og destruktiv testing** er typisk manuell, fordi de bygger på menneskelig kreativitet
- **Ytelsestesting** er ofte automatisert med verktøy, men analyseres av mennesker

Det viktigste skillet er egentlig ikke testtypen, men **om gjennomføringen kan standardiseres og repeteres effektivt av maskin**.

---

# 14. Black-box, white-box, usability og destruktiv testing: ulike perspektiver på samme system

Disse begrepene beskriver **hvordan du ser på systemet under testing**.

- **Black-box**: du bryr deg om input og output, ikke intern struktur
- **White-box**: du kjenner intern struktur og tester logikk, veier og kode
- **Usabilitytesting**: du ser på brukeropplevelse og brukervennlighet
- **Destruktiv testing**: du prøver aktivt å få systemet til å feile

Et system kan altså testes fra flere perspektiver samtidig. En innloggingsfunksjon kan:
- enhetstestes white-box av utvikler
- systemtestes black-box av QA
- brukertestes for usability
- angripes destruktivt med rare input eller uventede handlingsmønstre

Dette er et godt eksempel på hvordan pensum overlapper.

---

# 15. Prosjektplanlegging, visjon, risikoanalyse og metodikk

Vision-dokument, risikoanalyse, Scrum/Kanban, testing og arkitektur henger sammen fordi de alle handler om **styring av usikkerhet**.

Visjonsdokumentet sier hvor prosjektet skal.  
Brukerhistorier og backlog konkretiserer arbeidet.  
Risikoanalyse sier hva som kan gå galt.  
Arkitekturvalg prøver å redusere teknisk risiko.  
Prototyper reduserer bruker- og designrisiko.  
Testing reduserer kvalitetsrisiko.  
Smidige metoder reduserer planrisiko ved å lære underveis.

Et veldig godt eksamensresonnement er derfor at mange praksiser i faget egentlig er ulike former for **risikoreduksjon**:
- prototype reduserer risiko for feil løsning
- UML reduserer risiko for misforståelser
- arkitektur reduserer risiko for kaos ved vekst
- tester reduserer risiko for feil i produksjon
- CI/CD reduserer risiko i leveranse
- universell utforming reduserer risiko for ekskludering og lovbrudd
- GDPR-arbeid reduserer risiko for personvernbrudd

---

# 16. GDPR, profesjonsetikk og kvalitet: hvordan de henger sammen

Dette er en veldig viktig del som mange svarer for isolert på eksamen, men som egentlig henger tett sammen med kvalitet og design.

GDPR handler om behandling av personopplysninger og individets rettigheter. Dette er ikke bare “juss ved siden av”, men påvirker **hvordan du designer systemet**.

Hvis du bygger en app med persondata, må du tenke:
- hvilke data er faktisk nødvendige?  
  → dataminimering
- hvor lenge skal de lagres?  
  → lagringsbegrensning
- hvordan sikres de?  
  → integritet og konfidensialitet
- hvordan kan brukeren få innsyn eller sletting?  
  → registrertes rettigheter

Dette påvirker både arkitektur, databasevalg, tilgangsstyring, logging og UI.

Eksempel: Hvis en bruker skal kunne be om innsyn i egne data, må systemet være bygd slik at data faktisk kan finnes, eksporteres og forklares. Altså påvirker GDPR teknisk design.

Profesjonsetikk går enda bredere. Her er poenget at utvikleren ikke bare har ansvar for å “få det til å virke”, men også for konsekvensene av systemet. Det knytter seg til:
- sikkerhet
- personvern
- diskriminering og bias
- brukerens velferd
- samfunnsmessige følger

Derfor henger etikk sammen med kvalitet: et system kan være teknisk imponerende, men fortsatt være dårlig programvare hvis det krenker personvern, ekskluderer brukere eller skaper skade.

---

# 17. Konkrete eksempelkjeder: slik anvender du stoffet samlet

Her er noen helhetlige eksempler som viser hvordan du kan bruke flere deler av pensum i ett svar.

## Eksempel 1: Lage nettbutikk
Du starter med interaksjonsdesign for å forstå hvordan kunden skal finne varer og betale enkelt. Du lager prototyper og evaluerer dem med brukertesting. Samtidig må du sikre universell utforming og WCAG, slik at løsningen fungerer for tastaturbrukere og personer med nedsatt syn.

Deretter beskriver du systemet med brukerhistorier og use cases. Domenemodellen kan inneholde Kunde, Produkt, Handlekurv og Ordre. Sekvensdiagram viser hvordan checkout fungerer. Klassediagram beskriver struktur.

Arkitekturmessig velger du kanskje klient-tjener med tre lag og REST-API. Hvis systemet er lite, starter du monolittisk. Hvis det vokser mye, kan enkelte deler skilles ut som mikrotjenester, for eksempel betaling og lager.

Utviklingsmessig kan teamet jobbe i Scrum med sprinter og backlog. TDD brukes på kjernelogikk som prisberegning. BDD brukes på akseptansekriterier for kjøpsflyt. CI kjører automatiske tester ved hver PR. CD deployer til staging. QA gjør systemtesting og usabilitytesting. GDPR er viktig fordi kundenes person- og betalingsdata behandles, så dataminimering, tilgangskontroll og sikker lagring må bygges inn.

## Eksempel 2: Bestille legetime
Her blir MMI ekstra viktig, fordi brukerne kan være stressede, eldre eller uvante med teknologi. Norman-prinsipper og universell utforming blir sentrale. Use case: bestille, endre og avbestille time. Tilstandsmaskin for timeavtale. Arkitektur: klient-tjener, kanskje med REST. Testing: enhetstester for validering, integrasjonstester mot API, systemtester for hele flyten, akseptansetester sammen med oppdragsgiver. GDPR er helt sentralt fordi helseopplysninger er sensitive. Profesjonsetikken skjerper ansvaret enda mer.

---

# 18. Viktige feil og presiseringer i notatene dine

Her er noen ting jeg ville formulert mer presist til eksamen:

## Interaksjonsdesign
Bra hovedinnhold, men skriv heller “interaksjonsmønstre” enn “interaksjonsmønstrer”.

## De fem dimensjonene i IxD
Den vanlige fremstillingen er:
1. ord
2. visuelle representasjoner
3. fysiske objekter/rom
4. tid
5. atferd

Du har dette omtrent riktig, men “tid-brukt på de første 3 dimensjonene” er litt upresist. Tid handler mer om hvordan interaksjon utfolder seg over tid: animasjon, lyd, sekvenser, respons.

## Don Norman
“Tilbydelser” er affordances. God forklaring, men skriv det gjerne som:  
“Affordances beskriver hvilke handlinger brukeren oppfatter som mulige.”

## Evaluering uten brukere
“Pluralistiske gjennomganger” involverer faktisk mennesker, ofte brukere, utviklere og eksperter sammen. Så den hører ikke helt rent under “ikke involverer brukere” slik du har satt den opp.

## Prediktive modeller
Dette er ikke nødvendigvis “maskinlæringsmodeller”. Prediktive modeller i HCI kan også være analytiske modeller som estimerer brukerhandlinger eller ytelse.

## Brukerhistorier
Formatet skal være omtrent:  
**“As a [rolle], I want [mål], so that [nytte].”**  
Ikke bare “As <> I want<> Suchthat<>”.

## Scrum-seremonier
Standup, sprint planning, sprint review og retrospektiv er separate seremonier. I notatet ditt ser sprint review og retrospektiv nesten ut som underpunkter av standup. Det er feil.

## TDD og DDD
Du skriver et sted “kontinuerlig og automatisk gjennom DDD.” Der mener du sannsynligvis **TDD**, ikke DDD.

## BDD
Akseptkriterier skrives ikke “vha domenespesifikt språk som UML”. Mer riktig: de skrives i et felles, forståelig språk for domene og forretning, ofte som Gherkin-scenarier.

## Akseptansetesting
“Er manuell og automatisk” er for kort. Bedre:  
“Akseptansetesting kan gjennomføres både manuelt og automatisk.”

## Destruktiv testing vs utforskende testing
Her er notatet litt forenklet. Utforskende testing er ikke bare “destruktiv testing, men white-box”. Utforskende testing er bredere og handler om samtidig læring, testdesign og testgjennomføring. Den trenger ikke være destruktiv, men kan være det.

## Automatisert testing
“Finner ikke noe eksplisitt” er upresist. Bedre:  
“Automatiserte tester er gode på repeterbare, kjente forventninger, men dårlige til å oppdage uventede problemer i brukeropplevelse, estetikk og kreative feilsituasjoner.”

## WCAG
Du skriver WCAG 2.0, men i moderne sammenheng brukes ofte 2.1 eller 2.2 i praksis. På eksamen må du likevel svare ut fra pensum, men vær bevisst på at prinsippene er de samme: perceivable, operable, understandable, robust.

---

# 19. Hvordan du bør svare anvendt på eksamen

Når du får et spørsmål, ikke svar som en løs definisjon hvis du kan unngå det. Svar heller i denne rekkefølgen:

1. **Definer begrepet kort og presist**
2. **Forklar hva det brukes til**
3. **Forklar hvordan det henger sammen med andre begreper**
4. **Gi et eksempel**
5. **Nevn eventuelle fordeler/ulemper eller typiske misforståelser**

Eksempel hvis du får “Hva er en prototype?”  
Dårlig svar: “En prototype er en tidlig versjon av et produkt.”  
Sterkere svar:  
“En prototype er en tidlig representasjon av et system som brukes for å utforske designvalg og få tilbakemeldinger før full implementasjon. I interaksjonsdesign brukes prototyper for å redusere risiko og evaluere om løsningen støtter brukerens behov. De kan være lavoppløselige eller høyoppløselige, og brukes ofte sammen med brukertesting og evaluering. For eksempel kan en papirprototype av en nettbutikk brukes til å teste om brukeren forstår checkout-flyten før man utvikler backend og database.”

Det er dette sensor ofte oppfatter som ekte forståelse.

---

# 20. Den viktigste helhetsforståelsen du bør sitte igjen med

Hvis du skal huske én ting, så er det dette:

**Systemutvikling er en iterativ prosess der vi prøver å bygge riktig system på riktig måte.**

“Riktig system” handler om:
- brukerbehov
- MMI
- interaksjonsdesign
- evaluering
- brukertesting
- universell utforming
- WCAG
- akseptanse
- etikk
- GDPR

“Riktig måte” handler om:
- UML og modellering
- arkitektur
- smidige metoder
- Scrum/Kanban/XP
- TDD/BDD
- testing
- CI/CD
- DevOps
- risikoanalyse
- prosjektplanlegging

Det ene uten det andre er ikke nok. Et system kan være teknisk elegant, men ubrukelig eller ulovlig. Eller det kan være ønsket av brukeren, men teknisk ustabilt og umulig å vedlikeholde. Hele pensumet ditt handler egentlig om å balansere disse hensynene.

---

Hvis du vil, kan jeg gjøre dette videre på **tre veldig nyttige måter**:

1. lage en **stor sammenhengsoversikt tema-for-tema** i tabellform  
2. lage en **muntlig eksamensforklaring** for hvert hovedtema i naturlig språk  
3. lage en **“hvis du får spørsmål om X, koble det til Y og Z”**-oversikt for rask pugging

Jeg kan også gå gjennom **hele Slides.md punkt for punkt** og gjøre den om til **forbedrede, faglig presise eksamensnotater**.

## @real-eo

videre, lag både: en stor sammenhengsoversikt tema-for-tema i tabellform, en muntlig eksamensforklaring for hvert hovedtema i naturlig språk, og “hvis du får spørsmål om X, koble det til Y og Z”-oversikt for rask pugging. IKKE: gå gjennom hele Slides.md punkt for punkt og gjøre den om til forbedrede, faglig presise eksamensnotater.

## Copilot

Ja — under får du **alle tre delene**, men **ikke** en punkt-for-punkt omskriving av hele `Slides.md`.

---

# Del 1: Stor sammenhengsoversikt tema-for-tema i tabellform

## 1. Helhetstabell: hva temaet betyr, hva det brukes til, og hva det henger sammen med

| Tema | Hva det er | Hva det brukes til | Henger særlig sammen med | Typisk eksempel |
|---|---|---|---|---|
| MMI | Faget om samspillet mellom mennesker og digitale systemer | Å lage løsninger som faktisk fungerer for mennesker | Interaksjonsdesign, evaluering, brukertesting, universell utforming, WCAG | En app kan være teknisk korrekt, men fortsatt vanskelig å bruke |
| Interaksjonsdesign | Utforming av hvordan brukeren handler i og opplever systemet | Å gjøre løsninger intuitive, effektive og meningsfulle | Prototyping, Norman, evaluering, brukertesting | Lage en god bestillingsflyt i en nettbutikk |
| Prototyping | Tidlige representasjoner av løsning | Å utforske ideer og redusere risiko før full implementasjon | Interaksjonsdesign, evaluering, brukertesting, smidig utvikling | Figma-prototype av innloggingsskjerm |
| Evaluering | Vurdering av kvalitet, nytte og brukeropplevelse | Å finne ut om løsningen fungerer som ønsket | Prototyping, brukertesting, heuristikker, validering | Testing av om brukerne finner “betal”-knappen |
| Brukertesting | Observasjon av brukere som utfører oppgaver | Å avdekke problemer i brukbarhet og forståelse | Evaluering, prototyper, MMI | En bruker prøver å bestille time uten hjelp |
| Universell utforming | Utforming for at flest mulig skal kunne bruke løsningen | Å inkludere brukere med ulike forutsetninger | WCAG, lovkrav, MMI, interaksjonsdesign | Et skjema som fungerer med tastatur og skjermleser |
| WCAG | Retningslinjer for webtilgjengelighet | Å konkretisere krav til tilgjengelighet | Universell utforming, lovkrav, testing | Kontrastkrav, alt-tekst, tastaturnavigasjon |
| Lovkrav til UU | Juridiske krav til tilgjengelighet i IKT | Å sikre at løsninger følger lov og forskrift | WCAG, universell utforming, profesjonsetikk | Offentlig nettside må være universelt utformet |
| UML | Modellspråk for å visualisere og beskrive systemer | Å skape felles forståelse av systemet | Krav, brukerhistorier, arkitektur, design | Diagrammer før koding |
| Use case | Modell av aktørers mål og samspill med systemet | Å beskrive funksjonelle krav og scenarioer | Brukerhistorier, BDD, sekvensdiagram | “Bestill time” |
| Domenemodell | Modell av sentrale begreper og relasjoner i domenet | Å skape felles domene-forståelse | DDD, klassediagram, brukerhistorier | Kunde, ordre, betaling |
| Sekvensdiagram | Viser meldinger mellom deltakere over tid | Å forstå flyt og samarbeid mellom komponenter | Use case, klassediagram, arkitektur | KundeUI kaller CheckoutService |
| Aktivitetsdiagram | Viser prosessflyt og beslutninger | Å beskrive arbeidsflyt og logikk | Use case, sekvensdiagram, brukertesting | Flyt for innlevering av skjema |
| Klassediagram | Statisk struktur med klasser og relasjoner | Å designe programstruktur | Domenemodell, sekvensdiagram, OO-design | Order, Customer, Product |
| Pakkediagram | Høynivågruppering av systemelementer | Å vise modularisering og struktur | Arkitektur, lagdeling, kompleksitetshåndtering | UI-, domene- og datalag |
| Tilstandsmaskindiagram | Viser tilstander og overganger | Å beskrive livsløp for objekter | Use case, sekvensdiagram, domenelogikk | Ordre: opprettet → betalt → sendt |
| Brukerhistorier | Små beskrivelser av brukerbehov | Å planlegge og prioritere arbeid | Use case, Scrum, BDD, akseptansetesting | “Som kunde vil jeg…” |
| Programvarearkitektur | Overordnet struktur i systemet | Å håndtere kompleksitet og styre kvaliteter | UML, testing, deployment, DevOps | Monolitt eller mikrotjenester |
| Kompleksitetshåndtering | Deling av system i mindre ansvar | Å gjøre systemer forståelige og vedlikeholdbare | Arkitektur, lagdeling, modulisering, testing | Skille UI, logikk og data |
| Standalone-applikasjon | Alt i én applikasjon | Egnet for små og enkle systemer | Monolitt, enkel testing | Liten desktop-app |
| Klient-tjener | System delt i klient og server | Å sentralisere logikk/data og støtte flere klienter | REST, trelagsarkitektur, webapplikasjoner | Nettleser + backend |
| Trelagsarkitektur | Presentasjon, logikk, data | Å skille ansvar og gjøre systemet mer vedlikeholdbart | Testing, MVC, klient-tjener | Frontend, service-lag, database-lag |
| Master-slave | En styrende enhet og flere arbeidende enheter | Å koordinere arbeid eller replikering | Distribuerte systemer, databaser | Primærdatabase med replikaer |
| Pipe-filter | Behandling i sekvensielle steg | Å strukturere databehandling | Dataflyt, ETL, streaming | Parser → validering → lagring |
| Broker | Mellomledd for kommunikasjon mellom komponenter | Å redusere direkte kobling | Distribuerte systemer, service discovery | Meldingsmegler |
| Peer-to-peer | Noder med likere roller | Å muliggjøre distribuert samarbeid | Nettverk, distribuert arkitektur | Fildeling |
| Event-bus | Hendelsesbasert kommunikasjon | Å koble komponenter løst | Mikrotjenester, asynkronitet, observer-mønster | “OrderCreated”-event |
| MVC | Deling i model, view og controller | Å strukturere interaktive apper | UI-design, trelagsarkitektur | Web- eller GUI-applikasjon |
| Mikrotjenester | Mange små, selvstendige tjenester | Å skalere, organisere og deploye uavhengig | DevOps, CI/CD, event-bus, REST | Egen tjeneste for betaling |
| Monolitt | Ett samlet system | Enkelt å starte med og drifte tidlig | Standalone, enklere deploy, testing | Alt i én backend |
| Plugin-arkitektur | Kjerne + utvidelser | Å gjøre systemer fleksible og utvidbare | Modulisering, lav kobling | VS Code extensions |
| Deployment-arkitektur | Hvordan programvare kjøres og distribueres | Å sikre drift, skalering og stabilitet | DevOps, containere, mikrotjenester | Docker + Kubernetes |
| Vannfall | Sekvensiell utviklingsmodell | Å planlegge tydelige faser | Tradisjonell testing, tung dokumentasjon | Krav → design → kode → test |
| UP | Iterativ prosess med mye modellering | Å håndtere endringer bedre enn vannfall | UML, iterasjoner | Tidlige iterasjoner med modeller |
| Smidige metoder | Iterativ, adaptiv utvikling | Å håndtere endringer og få rask feedback | Scrum, Kanban, XP, TDD, DevOps | Korte inkrementer |
| Scrum | Sprintbasert arbeidsrammeverk | Å strukturere smidig arbeid | Brukerhistorier, backlog, review, retro | To ukers sprint |
| Kanban | Flytbasert arbeidsmåte | Å optimalisere kontinuerlig flyt | WIP-begrensning, DevOps | Tavle med oppgaver i flyt |
| XP | Smidig metode med tekniske praksiser | Å sikre høy kodekvalitet og rask feedback | TDD, parprogrammering, refaktorering | Test først, kode deretter |
| TDD | Test først, så kode | Å styre design og sikre testbarhet | XP, enhetstesting, mocking, DI | Skriv test for kalkulator før kode |
| BDD | Atferdsdrevet utvikling | Å koble krav, språk og akseptansetesting | Brukerhistorier, Gherkin, akseptansetesting | Given-When-Then-scenarioer |
| Lean | Fokus på verdi og fjerning av sløsing | Å effektivisere utvikling | Kanban, smidig, levering | Unngå unødvendig dokumentasjon |
| DDD | Domenedrevet utvikling | Å bygge system rundt domeneforståelse | Domenemodell, arkitektur, språk | Kode som speiler forretningsbegreper |
| DevOps | Kultur for samarbeid mellom utvikling og drift | Å muliggjøre rask og trygg levering | CI/CD, deployment, monitorering | Automatisert bygg, test og deploy |
| REST | Arkitekturstil for API-er | Å eksponere ressurser over HTTP | Klient-tjener, testing, websystemer | GET /orders |
| Testing | Verifikasjon og validering av system | Å finne feil og bygge tillit | TDD, CI, kvalitet, akseptanse | Teste både kode og brukbarhet |
| Enhetstesting | Test av små isolerte deler | Å finne feil tidlig og billig | TDD, mocking, DI | Test av `calculateTotal()` |
| Integrasjonstesting | Test av samspill mellom komponenter | Å finne grensesnittfeil | API-er, databaser, arkitektur | Service + repository |
| Systemtesting | Test av hele systemet | Å se om alt fungerer sammen | Akseptanse, staging, QA | Komplett kjøpsflyt |
| Akseptansetesting | Test mot bruker-/kundekrav | Å avgjøre om løsningen er godkjent | BDD, brukerhistorier, validering | Kunden godkjenner bookingflyt |
| Regresjonstesting | Test for å oppdage at noe gammelt har blitt ødelagt | Å sikre trygg videreutvikling | CI, automatiserte tester, små endringer | Gamle tester kjøres etter ny kode |
| Smoke/sanity | Overfladiske kontroller av kritisk eller ny funksjonalitet | Å raskt sjekke om systemet er testbart | Release, systemtesting | “Starter appen og kan jeg logge inn?” |
| Mocking | Erstatte ekte avhengigheter med testdobler | Å isolere tester og gjøre dem deterministiske | Enhetstesting, TDD, DI | Fake betalingstjeneste i test |
| Testdata | Kontrollerte data brukt i test | Å sikre forutsigbare og repeterbare tester | Automatisering, regresjon, testfaser | Fast datasett i databasen |
| Risk poker | Felles vurdering av risiko og konsekvens | Å prioritere test og innsats | Risikoanalyse, teststrategi, Scrum | Teamet vurderer betalingsfeil som høy risiko |
| GDPR | Regelverk for behandling av personopplysninger | Å beskytte personvern og kontroll over data | Etikk, arkitektur, sikkerhet, krav | Innsyn, sletting, dataminimering |
| Profesjonsetikk | Moralsk ansvar i profesjonell praksis | Å ta ansvar for konsekvenser av teknologi | GDPR, UU, kvalitet, sikkerhet | Ikke lage diskriminerende systemer |
| Prosjektplanlegging | Plan for mål, risiko og gjennomføring | Å styre prosjektet mot ønsket resultat | Vision, risiko, smidig arbeid | Prosjektmål, milepæler, interessenter |
| Visjonsdokument | Beskrivelse av formål og retning | Å gi felles forståelse | Krav, brukerhistorier, interessenter | Hva produktet skal oppnå |
| Risikoanalyse | Analyse av hva som kan gå galt | Å prioritere tiltak og redusere usikkerhet | Testing, arkitektur, prosjektstyring | Risiko for personvernbrudd |

---

## 2. Kryssreferansetabell: “Dette temaet bør nesten alltid kobles til …”

| Hvis temaet er … | Koble det til … | Hvorfor |
|---|---|---|
| Interaksjonsdesign | Prototyping, evaluering, brukertesting | Design må prøves ut og vurderes |
| Brukertesting | Evaluering, prototyper, MMI | Brukertesting er en del av evaluering |
| Universell utforming | WCAG, lovkrav, MMI | UU er målet, WCAG er konkretiseringen |
| WCAG | Universell utforming, testing | WCAG må faktisk testes i praksis |
| Use case | Brukerhistorier, sekvensdiagram, akseptanse | Use case beskriver mål og scenario |
| Domenemodell | DDD, klassediagram, språk i teamet | Domeneforståelse styrer design og kode |
| Sekvensdiagram | Use case, klassediagram, arkitektur | Viser hvordan statiske deler samarbeider |
| Klassediagram | Domenemodell, sekvensdiagram, testing | Struktur påvirker implementasjon og testbarhet |
| Arkitektur | Kompleksitet, testing, deployment | Arkitektur velges for å håndtere kvaliteter og risiko |
| Trelagsarkitektur | Testing, MVC, lav kobling | Lagdeling gjør test og vedlikehold lettere |
| Mikrotjenester | DevOps, CI/CD, observability, event-bus | Distribusjon krever mer moden drift |
| Monolitt | Enkel deployment, tidlig fase, enklere debugging | Ofte bra når kompleksitet må holdes nede |
| Scrum | Brukerhistorier, backlog, review, retro | Scrum er en styringsramme rundt arbeidet |
| Kanban | Flyt, WIP, kontinuerlig levering | Handler om flyt framfor sprint |
| XP | TDD, parprogrammering, refaktorering | XP konkretiserer tekniske smidige praksiser |
| TDD | Enhetstesting, mocking, DI | TDD krever testbar kode |
| BDD | Brukerhistorier, akseptansetesting, Gherkin | BDD gjør krav om til testbare scenarier |
| DevOps | CI/CD, automatiserte tester, deployment | DevOps kobler utvikling og drift |
| Enhetstesting | TDD, mocking, DI | Isolasjon og determinisme er viktig |
| Integrasjonstesting | API, databaser, arkitektur | Samspill mellom komponenter testes |
| Akseptansetesting | BDD, brukerhistorier, kunde | Handler om å møte behovene |
| Regresjonstesting | CI, små endringer, automatisering | Kjøres ofte hele tiden i moderne utvikling |
| GDPR | Etikk, sikkerhet, arkitektur | Personvern må bygges inn i systemet |
| Profesjonsetikk | GDPR, UU, kvalitet, samfunnsansvar | Etikk påvirker tekniske valg |
| Risikoanalyse | Testing, prosjektplanlegging, arkitektur | Risiko avgjør hva som prioriteres |

---

# Del 2: Muntlig eksamensforklaring for hvert hovedtema i naturlig språk

Nå formulerer jeg dette slik du kan **si det muntlig**.

---

## MMI og interaksjonsdesign

Hvis jeg skulle forklart MMI muntlig, ville jeg sagt at dette handler om forholdet mellom mennesket og systemet, altså hvordan vi designer digitale løsninger som faktisk fungerer godt for brukeren. Interaksjonsdesign er den delen av dette som handler om å utforme selve samhandlingen: hvilke valg brukeren får, hvordan navigasjon fungerer, hvordan systemet gir tilbakemelding, og hvordan opplevelsen blir intuitiv og effektiv. Dette henger tett sammen med prototyping og evaluering, fordi vi ikke bare kan anta at et design fungerer; vi må teste det tidlig og forbedre det iterativt. Don Normans prinsipper er sentrale her fordi de gir oss et språk for å vurdere brukskvalitet, for eksempel synlighet, feedback, konsistens og affordances. I praksis betyr dette at hvis jeg designer et skjema eller en bestillingsflyt, må jeg tenke på hva brukeren prøver å oppnå, hvordan systemet kommuniserer med brukeren, og hvor lett det er å gjøre riktige handlinger uten å bli forvirret.

---

## Prototyping, evaluering og brukertesting

Prototyping brukes for å gjøre idéer konkrete tidlig i prosessen, før vi bruker mye tid på full utvikling. En prototype kan være alt fra en enkel papirskisse til en høyoppløselig, klikkbar modell. Poenget er å redusere risiko og få innsikt. Dette henger tett sammen med evaluering, fordi prototyper gir oss noe vi faktisk kan evaluere. Evaluering er et bredt begrep som handler om å vurdere kvalitet og nytte, mens brukertesting er en mer spesifikk metode der vi observerer brukere som løser oppgaver. Jeg ville forklart sammenhengen slik: interaksjonsdesign lager forslag, prototyping gjør dem testbare, evaluering undersøker hvor gode de er, og brukertesting gir direkte innsikt i hvordan reelle brukere oppfatter løsningen. I praksis kan man for eksempel lage en prototype av en timebestillingsløsning og la brukere prøve å finne ledige timer. Hvis de sliter med å forstå neste steg, er det et tegn på at designet må forbedres.

---

## Universell utforming, lovkrav og WCAG

Universell utforming handler om at løsninger skal kunne brukes av flest mulig, uavhengig av funksjonsevne og forutsetninger. Dette er både et designmål, et kvalitetsmål og i mange sammenhenger et lovkrav. Jeg ville forklart at universell utforming er det overordnede prinsippet, mens WCAG er den konkrete standarden eller retningslinjesamlingen som hjelper oss å oppfylle dette i praksis på web. Lovkravene gjør at dette ikke bare er “nice to have”, men noe virksomheter faktisk er pålagt å følge, særlig når IKT-løsninger er rettet mot allmennheten. Dette henger også tett sammen med MMI, fordi god tilgjengelighet i praksis ofte også gir bedre brukervennlighet generelt. Et godt eksempel er tydelig kontrast, god struktur og tastaturnavigasjon: det hjelper brukere med funksjonsnedsettelser, men også vanlige brukere på mobil, i sterkt lys eller under stress.

---

## UML og modellering

UML bruker vi for å visualisere og kommunisere systemer på en strukturert måte. Poenget er ikke å lage diagrammer for diagrammenes skyld, men å skape felles forståelse og redusere misforståelser. Jeg ville forklart at forskjellige UML-diagrammer viser forskjellige sider av samme system. Use case-diagrammet viser hva aktører vil oppnå. Domenemodellen viser sentrale begreper i problemområdet. Sekvensdiagram viser meldinger mellom objekter over tid. Aktivitetsdiagram viser prosessflyt. Klassediagram viser den statiske strukturen. Tilstandsmaskindiagram viser hvordan objekter endrer tilstand. Poenget er at de utfyller hverandre. Hvis vi for eksempel lager en nettbutikk, kan use case vise at kunden vil betale, sekvensdiagrammet vise hvordan komponentene samarbeider i checkout, og klassediagrammet vise hvilke klasser som trengs. UML henger derfor tett sammen med både kravarbeid, design og arkitektur.

---

## Brukerhistorier, use case og BDD

Brukerhistorier, use case og BDD er tre ulike måter å beskrive behov og forventet oppførsel på, men de henger tett sammen. Brukerhistorier er korte og verdiorienterte, og brukes ofte i smidige prosesser for planlegging og prioritering. Use case er mer scenariobaserte og viser hvordan en aktør samhandler med systemet for å oppnå et mål. BDD bygger videre på dette ved å formulere akseptkriterier som kjørbare eller halvformelle scenarier i naturlig språk, ofte i Given-When-Then-format. Jeg ville forklart dette som en kjede: først identifiserer vi brukerbehov gjennom brukerhistorier, så konkretiserer vi interaksjonen gjennom use case, og deretter gjør vi forventningene testbare gjennom BDD-scenarier. Dette knytter sammen krav, kommunikasjon og testing.

---

## Programvarearkitektur

Programvarearkitektur handler om den overordnede strukturen i systemet: hvilke deler det består av, hvordan de samarbeider, og hvilke prinsipper som styrer design og utvikling videre. Jeg ville lagt vekt på at arkitektur først og fremst handler om å håndtere kompleksitet. Når systemer blir store, må vi dele dem opp på en måte som gir lav kobling, høy kohesjon og tydelig ansvar. Dette henger tett sammen med testing, vedlikehold, skalering og teamarbeid. Hvis vi for eksempel velger trelagsarkitektur, blir det lettere å teste forretningslogikken separat fra brukergrensesnitt og database. Hvis vi velger mikrotjenester, kan vi skalere og deploye deler uavhengig, men vi får også mer kompleksitet i drift og feilsøking. Derfor er arkitektur alltid et kompromiss mellom ulike kvalitetskrav.

---

## Arkitekturmønstre

De ulike arkitekturmønstrene i pensum kan forklares som ulike måter å organisere systemer på avhengig av behov. Klient-tjener brukes når klienter ber om tjenester fra en sentral server. Trelagsarkitektur skiller presentasjon, logikk og data. MVC strukturerer interaktive applikasjoner i model, view og controller. Monolitt samler alt i ett system, mens mikrotjenester deler det i mange små tjenester. Event-bus og broker brukes når vi vil ha løsere kobling mellom komponenter. Pipe-filter passer når data skal behandles i flere steg. Jeg ville forklart at disse mønstrene ikke nødvendigvis utelukker hverandre; i et moderne system kan man ha klient-tjener på toppnivå, mikrotjenester i backend, REST mellom tjenester og event-bus for asynkron kommunikasjon. Det sentrale er å kunne begrunne hvorfor et mønster passer i en gitt situasjon.

---

## Smidige metoder, Scrum og Kanban

Smidige metoder oppstod fordi tradisjonelle, tunge prosesser fungerte dårlig når krav og omgivelser endret seg. Kjernen i smidig er iterasjon, samarbeid, tilbakemelding og tilpasning. Scrum og Kanban er to ulike måter å organisere dette på. Scrum bruker tidsbokser, altså sprinter, og har faste seremonier som planning, daily standup, review og retrospektiv. Kanban fokuserer mer på flyt, visuell styring og begrensning av arbeid i prosess. Jeg ville forklart at begge prøver å få framgang og læring, men på ulike måter. Scrum passer ofte når man vil ha rytme og forpliktelse rundt sprintmål, mens Kanban passer når man vil optimalisere kontinuerlig flyt og redusere flaskehalser. Disse metodene henger tett sammen med brukerhistorier, backlog, testing og DevOps.

---

## XP, TDD og BDD

XP er en smidig metode med sterkt fokus på tekniske praksiser som høy kvalitet, tett feedback, enkel kode og refaktorering. TDD er en praksis innen denne tradisjonen der man skriver test først, ser at den feiler, skriver minimal kode for å få den grønn, og så refaktorerer. BDD bygger videre på tanken om at spesifikasjon og test kan uttrykkes i et språk som også forretning og kunde forstår. Jeg ville forklart samspillet slik: XP gir verdier og praksiser, TDD hjelper oss å bygge kode med god struktur og høy testbarhet, og BDD knytter funksjonelle krav og akseptanse tettere til utvikling og test. For eksempel kan TDD brukes på en prisberegningsfunksjon, mens BDD brukes på brukerens kjøpsopplevelse.

---

## DDD og domeneforståelse

Domain-Driven Design handler om at systemet skal bygges rundt en dyp forståelse av domenet. Jeg ville forklart at dette henger nært sammen med domenemodellering og språk. Hvis teamet og kunden bruker de samme begrepene, og disse begrepene også speiles i koden, blir det mindre misforståelser og bedre samsvar mellom forretningsbehov og teknisk løsning. DDD er spesielt nyttig i komplekse domener der det er viktig å modellere virkeligheten på en presis måte. Dette påvirker både arkitektur, navngiving og hvordan teamet samarbeider.

---

## DevOps, CI og CD

DevOps er en kultur og praksis som kobler utvikling og drift tettere sammen for å muliggjøre rask, stabil og sikker levering. Jeg ville sagt at Agile ofte fokuserer mest på hvordan vi utvikler, mens DevOps utvider dette til også å omfatte bygg, test, deployment, drift og overvåking. CI betyr at kode integreres hyppig og testes automatisk. CD betyr at programvare kan leveres eller deployes automatisk videre i pipelinen. Dette henger tett sammen med automatisert testing, små endringer, regresjonstesting og deployment-arkitektur som containere og Kubernetes. I praksis betyr det at en liten kodeendring kan pushes, bygges, testes og rulles ut på en kontrollert måte med rask feedback.

---

## Testing som helhet

Testing handler både om verifisering og validering. Verifisering betyr at vi sjekker om systemet er bygget riktig, mens validering handler om om vi bygger riktig system. Jeg ville sagt at testing finnes på flere nivåer: enhetstesting, integrasjonstesting, systemtesting og akseptansetesting. Disse nivåene dekker ulike risikoer. Enhetstesting sjekker små isolerte deler, integrasjonstesting ser på samspill, systemtesting vurderer hele systemet, og akseptansetesting vurderer om løsningen oppfyller bruker- eller kundekrav. Dette henger tett sammen med arkitektur, fordi god lagdeling og løs kobling gjør det lettere å teste. Det henger også sammen med smidig utvikling og DevOps, fordi automatiserte tester og CI gjør det mulig å få rask og kontinuerlig feedback.

---

## Mocking, testdata og testfaser

Mocking brukes når vi vil erstatte ekte avhengigheter med kontrollerte testobjekter, slik at vi kan teste én del isolert og deterministisk. Dette er tett koblet til dependency injection og TDD. Testdata brukes for å gi forutsigbare og repeterbare testforhold, slik at testene faktisk sier noe pålitelig. Testfaser som oppsett, gjennomføring, verifisering og opprydding beskriver strukturen i en test. Jeg ville forklart at disse tre temaene sammen handler om testbarhet og kvalitet i selve testarbeidet. Hvis vi ikke har stabile testdata og kontrollerte avhengigheter, får vi skjøre tester som er vanskelige å stole på.

---

## GDPR og profesjonsetikk

GDPR handler om regler for behandling av personopplysninger, men i systemutvikling må dette forstås som noe som påvirker design og arkitektur, ikke bare juridikk. Dataminimering, sikkerhet, innsyn og sletting må bygges inn i systemet. Profesjonsetikk går enda bredere og handler om utviklerens ansvar for konsekvensene av teknologien. Jeg ville forklart at dette henger tett sammen med kvalitet: et system som krenker personvern, diskriminerer brukere eller er farlig i bruk, er ikke et godt system selv om det fungerer teknisk. Derfor må etikk og juss ses som en del av god systemutvikling, ikke noe som kommer i tillegg etterpå.

---

## Prosjektplanlegging og risiko

Prosjektplanlegging handler om å skape retning og struktur, mens risikoanalyse handler om å identifisere hva som kan gå galt og prioritere tiltak. Jeg ville forklart at nesten hele pensum egentlig kan ses som ulike former for risikoreduksjon. Prototyper reduserer risiko for feil løsning. UML reduserer risiko for misforståelser. Arkitektur reduserer risiko for teknisk kaos. Testing reduserer risiko for feil i produksjon. DevOps reduserer risiko ved leveranse. Risikoanalyse og risk poker hjelper teamet å prioritere innsats der konsekvensene er størst.

---

# Del 3: “Hvis du får spørsmål om X, koble det til Y og Z”-oversikt for rask pugging

Dette er laget for muntlig og skriftlig eksamen, så du raskt kan utvide svarene dine.

---

## MMI / interaksjonsdesign
**Hvis du får spørsmål om interaksjonsdesign, koble det til:**
- **prototyping**, fordi design må konkretiseres
- **evaluering/brukertesting**, fordi design må prøves ut
- **Normans prinsipper**, fordi de gir språk for god brukskvalitet
- **universell utforming/WCAG**, fordi godt design også må være tilgjengelig

**Eksempelsetning:**  
“Interaksjonsdesign handler ikke bare om layout, men om hvordan brukeren opplever samspillet, og derfor henger det tett sammen med prototyping, evaluering og universell utforming.”

---

## Prototyping
**Koble til:**
- interaksjonsdesign
- evaluering
- brukertesting
- smidig/iterativ utvikling

**Eksempelsetning:**  
“Prototyper brukes for å teste designhypoteser tidlig, og er derfor tett koblet til både brukertesting og smidige iterasjoner.”

---

## Evaluering
**Koble til:**
- testing vs evaluering
- brukertesting
- heuristisk evaluering
- validering

**Eksempelsetning:**  
“Evaluering er bredere enn testing fordi det handler om å vurdere om løsningen er nyttig og brukbar, ikke bare om den er feilfri.”

---

## Brukertesting
**Koble til:**
- prototyper
- evaluering
- MMI
- usability

**Eksempelsetning:**  
“Brukertesting er en evalueringsmetode der vi observerer om brukeren faktisk klarer oppgaver i løsningen.”

---

## Universell utforming
**Koble til:**
- WCAG
- lovkrav
- MMI
- profesjonsetikk

**Eksempelsetning:**  
“Universell utforming er både et kvalitetsmål, et inkluderingsmål og i mange tilfeller et lovkrav.”

---

## WCAG
**Koble til:**
- universell utforming
- testing
- lov/forskrift
- konkrete designvalg

**Eksempelsetning:**  
“WCAG gjør universell utforming konkret gjennom testbare kriterier som kontrast, tastaturnavigasjon og alternativ tekst.”

---

## Use case
**Koble til:**
- brukerhistorier
- sekvensdiagram
- akseptansetesting
- funksjonelle krav

**Eksempelsetning:**  
“Use case beskriver hvordan en aktør oppnår et mål i systemet, og kan brukes som grunnlag for både sekvensdiagram og testscenarioer.”

---

## Domenemodell
**Koble til:**
- DDD
- klassediagram
- felles språk
- kravforståelse

**Eksempelsetning:**  
“Domenemodellen hjelper teamet å forstå hvilke begreper som er sentrale i problemdomenet, og den legger grunnlaget for videre design.”

---

## Sekvensdiagram
**Koble til:**
- use case
- klassediagram
- arkitektur
- ansvar mellom komponenter

**Eksempelsetning:**  
“Sekvensdiagram viser hvordan delene samarbeider over tid for å realisere et use case.”

---

## Klassediagram
**Koble til:**
- domenemodell
- objektorientering
- testbarhet
- sekvensdiagram

**Eksempelsetning:**  
“Klassediagrammet viser den statiske strukturen, mens sekvensdiagrammet viser hvordan denne strukturen brukes i praksis.”

---

## Tilstandsmaskindiagram
**Koble til:**
- domenelogikk
- sekvensdiagram
- use case
- objekters livsløp

**Eksempelsetning:**  
“Tilstandsmaskindiagram er særlig nyttig når et objekt har tydelige livsfaser, som en ordre eller en timeavtale.”

---

## Programvarearkitektur
**Koble til:**
- kompleksitetshåndtering
- testing
- deployment
- kvalitetskrav

**Eksempelsetning:**  
“Arkitektur handler om å organisere systemet slik at det møter kvalitetskrav som vedlikeholdbarhet, testbarhet og skalerbarhet.”

---

## Trelagsarkitektur
**Koble til:**
- klient-tjener
- MVC
- testing
- lav kobling

**Eksempelsetning:**  
“Ved å skille presentasjon, forretningslogikk og data blir systemet lettere å forstå, teste og vedlikeholde.”

---

## Monolitt
**Koble til:**
- enkel oppstart
- enklere debugging
- svakere skalering
- alternativ til mikrotjenester

**Eksempelsetning:**  
“Monolitt er ofte et godt startpunkt fordi løsningen er enklere å utvikle og drifte før kompleksiteten blir for stor.”

---

## Mikrotjenester
**Koble til:**
- DevOps
- CI/CD
- distribuerte systemer
- event-bus eller REST

**Eksempelsetning:**  
“Mikrotjenester gir uavhengig deploy og skalering, men øker kompleksiteten i drift, testing og observability.”

---

## MVC
**Koble til:**
- UI-struktur
- trelagsarkitektur
- interaktive apper
- separasjon av ansvar

**Eksempelsetning:**  
“MVC er et mønster for å strukturere interaktive applikasjoner slik at presentasjon og logikk ikke blandes unødvendig.”

---

## Scrum
**Koble til:**
- backlog
- brukerhistorier
- sprint review
- retrospektiv

**Eksempelsetning:**  
“Scrum organiserer smidig arbeid i sprinter, og bruker seremonier for å planlegge, følge opp, evaluere og forbedre.”

---

## Kanban
**Koble til:**
- flyt
- WIP-begrensning
- DevOps
- flaskehalser

**Eksempelsetning:**  
“Kanban fokuserer på kontinuerlig flyt og gjør flaskehalser synlige gjennom tavlen og begrensning av arbeid i prosess.”

---

## XP
**Koble til:**
- TDD
- parprogrammering
- refaktorering
- feedback

**Eksempelsetning:**  
“XP er en smidig tilnærming som konkretiserer hvordan teamet jobber teknisk for å sikre kvalitet og rask feedback.”

---

## TDD
**Koble til:**
- enhetstesting
- mocking
- dependency injection
- refaktorering

**Eksempelsetning:**  
“TDD fremmer testbar kode og korte feedback-looper ved at testen skrives før implementasjonen.”

---

## BDD
**Koble til:**
- brukerhistorier
- akseptansetesting
- Gherkin
- kunde/forretning

**Eksempelsetning:**  
“BDD gjør krav mer testbare og forståelige ved å uttrykke systemets atferd i et språk både tekniske og ikke-tekniske kan lese.”

---

## DevOps
**Koble til:**
- CI/CD
- automatiserte tester
- containere
- monitorering

**Eksempelsetning:**  
“DevOps kobler utvikling og drift for å gjøre leveranser raskere, tryggere og mer automatiserte.”

---

## Testing generelt
**Koble til:**
- verifisering vs validering
- testnivåer
- automasjon
- risiko

**Eksempelsetning:**  
“Testing handler både om å sjekke at systemet er bygget riktig, og om å vurdere om vi har bygget riktig system.”

---

## Enhetstesting
**Koble til:**
- TDD
- mocking
- DI
- byggeprosess

**Eksempelsetning:**  
“Enhetstesting fokuserer på små isolerte deler og er ofte første forsvarslinje mot feil.”

---

## Integrasjonstesting
**Koble til:**
- API
- databaser
- tjenestesamspill
- arkitektur

**Eksempelsetning:**  
“Integrasjonstesting avdekker feil som ikke vises når delene testes isolert.”

---

## Akseptansetesting
**Koble til:**
- BDD
- kunde
- brukerhistorier
- validering

**Eksempelsetning:**  
“Akseptansetesting vurderer om løsningen faktisk oppfyller behovene og kravene som er avtalt.”

---

## Regresjonstesting
**Koble til:**
- CI
- automatiserte tester
- små endringer
- trygg videreutvikling

**Eksempelsetning:**  
“Regresjonstesting sikrer at eksisterende funksjonalitet ikke blir ødelagt når vi gjør endringer.”

---

## Mocking
**Koble til:**
- enhetstesting
- dependency injection
- determinisme
- testbar arkitektur

**Eksempelsetning:**  
“Mocking gjør det mulig å teste én del isolert ved å kontrollere responsen fra avhengigheter.”

---

## GDPR
**Koble til:**
- sikkerhet
- arkitektur
- profesjonsetikk
- krav

**Eksempelsetning:**  
“GDPR påvirker ikke bare jussen rundt systemet, men også hvordan vi designer datalagring, tilgang og sletting.”

---

## Profesjonsetikk
**Koble til:**
- GDPR
- universell utforming
- sikkerhet
- kvalitet

**Eksempelsetning:**  
“Profesjonsetikk handler om at utviklere må ta ansvar for konsekvensene av teknologien de lager, ikke bare den tekniske funksjonen.”

---

## Risikoanalyse
**Koble til:**
- testprioritering
- prosjektplanlegging
- arkitekturvalg
- risk poker

**Eksempelsetning:**  
“Risikoanalyse hjelper teamet å prioritere innsats der sannsynlighet og konsekvens er størst.”

---

# Hvordan bruke dette smartest

Jeg anbefaler at du pugger i denne rekkefølgen:

1. **Lær hovedkjeden:**  
   brukerbehov → krav → modellering → arkitektur → implementasjon → testing → drift/evaluering

2. **Lær koblingsord:**  
   “Dette henger sammen med …”, “Dette brukes som grunnlag for …”, “Dette påvirker …”

3. **Lær 1 eksempel per hovedtema**, for eksempel:
   - nettbutikk
   - timebestilling
   - innlogging
   - ordrebehandling

4. **Svar aldri isolert på eksamen** hvis du kan unngå det.  
   Koble alltid minst 2–3 temaer sammen.

---

Hvis du vil, kan jeg som neste steg lage enten:

1. **en kompakt 2-siders puggeversjon** av alt over,  
2. **en stor quiz med muntlige eksamensspørsmål og modell-svar**, eller  
3. **en “falske venner og vanlige feil” oversikt** over begreper som lett blandes, som evaluering vs testing, use case vs brukerhistorie, monolitt vs mikrotjenester, Scrum vs Kanban, og verifisering vs validering.

## @real-eo

samle alle prinsipper, faser, dimensjoner, ulemper, fordeler, regler, o.l som består av oppramsbare elementer; altså - ting som er fastslått og må pugges til en .md fil, slik at jeg kan lage flashcards automatisk

## Copilot

```markdown name=flashcards-oppramsing.md
# IDATT1005 – Oppramsbare elementer for flashcards

Denne filen samler **prinsipper, faser, dimensjoner, regler, seremonier, nivåer, typer, fordeler/ulemper og andre oppramsbare elementer** fra pensum, formulert så konsist og presist som mulig for automatiske flashcards.

---

## Interaksjonsdesign

### Prosess for interaksjonsdesign
1. Definer krav
2. Design alternativer
3. Lag prototype
4. Evaluer

### De fem dimensjonene i interaksjonsdesign
1. Ord
2. Visuelle representasjoner
3. Fysiske objekter og rom
4. Tid
5. Atferd

### Don Normans prinsipper
1. Synlighet
2. Feedback
3. Begrensninger
4. Avbilding (mapping)
5. Konsistens
6. Tilbydelser / affordances

---

## Prototyping

### Dimensjoner ved prototyping
1. Utseende
2. Innhold
3. Funksjonalitet
4. Interaktivitet
5. Romlig struktur

### Klasser av prototyping
- Horisontal prototype
- Vertikal prototype

### Aspekter ved utvikling av prototyper
- Evolusjonær prototype
- Bruk-og-kast-prototype
- Lavoppløselig prototype
- Høyoppløselig prototype

---

## Evaluering

### Forskjell: testing vs evaluering
- Testing: verifisering – bygger vi produktet riktig?
- Evaluering: validering – bygger vi riktig produkt?

### Evalueringsformer
- Formativ evaluering
- Summativ evaluering

### Evaluering som involverer brukere
- Brukertest
- A/B-test
- Feltstudie
- Opportunistisk evaluering

### Evaluering som ikke involverer brukere
- Heuristisk gjennomgang
- Prediktive modeller

### Evaluering som kan involvere både eksperter og brukere
- Pluralistisk gjennomgang

### Evalueringsmetoder
- Observasjon
- Spørre brukere
- Direkte testing
- Spørre eksperter
- Modellering

### Evalueringsteknikker / hva man kan teste
- Kodevalidering
- Testing i ulike nettlesere og på ulike plattformer
- Testing av fleksibiliteten til et design
- Testing av grad av universell utforming / brukskvalitet
- Testing av feilmeldinger

---

## Brukertesting

### Kjennetegn ved god brukertesting
- Konkret hensikt
- Avgrenset formål
- Realistiske oppgaver
- Observasjon av brukeren

---

## Universell utforming

### Prinsipper for universell utforming
1. Enkel og intuitiv i bruk
2. Forståelig informasjon
3. Toleranse for feil
4. Like muligheter for alle
5. Fleksibel i bruk
6. Lav fysisk anstrengelse
7. Størrelse og plass for tilgang og bruk

### Hva “størrelse og plass for tilgang og bruk” skal muliggjøre
1. Tilgang
2. Rekkevidde
3. Betjening og bruk

### Gode argumenter for universell utforming
- Mer inkluderende
- Enklere å bruke
- Mer mobiltilpasset
- Mer synlig for Google / bedre SEO
- Mer lønnsomt

---

## WCAG

### De fire prinsippene i WCAG
1. Mulig å oppfatte (Perceivable)
2. Mulig å betjene (Operable)
3. Forståelig (Understandable)
4. Robust (Robust)

### Eksempler på krav i WCAG
- Innhold skal være tilgjengelig via tastatur
- Bilder skal ha alternativ tekst
- Video skal ha teksting eller alternativ lyd
- Skjema og formater skal være lette å forstå
- Innhold skal være lett å forstå

---

## UML

### Vanlige UML-modeller / diagramtyper i pensum
- Use case-diagram
- Domenemodell
- Sekvensdiagram
- Aktivitetsdiagram
- Klassediagram
- Pakkediagram
- Tilstandsmaskindiagram

### Elementer i sekvensdiagram
- Deltakere
- Meldinger / funksjonskall
- Levetidslinje
- Aktiveringsboks
- Rammer (f.eks. løkke/alt)

### Elementer i aktivitetsdiagram
- Aksjoner
- Initial node
- Final node
- Decision node
- Fork node
- Join node
- Merge node
- Overganger / piler

### Elementer i klassediagram
- Klasse
- Attributter
- Metoder

### Relasjoner i klassediagram
- Avhengighet (dependency)
- Assosiasjon
- Aggregering
- Komposisjon
- Arv / generalisering
- Realisering

### Hovedelementer i tilstandsmaskindiagram
- Starttilstand
- Sluttilstand
- Tilstander
- Overganger
- Triggere / hendelser

---

## Brukerhistorier

### Standardformat for brukerhistorier
- Som [rolle]
- vil jeg [mål/ønske]
- slik at [nytte/verdi]

---

## Programvarearkitektur

### Hvorfor programvarearkitektur er viktig
- Forstå systemet tidlig
- Redusere kostnader
- Unngå duplisering av ressurser
- Øke kvalitet
- Hjelpe risikostyring
- Støtte kommunikasjon mellom interessenter
- Gi retningslinjer for utviklere

### Kompleksitetshåndtering
- Splitt og hersk
- Lav kobling
- Mer testbar kode
- Mer robust kode
- Enklere delegering av ansvar

---

## Trelagsarkitektur

### De tre lagene
1. Presentasjonslag
2. Forretningslogikklag
3. Data access-lag

### Hovedidé i lagdeling
- Hvert lag har spesifikt ansvar
- Hvert lag yter tjenester til laget over / bruker laget under
- Gir lav kobling

---

## Master-slave pattern

### Hoveddeler
- Master
- Slaver

### Fordeler
- Tydelig oversikt i master
- Slavene kan enhetstestes separat
- Master kan integrasjonstestes mot slavene

---

## Event-bus pattern

### Fire hovedkomponenter
1. Event listener
2. Event source
3. Channel
4. Event bus

---

## MVC

### Tre deler i MVC
1. Model
2. View
3. Controller

### Fordeler
- Høyere kohesjon
- Gjenbrukbarhet
- Skiller ansvar

---

## Mikrotjenester

### Mikrotjenester er basert på
- Single Responsibility Principle

### Kjennetegn
- Selvstendige tjenester
- Én hovedoppgave per tjeneste
- Egen data
- Eget kjøremiljø

### Fordeler
- Skalerbart
- Modulært
- Fleksibel teknologibruk
- Høy tilgjengelighet / feil isoleres
- Støtter kontinuerlig levering (CI/CD)
- Passer DevOps

### Ulemper
- Kompleks debugging
- Kompleks logging på tvers av tjenester
- Krever automatisering
- Vanskelig å teste distribuerte systemer
- Datainkonsistens kan oppstå
- Økt ressursforbruk

---

## Monolittarkitektur

### Fordeler
- God gjennomstrømning / lite overhead
- Enklere å teste og debugge i starten

### Ulemper
- Vanskeligere å vedlikeholde ved vekst
- Lite skalerbar
- Lite utvidbar sammenlignet med modulære løsninger
- Tett koblet
- Feil i én del kan stoppe hele systemet

---

## Plugin-basert arkitektur

### Hoveddeler
- Kjerne-system
- Plugin-moduler / extensions

### Fordeler
- Lav kobling
- Høy isolasjon mellom funksjoner
- Fleksibelt
- Utvidbart

### Ulemper
- Endringer i kjernen kan ødelegge plugins
- Mange plugins kan redusere ytelsen
- Kompleks testing av hele systemet

### Eksempler
- Chrome Web Store
- IntelliJ
- VS Code
- Eclipse

---

## Deployment-arkitekturer

### Tradisjonell deployment
- Applikasjoner kjøres direkte på fysiske servere

### Utfordringer ved tradisjonell deployment
- Ressursallokering kan bli ineffektiv
- Én applikasjon kan ta for mye kapasitet

### Virtualisering (VMs)
- Flere virtuelle maskiner på én fysisk server
- Hver VM har eget operativsystem

### Ulempe ved virtualisering
- Ressurser reserveres selv om de ikke brukes

### Container-deployment
- Containere deler OS, men er isolerte
- Lettere enn virtuelle maskiner

### Nøkkelteknologier i container-deployment
- Docker
- Kubernetes

### Fordeler med containere
- Enkel distribusjon
- Konsistent kjøremiljø
- Løst koblet
- Distribuert
- Elastisk

---

## Systemutviklingsmetodikk

### Før smidige metoder
- Vannfallsmodellen
- Unified Process (UP)

### Grunnleggende prinsipper i smidig metode
1. Problem based
2. Collaborative
3. Iterativ
4. Adaptiv

### Agile Manifesto – fire hovedverdier
1. Individer og interaksjoner fremfor prosesser og verktøy
2. Fungerende programvare fremfor omfattende dokumentasjon
3. Kundesamarbeid fremfor kontraktsforhandlinger
4. Reagere på endring fremfor å følge en plan

---

## Extreme Programming (XP)

### Kjennetegn
- Lite dokumentasjon
- Lite modellering
- Tett feedback-loop
- Kort iterasjonstid

### Antall faste regler i XP
- 29 regler

### Eksempler på XP-regler
- Parprogrammering
- Skriv enhetstester før kode
- Integrer én liten endring av gangen
- Enkel og tydelig kode
- Hyppig refaktorering
- Korte feedback-looper
- Hyppige tester
- Hyppige leveranser

### Fem sentrale verdier i XP
1. Communication
2. Simplicity
3. Feedback
4. Courage
5. Respect

---

## Test-Driven Development (TDD)

### Grunnidé
1. Skriv test først
2. Kjør testen og se at den feiler
3. Skriv kode som får testen til å bestå
4. Refaktorer

### Fokus i TDD
- Primært enhetstesting
- Noen ganger integrasjonstesting
- Sjelden systemtesting

### Fordeler
- Bedre kodekvalitet
- Høyere testdekning
- Rask tilbakemelding
- Økt tillit
- Testene fungerer som dokumentasjon

### Ulemper
- Lærekurve
- Tidsbruk til å skrive tester
- Vedlikehold av tester

---

## Behavior-Driven Development (BDD)

### Hovedidé
- Kobler forretningsmål og teknologi
- Beskriver systematferd fra brukerens perspektiv
- Bruker naturlig språk

### Given-When-Then-formatet
1. Given (Gitt) – starttilstand / kontekst
2. When (Når) – handling / hendelse
3. Then (Så) – forventet resultat

### Nøkkelelementer i Gherkin
- Feature
- Scenario
- Given
- When
- Then
- And

### Hva BDD bidrar til
- Tydeligere akseptkriterier
- Felles forståelse mellom forretning og utvikling
- Testbar spesifikasjon
- Høyere fokus på brukerens perspektiv

---

## Scrum

### Hva Scrum er
- Tidsboksbasert smidig rammeverk

### Fokus i Scrum
- Kryssfunksjonelle team
- Sprinter
- Inkrementell fremgang

### Scrum-seremonier
1. Sprint planning
2. Daily standup / daily scrum
3. Sprint review
4. Retrospektiv

### Typiske artefakter / objekter i Scrum
- Product backlog
- Sprint backlog
- Product backlog items (PBI)
- Scrum board

---

## Lean

### Lean-prinsipper
1. Eliminate waste
2. Build quality in
3. Create knowledge
4. Defer commitment
5. Deliver fast
6. Respect people
7. Optimize the whole

---

## Kanban

### Kjennetegn
- Flytbasert
- Kontinuerlig levering
- Ingen faste iterasjoner
- Visuell styring

### Viktige elementer
- Kanban-board
- Begrensning av arbeid i prosess (WIP)
- Fokus på flaskehalser

### Formål med WIP-begrensning
- Synliggjøre flaskehalser
- Forbedre flyt
- Hjelpe teammedlemmer å bidra der det stopper opp

---

## Domain-Driven Design (DDD)

### Kjennetegn
- Høyt fokus på domenet
- Koden skal gjenspeile virkeligheten
- Egnet for skalering og endring
- Fokus på det viktigste i domenet

---

## DevOps

### Hva DevOps kombinerer
- Utvikling (Dev)
- Drift (Ops)

### DevOps skal sikre
- Kontinuerlig integrasjon
- Kontinuerlig levering / deploy
- Tettere samarbeid mellom utvikling og drift

### CI (Continuous Integration)
- Hyppig integrasjon til felles gren
- Automatisk bygging
- Automatisk testing

### CD (Continuous Delivery / Deployment)
- Automatisk levering / deploy av kodeendringer

### DevOps-verktøy i pensum
- GitLab / GitHub
- Jira / Confluence
- Maven
- Gradle
- Jenkins
- JUnit
- Selenium
- Kubernetes
- Helm
- Docker
- Kibana
- Grafana

---

## REST

### REST-prinsipper i pensum
- Klient-tjener
- Ressurser identifiseres via URI-er
- Ressurser manipuleres via HTTP-metoder

### HTTP-metoder i pensum
- GET
- POST
- PUT
- DELETE

---

## Testing

### Hvorfor teste
- Sikre riktig respons ved input/interaksjon
- Finne bugs
- Verifisere ytelse under edge cases
- Vurdere brukervennlighet
- Kontrollere at krav er oppfylt
- Kontrollere at systemet kan installeres i riktig miljø
- Kontrollere at systemet tåler endringer

### Testing principles
1. Testing shows the presence of defects
2. Exhaustive testing is impossible
3. Early testing
4. Defects clustering
5. Pesticide paradox
6. Testing is context dependent
7. Absence of error fallacy

### Tradisjonell testing
- Utvikling og testing skjer separat
- QA-team kvalitetssikrer etter utvikling

### Ulempe ved tradisjonell testing
- Mye tid går til kommunikasjon og overlevering

### Smidig testing
- Utviklere tester egen kode kontinuerlig
- Små inkrementer
- Automatiserte tester brukes mye

### Fordeler ved smidig testing
- Raskere feedback
- Tettere kobling mellom utvikling og kvalitet
- QA kan fokusere på viktige scenarioer

---

## Automatiserte tester

### Når de ofte kjøres
- Ved opprettelse av pull request
- I CI-pipelines
- Ved nye kodeendringer

### Kjennetegn
- Enhetstester og integrasjonstester kjøres automatisk
- Resultater rapporteres raskt

### Fordeler
- Rask feedback
- Høy hastighet
- Kontinuerlig kontroll
- Forutsigbar kvalitet
- Kostnadsbesparende over tid

### Ulemper / utfordringer
- Høy oppstarts- og vedlikeholdskostnad
- Krever riktig fokus og god testdesign

---

## Egne test-/staging-miljøer

### Kjennetegn
- Testmiljø speiler produksjonsmiljø
- Hele applikasjonen kan testes før release

### Fordeler
- Mer realistisk testing
- QA kan teste hele applikasjonen
- Infrastructure as Code gjør oppsett enklere

---

## CI og små endringer

### Fordeler
- Mindre diff mellom gammel og ny versjon
- Enklere isolering av feil
- Enklere sporing av endringer
- Lavere sannsynlighet for feil
- Enklere rollback

---

## Prioritering av testing

### Viktige prinsipper
- Finn riktig nivå på testdekning basert på risiko
- Prioriter tester som gir størst verdi
- Prioriter tester som reduserer mest usikkerhet

---

## Risk poker

### Hva man vurderer
- Risiko
- Konsekvens
- Risikofaktorer

### Fordeler
- Hele teamet deltar
- Bedre treffsikkerhet
- Felles forståelse av risiko

---

## Testdata

### Egenskaper ved gode testdata
- Samme data hver gang
- Deterministisk prosess
- Forutsigbart testmiljø

### Fordeler
- Enklere å isolere feil
- Mer presise testresultater
- Bedre analyse av testutfall

---

## Mocking

### Hva mocking brukes til
- Erstatte ekte og komplekse avhengigheter
- Isolere klasser / moduler i test

### Typiske avhengigheter som kan mocket
- Database
- Eksternt API
- Betalingstjeneste

### Hva som gjør mocking ideelt
- Deterministiske svar
- Samme grensesnitt som ekte avhengighet
- Kombineres godt med dependency injection

### Fordeler
- Muliggjør isolert testing
- Gjør automatiserte tester mulige i flere situasjoner
- Gir kontroll over testmiljøet

---

## Testfaser

### Faser i en test
1. Oppsett
2. Gjennomføring
3. Verifisering
4. Opprydding

---

## Enhetstesting

### Kjennetegn
- Tester individuelle klasser / funksjoner
- Fokus på små enheter
- Ofte utviklers ansvar

### Fordeler
- Automatisert
- Repeterbar
- Kjøres i byggeprosessen

### Mål
- Finne feil tidlig
- Stoppe feil før integrasjon med andre deler

---

## Integrasjonstesting

### Kjennetegn
- Tester samspill mellom komponenter
- Bygger på at delene allerede er testet individuelt

### Mål
- Oppdage feil i grensesnitt og samhandling

### Valg
- Kan automatiseres
- Bør automatiseres der det er hensiktsmessig

---

## Systemtesting

### Kjennetegn
- Tester hele systemet
- Sjekker at alle deler fungerer sammen

### Fordeler
- Finner feil mellom deler av systemet
- Gir trygghet før levering

### Mål
- Sjekke at systemet oppfyller krav
- Finne feil før bruk

### Valg
- Kan utføres med verktøy som Selenium
- Kan være vanskelig å gjøre helt repeterbar

---

## Akseptansetesting

### Kjennetegn
- Type systemtesting
- Utføres for å verifisere at krav er oppfylt

### Viktig i BDD
- Bygger på user stories
- Kan utvikles sammen med kunden

### Kan være
- Manuell
- Automatisert

---

## Regresjonstesting

### Hva det er
- Tester at endringer ikke ødelegger eksisterende funksjonalitet

### Når det skjer
- Før og etter endringer
- Kontinuerlig i CI ved innsjekk av kode

### Hvilke nivåer det kan finnes på
- Enhetstestnivå
- Integrasjonsnivå
- Akseptansenivå

### Valg
- Egner seg godt for automatisering

---

## Smoke-testing og sanity-testing

### Smoke-testing
- Tester kritisk funksjonalitet
- Rask sjekk av om systemet “i det hele tatt fungerer”

### Sanity-testing
- Tester ny eller endret funksjonalitet
- Rask sjekk av om en spesifikk endring virker fornuftig

### Hvorfor de er nyttige
- Avdekker tidlig om videre testing er hensiktsmessig

---

## Destruktiv testing og utforskende testing

### Destruktiv testing
- Kreativ testing for å få systemet til å feile
- Kan ikke automatiseres
- Krever menneskelig erfaring og kreativitet

### Utforskende testing
- Tester med aktiv læring og utforsking underveis
- Bygger på innsikt i systemet og nye hypoteser

### Forskjell
- Destruktiv testing: fokus på å bryte systemet
- Utforskende testing: bredere utforsking og læring

---

## Usabilitytesting

### Hva det tester
- Brukervennlighet
- GUI
- Om brukeren / kunden er fornøyd

---

## Ytelsestesting

### Hva ytelsestesting undersøker
- Hvor mye last systemet tåler
- Hvor mye plutselig last systemet tåler
- Ytelse over tid
- Lekkasjer / ressursproblemer

### Hvordan ytelse måles
- Antall samtidige brukere
- Transaksjoner per tidsenhet
- Throughput
- Responstid

### Hva flaskehalser er
- Systemets svakeste / tregeste punkt
- Det som begrenser total ytelse

### Vanlige årsaker til flaskehalser
- CPU
- Minne
- Tråder
- Databasetilkobling

### Typer ytelsestester
1. Lasttest
2. Stresstest
3. Spike-test
4. Utholdenhetstest

---

## Black-box og white-box testing

### Black-box testing
- Ingen innsikt i intern kode
- Bygger på krav, spesifikasjoner og forventet oppførsel

### White-box testing
- Full innsikt i intern kode og struktur
- Tester intern logikk og oppbygning

---

## Automatisk vs manuell testing

### Fordeler ved automatiske tester
- Raske
- Nøyaktige
- Repeterbare
- Gode for kjente forventninger

### Typiske automatiserte tester
- Enhetstester
- Regresjonstester
- Mange integrasjonstester
- Mange ytelsestester

### Ulemper ved automatiske tester
- Krever vedlikehold
- Fanger ikke alt
- Dårligere på kreative og uventede problemer

### Fordeler ved manuelle tester
- Kreative
- Fanger ofte naturlige brukerfeil og uventede problemer
- Gode for utforsking og opplevelse

### Typiske manuelle tester
- Utforskende testing
- Destruktiv testing
- Mye usabilitytesting

### Testtyper som kan være både manuelle og automatiske
- Smoke-testing
- Sanity-testing
- Integrasjonstesting
- Systemtesting
- Akseptansetesting
- Ytelsestesting

---

## GDPR

### Grunnleggende prinsipper i GDPR
1. Lovlighet, rimelighet og gjennomsiktighet
2. Formålsbegrensning
3. Dataminimering
4. Riktighet
5. Lagringsbegrensning
6. Integritet og konfidensialitet
7. Ansvarliggjøring

### De registrertes rettigheter
1. Rett til informasjon
2. Rett til innsyn
3. Rett til retting
4. Rett til sletting
5. Rett til begrensning
6. Rett til å protestere
7. Rett til dataportabilitet

### Typiske unntak / begrensninger
- Juridisk forpliktelse
- Offentlig sikkerhet
- Forskning

---

## Profesjonsetikk

### Ingeniørens ansvar omfatter blant annet
- Sosialt ansvar
- Sikkerhet og pålitelighet
- Brukeres velferd
- AI og militær bruk / alvorlige konsekvenser av teknologi

### Eksempler på NITO-prinsipper i pensum
- Vise respekt for kolleger
- Vedkjenne seg faglig ansvar
- Følge anerkjente kvalitetsnormer
- Bidra til åpenhet om teknologiske konsekvenser

### IEEE/ACM Code of Ethics – hovedområder
1. Samfunn
2. Kunde og arbeidsgiver
3. Produkt
4. Vurdering
5. Ledelse
6. Profesjon
7. Kolleger
8. Egen utvikling / livslang læring

### Nøkkelprinsipper i profesjonsetikken
- Ærlighet og integritet
- Respekt for personvern
- Kvalitetsbevissthet
- Ansvar for konsekvenser
- Kontinuerlig vurdering

### Hvorfor profesjonsetikk henger sammen med kvalitet
- Mer robuste systemer
- Færre sikkerhets- og personvernbrudd
- Høyere brukertilfredshet
- Beskytter omdømme
- Reduserer risiko for bias og tillitsbrudd

---

## Prosjektplanlegging

### Visjonsdokument – hva det typisk inneholder
- Formål
- Omfang
- Hensikt
- Målgruppe
- Funksjonelle krav
- Ikke-funksjonelle krav
- Interessenter
- Brukerbehov

### Risikoanalyse – hva den brukes til
- Identifisere risiko
- Prioritere risiko
- Definere tiltak
- Forbedre beslutningsprosesser
- Øke prosjektets robusthet

---
```

Hvis du vil, kan jeg også gjøre dette i ett av disse formatene for enklere automatisk flashcard-generering:

1. **CSV-format** med `front,back`  
2. **ren Q/A-markdown**  
3. **Anki-style** med én seksjon per korttype  
4. **tabellformat** med `begrep | oppramsing | kategori`

## @real-eo

Bra. Ikke gjør det du foreslo, det du kom frem med er mer enn godt nok, men alle begreper o.l (ting som står alene) som er fagbegrep/fagkunnskap MÅ ha en forklaring også

## Copilot

```markdown name=flashcards-oppramsing-med-forklaringer.md
# IDATT1005 – Oppramsbare elementer med forklaringer

Denne filen samler **prinsipper, faser, dimensjoner, regler, seremonier, nivåer, typer, fordeler/ulemper og andre oppramsbare elementer** fra pensum.  
Alle fagbegreper som står alene har fått en **kort forklaring**, slik at innholdet kan brukes til automatiske flashcards.

---

## Interaksjonsdesign

### Prosess for interaksjonsdesign
1. **Definer krav** – avklar brukerbehov, mål og rammer for løsningen.
2. **Design alternativer** – lag flere mulige forslag til hvordan løsningen kan fungere.
3. **Lag prototype** – gjør designet konkret i en enkel eller avansert modell.
4. **Evaluer** – vurder om løsningen fungerer for brukerne og oppfyller kravene.

### De fem dimensjonene i interaksjonsdesign
1. **Ord** – tekst og språk som brukes i grensesnittet.
2. **Visuelle representasjoner** – ikoner, farger, bilder, typografi og andre grafiske elementer.
3. **Fysiske objekter og rom** – den fysiske konteksten eller enheten brukeren samhandler gjennom.
4. **Tid** – hvordan interaksjonen utvikler seg over tid, for eksempel animasjoner, lyd og responstid.
5. **Atferd** – hvordan systemet oppfører seg, og hvilke reaksjoner og opplevelser dette skaper hos brukeren.

### Don Normans prinsipper
1. **Synlighet** – funksjoner og muligheter skal være lette å oppdage.
2. **Feedback** – systemet skal gi tydelig tilbakemelding på hva som skjer.
3. **Begrensninger** – designet bør begrense feil handlinger og lede brukeren riktig.
4. **Avbilding (mapping)** – sammenhengen mellom kontroll og effekt bør være intuitiv.
5. **Konsistens** – like ting bør fungere likt i hele systemet.
6. **Tilbydelser / affordances** – designet skal signalisere hvilke handlinger som er mulige.

---

## Prototyping

### Dimensjoner ved prototyping
1. **Utseende** – hvordan prototypen ser ut visuelt.
2. **Innhold** – hvilken informasjon og hvilke elementer som er med.
3. **Funksjonalitet** – hvilke funksjoner som er simulert eller implementert.
4. **Interaktivitet** – hvor mye brukeren faktisk kan gjøre i prototypen.
5. **Romlig struktur** – hvordan skjermbilder, elementer eller deler av løsningen er organisert.

### Klasser av prototyping
- **Horisontal prototype** – bred prototype med mange funksjonsområder, men lite dybde.
- **Vertikal prototype** – smal prototype som går i detalj og dybde på én funksjon.

### Aspekter ved utvikling av prototyper
- **Evolusjonær prototype** – prototype som videreutvikles til en del av sluttproduktet.
- **Bruk-og-kast-prototype** – prototype som brukes til læring og deretter forkastes.
- **Lavoppløselig prototype** – enkel prototype med lite detalj og lite interaksjon, for eksempel papirskisse.
- **Høyoppløselig prototype** – mer realistisk prototype med mye detalj og ofte mer interaksjon.

---

## Evaluering

### Forskjell: testing vs evaluering
- **Testing** – verifisering av om systemet fungerer teknisk riktig.
- **Evaluering** – vurdering av om løsningen er nyttig, brukbar og riktig for behovet.

### Evalueringsformer
- **Formativ evaluering** – evaluering underveis for å forbedre løsningen mens den utvikles.
- **Summativ evaluering** – evaluering av ferdig løsning for å vurdere sluttresultatet.

### Evaluering som involverer brukere
- **Brukertest** – brukere utfører oppgaver mens man observerer problemer og atferd.
- **A/B-test** – to eller flere varianter sammenlignes for å se hvilken som fungerer best.
- **Feltstudie** – evaluering i brukerens naturlige omgivelser.
- **Opportunistisk evaluering** – rask tilbakemelding fra brukere på en idé eller problemstilling.

### Evaluering som ikke involverer brukere
- **Heuristisk gjennomgang** – eksperter vurderer løsningen ut fra etablerte brukbarhetsprinsipper.
- **Prediktive modeller** – analytiske eller beregnende modeller brukes for å forutsi brukeropplevelse eller ytelse.

### Evaluering som kan involvere både eksperter og brukere
- **Pluralistisk gjennomgang** – brukere, utviklere og eksperter går sammen gjennom scenarioer og vurderer løsningen.

### Evalueringsmetoder
- **Observasjon** – se hvordan brukeren faktisk oppfører seg.
- **Spørre brukere** – samle innsikt gjennom intervju, samtale eller spørreskjema.
- **Direkte testing** – brukeren prøver konkrete oppgaver i løsningen.
- **Spørre eksperter** – hente vurderinger fra fagpersoner.
- **Modellering** – bruke modeller for å analysere eller forutsi bruk.

### Evalueringsteknikker / hva man kan teste
- **Kodevalidering** – sjekk av om kode og struktur følger krav eller standarder.
- **Testing i ulike nettlesere og på ulike plattformer** – sjekk av kompatibilitet på tvers av miljøer.
- **Testing av fleksibiliteten til et design** – vurdering av hvor godt designet fungerer under ulike forhold.
- **Testing av grad av universell utforming / brukskvalitet** – sjekk av tilgjengelighet og brukervennlighet.
- **Testing av feilmeldinger** – vurdering av om feilmeldinger er tydelige og hjelpsomme.

---

## Brukertesting

### Kjennetegn ved god brukertesting
- **Konkret hensikt** – testen skal ha et tydelig mål.
- **Avgrenset formål** – man tester noe spesifikt, ikke “alt på en gang”.
- **Realistiske oppgaver** – oppgavene bør ligne ekte brukssituasjoner.
- **Observasjon av brukeren** – man ser hva brukeren faktisk gjør, ikke bare hva brukeren sier.

---

## Universell utforming

### Prinsipper for universell utforming
1. **Enkel og intuitiv i bruk** – løsningen skal være lett å forstå.
2. **Forståelig informasjon** – nødvendig informasjon skal kommuniseres tydelig.
3. **Toleranse for feil** – designet skal redusere risiko og konsekvenser av feil.
4. **Like muligheter for alle** – løsningen skal kunne brukes av personer med ulike ferdigheter.
5. **Fleksibel i bruk** – løsningen skal støtte ulike preferanser og måter å bruke systemet på.
6. **Lav fysisk anstrengelse** – løsningen skal kunne brukes med minst mulig belastning.
7. **Størrelse og plass for tilgang og bruk** – fysisk og visuell utforming skal støtte tilgang og bruk.

### Hva “størrelse og plass for tilgang og bruk” skal muliggjøre
1. **Tilgang** – brukeren skal kunne nå og oppfatte løsningens elementer.
2. **Rekkevidde** – brukeren skal kunne komme til funksjonene uavhengig av kroppslige forutsetninger.
3. **Betjening og bruk** – løsningens elementer skal kunne brukes praktisk og sikkert.

### Gode argumenter for universell utforming
- **Mer inkluderende** – flere mennesker kan bruke løsningen.
- **Enklere å bruke** – god struktur og navigasjon hjelper alle brukere.
- **Mer mobiltilpasset** – tilgjengelige løsninger fungerer ofte bedre på små skjermer.
- **Mer synlig for Google / bedre SEO** – god struktur og semantikk hjelper søkemotorer.
- **Mer lønnsomt** – flere brukere når fram, og supportbehov kan reduseres.

---

## WCAG

### De fire prinsippene i WCAG
1. **Mulig å oppfatte (Perceivable)** – innhold må kunne oppfattes av brukeren.
2. **Mulig å betjene (Operable)** – grensesnittet må kunne brukes og navigeres.
3. **Forståelig (Understandable)** – innhold og funksjonalitet må være forståelige.
4. **Robust (Robust)** – løsningen må fungere med ulike nettlesere og hjelpemidler.

### Eksempler på krav i WCAG
- **Innhold skal være tilgjengelig via tastatur** – brukeren skal ikke være avhengig av mus.
- **Bilder skal ha alternativ tekst** – skjermlesere må kunne formidle bildeinnhold.
- **Video skal ha teksting eller alternativ lyd** – innholdet må være tilgjengelig ved ulike behov.
- **Skjema og formater skal være lette å forstå** – brukerens oppgaver må være tydelige.
- **Innhold skal være lett å forstå** – språk og struktur må støtte forståelse.

---

## UML

### Vanlige UML-modeller / diagramtyper i pensum
- **Use case-diagram** – viser aktører og hvilke mål eller funksjoner de bruker systemet til.
- **Domenemodell** – viser sentrale begreper i domenet og relasjonene mellom dem.
- **Sekvensdiagram** – viser meldinger og samspill mellom deltakere over tid.
- **Aktivitetsdiagram** – viser flyt av aktiviteter, beslutninger og parallelle handlinger.
- **Klassediagram** – viser klasser, attributter, metoder og relasjoner.
- **Pakkediagram** – viser hvordan elementer grupperes i pakker eller moduler.
- **Tilstandsmaskindiagram** – viser tilstander og overganger for et objekt eller system.

### Elementer i sekvensdiagram
- **Deltakere** – aktører, objekter eller komponenter som deltar i samspillet.
- **Meldinger / funksjonskall** – kommunikasjon mellom deltakerne.
- **Levetidslinje** – stiplet linje som viser deltakerens eksistens over tid.
- **Aktiveringsboks** – viser når en deltaker utfører arbeid.
- **Rammer (f.eks. løkke/alt)** – markerer kontrollstrukturer som valg eller repetisjon.

### Elementer i aktivitetsdiagram
- **Aksjoner** – konkrete handlinger eller steg i en prosess.
- **Initial node** – startpunktet for aktiviteten.
- **Final node** – sluttpunktet for aktiviteten.
- **Decision node** – punkt der prosessen forgrenes ut fra betingelser.
- **Fork node** – deler prosessen i parallelle løp.
- **Join node** – samler parallelle løp igjen.
- **Merge node** – slår sammen alternative flyter.
- **Overganger / piler** – viser rekkefølge og flyt mellom aktiviteter.

### Elementer i klassediagram
- **Klasse** – en type objekt med data og atferd.
- **Attributter** – data som hører til klassen.
- **Metoder** – funksjoner eller operasjoner klassen kan utføre.

### Relasjoner i klassediagram
- **Avhengighet (dependency)** – en svak kobling der én klasse bruker en annen.
- **Assosiasjon** – en strukturell kobling mellom to klasser.
- **Aggregering** – hel-del-relasjon der delen kan eksistere uten helheten.
- **Komposisjon** – sterk hel-del-relasjon der delen hører tett til helheten.
- **Arv / generalisering** – en subklasse arver fra en superklasse.
- **Realisering** – en klasse implementerer et grensesnitt.

### Hovedelementer i tilstandsmaskindiagram
- **Starttilstand** – tilstanden systemet eller objektet starter i.
- **Sluttilstand** – tilstanden der livsløpet avsluttes.
- **Tilstander** – ulike situasjoner objektet kan befinne seg i.
- **Overganger** – bevegelser fra én tilstand til en annen.
- **Triggere / hendelser** – det som utløser en overgang.

---

## Brukerhistorier

### Standardformat for brukerhistorier
- **Som [rolle]** – beskriver hvem brukeren er.
- **vil jeg [mål/ønske]** – beskriver hva brukeren ønsker å gjøre.
- **slik at [nytte/verdi]** – beskriver hvorfor dette er viktig.

---

## Programvarearkitektur

### Hvorfor programvarearkitektur er viktig
- **Forstå systemet tidlig** – gjør det lettere å se helheten før implementasjon.
- **Redusere kostnader** – tidlige gode valg sparer tid og penger senere.
- **Unngå duplisering av ressurser** – tydelig struktur reduserer overlappende løsninger.
- **Øke kvalitet** – bedre struktur gir bedre vedlikeholdbarhet og testbarhet.
- **Hjelpe risikostyring** – man oppdager tekniske utfordringer tidligere.
- **Støtte kommunikasjon mellom interessenter** – gir et felles bilde av systemet.
- **Gi retningslinjer for utviklere** – hjelper teamet å utvikle konsistent.

### Kompleksitetshåndtering
- **Splitt og hersk** – del opp problemet i mindre deler.
- **Lav kobling** – delene bør være minst mulig avhengige av hverandre.
- **Mer testbar kode** – mindre og tydeligere deler er enklere å teste.
- **Mer robust kode** – isolerte deler tåler endringer bedre.
- **Enklere delegering av ansvar** – team kan jobbe med ulike deler parallelt.

---

## Trelagsarkitektur

### De tre lagene
1. **Presentasjonslag** – viser informasjon og håndterer brukerinteraksjon.
2. **Forretningslogikklag** – utfører regler, prosessering og kjernefunksjonalitet.
3. **Data access-lag** – håndterer lagring, henting og oppdatering av data.

### Hovedidé i lagdeling
- **Hvert lag har spesifikt ansvar** – gjør systemet mer oversiktlig.
- **Hvert lag yter tjenester til laget over / bruker laget under** – gir strukturert avhengighet.
- **Gir lav kobling** – endringer i ett lag påvirker ikke nødvendigvis alle andre.

---

## Master-slave pattern

### Hoveddeler
- **Master** – styrer, fordeler arbeid og samler resultater.
- **Slaver** – utfører arbeid delegert av master.

### Fordeler
- **Tydelig oversikt i master** – gir sentral kontroll over prosessen.
- **Slavene kan enhetstestes separat** – hver del kan testes isolert.
- **Master kan integrasjonstestes mot slavene** – samspillet kan testes samlet.

---

## Event-bus pattern

### Fire hovedkomponenter
1. **Event listener** – lytter etter hendelser.
2. **Event source** – produserer eller sender hendelser.
3. **Channel** – kanal eller emne der hendelser publiseres.
4. **Event bus** – infrastrukturen som frakter hendelser mellom kilder og lyttere.

---

## MVC

### Tre deler i MVC
1. **Model** – data og forretningslogikk.
2. **View** – det brukeren ser i grensesnittet.
3. **Controller** – håndterer input og styrer flyten mellom model og view.

### Fordeler
- **Høyere kohesjon** – hver del får tydeligere ansvar.
- **Gjenbrukbarhet** – deler kan lettere brukes på nytt.
- **Skiller ansvar** – gjør systemet enklere å forstå og endre.

---

## Mikrotjenester

### Mikrotjenester er basert på
- **Single Responsibility Principle** – hver tjeneste bør ha ett tydelig hovedansvar.

### Kjennetegn
- **Selvstendige tjenester** – hver tjeneste kan utvikles og driftes separat.
- **Én hovedoppgave per tjeneste** – tydelig ansvarsdeling.
- **Egen data** – tjenesten eier vanligvis sin egen datalagring.
- **Eget kjøremiljø** – tjenesten kan kjøres og deployes uavhengig.

### Fordeler
- **Skalerbart** – tjenester kan skaleres separat.
- **Modulært** – systemet deles i mindre moduler.
- **Fleksibel teknologibruk** – ulike tjenester kan bruke ulik teknologi.
- **Høy tilgjengelighet / feil isoleres** – feil i én tjeneste stopper ikke nødvendigvis hele systemet.
- **Støtter kontinuerlig levering (CI/CD)** – tjenester kan oppdateres uavhengig.
- **Passer DevOps** – tett kobling mellom utvikling, drift og deploy.

### Ulemper
- **Kompleks debugging** – feilsporing på tvers av tjenester er vanskeligere.
- **Kompleks logging på tvers av tjenester** – data om feil og flyt spres i flere systemer.
- **Krever automatisering** – bygg, test og deploy må ofte automatiseres sterkt.
- **Vanskelig å teste distribuerte systemer** – mange avhengigheter og miljøer kompliserer test.
- **Datainkonsistens kan oppstå** – data er fordelt og kan bli ute av synk.
- **Økt ressursforbruk** – mange tjenester krever mer infrastruktur.

---

## Monolittarkitektur

### Fordeler
- **God gjennomstrømning / lite overhead** – mindre kommunikasjon mellom separate tjenester.
- **Enklere å teste og debugge i starten** – alt er samlet i én applikasjon.

### Ulemper
- **Vanskeligere å vedlikeholde ved vekst** – systemet blir tungt å endre når det blir stort.
- **Lite skalerbar** – hele systemet må ofte skaleres samlet.
- **Lite utvidbar sammenlignet med modulære løsninger** – struktur og vekst blir vanskeligere.
- **Tett koblet** – delene er ofte avhengige av hverandre.
- **Feil i én del kan stoppe hele systemet** – svak isolasjon av feil.

---

## Plugin-basert arkitektur

### Hoveddeler
- **Kjerne-system** – grunnsystemet som gir basisfunksjonalitet.
- **Plugin-moduler / extensions** – tillegg som utvider funksjonaliteten.

### Fordeler
- **Lav kobling** – plugins kan være relativt uavhengige av hverandre.
- **Høy isolasjon mellom funksjoner** – endringer i én plugin trenger ikke påvirke andre.
- **Fleksibelt** – funksjonalitet kan legges til eller fjernes.
- **Utvidbart** – systemet kan vokse gjennom nye plugins.

### Ulemper
- **Endringer i kjernen kan ødelegge plugins** – bakoverkompatibilitet blir viktig.
- **Mange plugins kan redusere ytelsen** – ekstra moduler kan gi mer belastning.
- **Kompleks testing av hele systemet** – mange kombinasjoner må testes.

### Eksempler
- **Chrome Web Store** – nettleserutvidelser.
- **IntelliJ** – IDE med mange utvidelser.
- **VS Code** – editor med plugin-system.
- **Eclipse** – utviklingsmiljø bygget rundt plugins.

---

## Deployment-arkitekturer

### Tradisjonell deployment
- **Applikasjoner kjøres direkte på fysiske servere** – programvaren installeres rett på maskinvaren.

### Utfordringer ved tradisjonell deployment
- **Ressursallokering kan bli ineffektiv** – det er vanskelig å fordele kapasitet godt.
- **Én applikasjon kan ta for mye kapasitet** – andre systemer kan påvirkes negativt.

### Virtualisering (VMs)
- **Flere virtuelle maskiner på én fysisk server** – én fysisk maskin deles opp logisk.
- **Hver VM har eget operativsystem** – gir sterk isolasjon mellom miljøene.

### Ulempe ved virtualisering
- **Ressurser reserveres selv om de ikke brukes** – effektiviteten kan bli lav.

### Container-deployment
- **Containere deler OS, men er isolerte** – lettere enn virtuelle maskiner, men fortsatt avgrenset.
- **Lettere enn virtuelle maskiner** – mindre overhead og raskere oppstart.

### Nøkkelteknologier i container-deployment
- **Docker** – teknologi for å bygge og kjøre containere.
- **Kubernetes** – plattform for orkestrering og styring av containere.

### Fordeler med containere
- **Enkel distribusjon** – lett å flytte og kjøre samme løsning flere steder.
- **Konsistent kjøremiljø** – “det fungerer likt overalt”.
- **Løst koblet** – tjenester kan holdes adskilt.
- **Distribuert** – egnet for moderne distribuerte systemer.
- **Elastisk** – kapasitet kan justeres dynamisk.

---

## Systemutviklingsmetodikk

### Før smidige metoder
- **Vannfallsmodellen** – sekvensiell modell med faste faser.
- **Unified Process (UP)** – iterativ prosess med mye modellering og struktur.

### Grunnleggende prinsipper i smidig metode
1. **Problem based** – store problemer brytes ned i mindre deler.
2. **Collaborative** – flere roller samarbeider tett gjennom hele prosessen.
3. **Iterativ** – løsningen utvikles og forbedres i gjentatte runder.
4. **Adaptiv** – planen og løsningen tilpasses ny læring og endring.

### Agile Manifesto – fire hovedverdier
1. **Individer og interaksjoner fremfor prosesser og verktøy** – mennesker og samarbeid er viktigst.
2. **Fungerende programvare fremfor omfattende dokumentasjon** – praktisk verdi prioriteres.
3. **Kundesamarbeid fremfor kontraktsforhandlinger** – kontinuerlig dialog er viktigere enn låste avtaler.
4. **Reagere på endring fremfor å følge en plan** – tilpasning er viktigere enn rigid planfølgning.

---

## Extreme Programming (XP)

### Kjennetegn
- **Lite dokumentasjon** – fokus på kode og praksis fremfor tunge dokumenter.
- **Lite modellering** – mindre vekt på omfattende forhåndsmodellering.
- **Tett feedback-loop** – raske tilbakemeldinger fra tester, kode og kunde.
- **Kort iterasjonstid** – små og hyppige leveranser.

### Antall faste regler i XP
- **29 regler** – XP beskrives ofte som en metode med mange konkrete arbeidsregler.

### Eksempler på XP-regler
- **Parprogrammering** – to utviklere jobber sammen ved samme oppgave.
- **Skriv enhetstester før kode** – test først for å styre utviklingen.
- **Integrer én liten endring av gangen** – små endringer gjør feil lettere å oppdage.
- **Enkel og tydelig kode** – løsningen skal være så enkel som mulig.
- **Hyppig refaktorering** – forbedre kode kontinuerlig uten å endre atferd.
- **Korte feedback-looper** – rask respons på endringer og feil.
- **Hyppige tester** – kvalitet kontrolleres kontinuerlig.
- **Hyppige leveranser** – verdi leveres ofte.

### Fem sentrale verdier i XP
1. **Communication** – tydelig kommunikasjon i teamet.
2. **Simplicity** – hold løsningen enkel.
3. **Feedback** – lær raskt av tester og brukere.
4. **Courage** – tør å endre og forbedre kode når det trengs.
5. **Respect** – respekt for teamet, koden og arbeidet.

---

## Test-Driven Development (TDD)

### Grunnidé
1. **Skriv test først** – definer forventet oppførsel.
2. **Kjør testen og se at den feiler** – bekreft at testen faktisk fanger mangel på funksjonalitet.
3. **Skriv kode som får testen til å bestå** – implementer minimum som trengs.
4. **Refaktorer** – forbedre koden uten å endre funksjonen.

### Fokus i TDD
- **Primært enhetstesting** – små isolerte funksjoner eller klasser.
- **Noen ganger integrasjonstesting** – i enkelte tilfeller kan TDD brukes bredere.
- **Sjelden systemtesting** – TDD brukes oftest nær kodenivå.

### Fordeler
- **Bedre kodekvalitet** – design blir ofte ryddigere.
- **Høyere testdekning** – flere deler av koden får tester.
- **Rask tilbakemelding** – feil oppdages tidlig.
- **Økt tillit** – lettere å endre kode når testene beskytter funksjonaliteten.
- **Testene fungerer som dokumentasjon** – viser hva systemet skal gjøre.

### Ulemper
- **Lærekurve** – krever ny måte å tenke på.
- **Tidsbruk til å skrive tester** – særlig i starten.
- **Vedlikehold av tester** – testene må oppdateres når systemet endres.

---

## Behavior-Driven Development (BDD)

### Hovedidé
- **Kobler forretningsmål og teknologi** – teknisk utvikling knyttes til bruker- og forretningsverdi.
- **Beskriver systematferd fra brukerens perspektiv** – fokus på hva systemet skal gjøre for brukeren.
- **Bruker naturlig språk** – krav uttrykkes i språk flere kan forstå.

### Given-When-Then-formatet
1. **Given (Gitt)** – beskriver starttilstand eller kontekst.
2. **When (Når)** – beskriver handlingen eller hendelsen.
3. **Then (Så)** – beskriver forventet resultat.

### Nøkkelelementer i Gherkin
- **Feature** – overordnet funksjonalitet eller egenskap.
- **Scenario** – konkret eksempel på oppførsel.
- **Given** – forutsetning.
- **When** – handling.
- **Then** – forventning.
- **And** – ekstra steg som bygger videre på de andre.

### Hva BDD bidrar til
- **Tydeligere akseptkriterier** – lettere å forstå hva som må være oppfylt.
- **Felles forståelse mellom forretning og utvikling** – mindre misforståelser.
- **Testbar spesifikasjon** – krav kan omsettes til tester.
- **Høyere fokus på brukerens perspektiv** – atferd sees fra sluttbrukerens side.

---

## Scrum

### Hva Scrum er
- **Tidsboksbasert smidig rammeverk** – arbeid organiseres i faste perioder kalt sprinter.

### Fokus i Scrum
- **Kryssfunksjonelle team** – teamet skal samlet ha kompetansen som trengs.
- **Sprinter** – korte, faste iterasjoner.
- **Inkrementell fremgang** – produktet forbedres litt etter litt.

### Scrum-seremonier
1. **Sprint planning** – planlegging av hva som skal gjøres i sprinten.
2. **Daily standup / daily scrum** – kort daglig møte for koordinering.
3. **Sprint review** – gjennomgang av resultatet med interessenter.
4. **Retrospektiv** – refleksjon over hvordan teamet kan forbedre arbeidsprosessen.

### Typiske artefakter / objekter i Scrum
- **Product backlog** – prioritert liste over alt som kan gjøres i produktet.
- **Sprint backlog** – utvalget av arbeid som tas inn i en sprint.
- **Product backlog items (PBI)** – enkeltenheter i product backlog.
- **Scrum board** – visuell tavle for oppgaver i sprinten.

---

## Lean

### Lean-prinsipper
1. **Eliminate waste** – fjern arbeid som ikke gir verdi.
2. **Build quality in** – kvalitet skal bygges inn i prosessen, ikke bare sjekkes til slutt.
3. **Create knowledge** – læring og tilbakemelding skal brukes aktivt.
4. **Defer commitment** – vent med irreversible valg til man vet mer.
5. **Deliver fast** – lever verdi raskt.
6. **Respect people** – stol på og støtt menneskene i systemet.
7. **Optimize the whole** – se helheten, ikke bare enkeltledd.

---

## Kanban

### Kjennetegn
- **Flytbasert** – fokus på jevn gjennomstrømning av arbeid.
- **Kontinuerlig levering** – arbeid leveres fortløpende.
- **Ingen faste iterasjoner** – i motsetning til Scrum er det ikke sprinter som styrer.
- **Visuell styring** – tavler brukes for å se status og flyt.

### Viktige elementer
- **Kanban-board** – tavle som visualiserer arbeidsflyten.
- **Begrensning av arbeid i prosess (WIP)** – setter grenser for hvor mange oppgaver som kan være i arbeid samtidig.
- **Fokus på flaskehalser** – prosessen forbedres der arbeidet stopper opp.

### Formål med WIP-begrensning
- **Synliggjøre flaskehalser** – gjør problemer i flyten tydelige.
- **Forbedre flyt** – reduserer opphopning av arbeid.
- **Hjelpe teammedlemmer å bidra der det stopper opp** – fremmer samarbeid på tvers.

---

## Domain-Driven Design (DDD)

### Kjennetegn
- **Høyt fokus på domenet** – utviklingen tar utgangspunkt i problemområdet.
- **Koden skal gjenspeile virkeligheten** – modell og kode bør bruke samme begreper som domenet.
- **Egnet for skalering og endring** – god domeneforståelse gjør videreutvikling lettere.
- **Fokus på det viktigste i domenet** – prioriterer kjernebegreper og kjerneprosesser.

---

## DevOps

### Hva DevOps kombinerer
- **Utvikling (Dev)** – bygging og forbedring av programvare.
- **Drift (Ops)** – utrulling, overvåking og vedlikehold i drift.

### DevOps skal sikre
- **Kontinuerlig integrasjon** – kode integreres ofte.
- **Kontinuerlig levering / deploy** – kode kan leveres raskt og trygt.
- **Tettere samarbeid mellom utvikling og drift** – færre siloer mellom team.

### CI (Continuous Integration)
- **Hyppig integrasjon til felles gren** – små endringer flettes ofte inn.
- **Automatisk bygging** – systemet bygges automatisk ved endringer.
- **Automatisk testing** – tester kjøres automatisk som del av bygget.

### CD (Continuous Delivery / Deployment)
- **Automatisk levering / deploy av kodeendringer** – endringer kan settes i drift med mindre manuelt arbeid.

### DevOps-verktøy i pensum
- **GitLab / GitHub** – versjonskontroll og samarbeid.
- **Jira / Confluence** – planlegging og dokumentasjon.
- **Maven** – byggverktøy for Java.
- **Gradle** – fleksibelt byggverktøy.
- **Jenkins** – automatiserings- og CI-server.
- **JUnit** – testverktøy for Java.
- **Selenium** – verktøy for automatisert system-/UI-testing.
- **Kubernetes** – orkestrering av containere.
- **Helm** – pakkebehandling for Kubernetes.
- **Docker** – containerteknologi.
- **Kibana** – visualisering av logger og søk.
- **Grafana** – visualisering av målinger og monitorering.

---

## REST

### REST-prinsipper i pensum
- **Klient-tjener** – klient og server har ulike roller og ansvar.
- **Ressurser identifiseres via URI-er** – data og funksjonalitet modelleres som ressurser.
- **Ressurser manipuleres via HTTP-metoder** – standardiserte operasjoner brukes for å hente og endre data.

### HTTP-metoder i pensum
- **GET** – hente data.
- **POST** – opprette ny ressurs.
- **PUT** – oppdatere eller erstatte ressurs.
- **DELETE** – slette ressurs.

---

## Testing

### Hvorfor teste
- **Sikre riktig respons ved input/interaksjon** – systemet må reagere riktig på brukerhandlinger.
- **Finne bugs** – feil må oppdages før brukerne gjør det.
- **Verifisere ytelse under edge cases** – systemet må tåle vanskelige situasjoner.
- **Vurdere brukervennlighet** – løsningen må være god å bruke.
- **Kontrollere at krav er oppfylt** – systemet må gjøre det som er avtalt.
- **Kontrollere at systemet kan installeres i riktig miljø** – løsningen må fungere der den skal kjøres.
- **Kontrollere at systemet tåler endringer** – videreutvikling må ikke ødelegge eksisterende funksjonalitet.

### Testing principles
1. **Testing shows the presence of defects** – testing kan vise at feil finnes, ikke bevise at ingen feil finnes.
2. **Exhaustive testing is impossible** – det er umulig å teste absolutt alt.
3. **Early testing** – testing bør starte tidlig.
4. **Defects clustering** – mange feil samler seg ofte i få deler av systemet.
5. **Pesticide paradox** – samme tester finner færre nye feil over tid.
6. **Testing is context dependent** – teststrategi må tilpasses situasjonen.
7. **Absence of error fallacy** – et feilfritt system er ikke nyttig hvis det løser feil problem.

### Tradisjonell testing
- **Utvikling og testing skjer separat** – et team lager systemet, et annet tester det.
- **QA-team kvalitetssikrer etter utvikling** – test kommer ofte sent i prosessen.

### Ulempe ved tradisjonell testing
- **Mye tid går til kommunikasjon og overlevering** – feil blir dyrere og tregere å håndtere.

### Smidig testing
- **Utviklere tester egen kode kontinuerlig** – test skjer parallelt med utvikling.
- **Små inkrementer** – mindre endringer testes og leveres ofte.
- **Automatiserte tester brukes mye** – rask feedback er viktig.

### Fordeler ved smidig testing
- **Raskere feedback** – feil oppdages tidlig.
- **Tettere kobling mellom utvikling og kvalitet** – kvalitet bygges inn underveis.
- **QA kan fokusere på viktige scenarioer** – manuell test kan brukes der den gir mest verdi.

---

## Automatiserte tester

### Når de ofte kjøres
- **Ved opprettelse av pull request** – nye endringer testes før sammenslåing.
- **I CI-pipelines** – test inngår i automatisert byggflyt.
- **Ved nye kodeendringer** – hyppig kjøring gir rask tilbakemelding.

### Kjennetegn
- **Enhetstester og integrasjonstester kjøres automatisk** – vanlige testnivåer for automatisering.
- **Resultater rapporteres raskt** – utviklere får rask oversikt over feil.

### Fordeler
- **Rask feedback** – feil oppdages tidlig.
- **Høy hastighet** – mange tester kan kjøres fort.
- **Kontinuerlig kontroll** – kvalitet følges opp automatisk.
- **Forutsigbar kvalitet** – samme test kjøres likt hver gang.
- **Kostnadsbesparende over tid** – reduserer manuelt repeterende arbeid.

### Ulemper / utfordringer
- **Høy oppstarts- og vedlikeholdskostnad** – testene må bygges og holdes oppdatert.
- **Krever riktig fokus og god testdesign** – dårlige automatiserte tester gir liten verdi.

---

## Egne test-/staging-miljøer

### Kjennetegn
- **Testmiljø speiler produksjonsmiljø** – test skjer i omgivelser som ligner virkeligheten.
- **Hele applikasjonen kan testes før release** – gir helhetlig kontroll.

### Fordeler
- **Mer realistisk testing** – større sjanse for å finne reelle feil.
- **QA kan teste hele applikasjonen** – også på systemnivå.
- **Infrastructure as Code gjør oppsett enklere** – miljøer kan opprettes og vedlikeholdes systematisk.

---

## CI og små endringer

### Fordeler
- **Mindre diff mellom gammel og ny versjon** – endringer blir lettere å forstå.
- **Enklere isolering av feil** – lettere å finne hva som gikk galt.
- **Enklere sporing av endringer** – bedre oversikt over historikk.
- **Lavere sannsynlighet for feil** – små endringer er lettere å kontrollere.
- **Enklere rollback** – enklere å rulle tilbake en liten endring.

---

## Prioritering av testing

### Viktige prinsipper
- **Finn riktig nivå på testdekning basert på risiko** – ikke alt må testes like mye.
- **Prioriter tester som gir størst verdi** – test der konsekvensen av feil er størst.
- **Prioriter tester som reduserer mest usikkerhet** – test der du vet minst eller er mest utsatt.

---

## Risk poker

### Hva man vurderer
- **Risiko** – sannsynlighet for at noe går galt.
- **Konsekvens** – hvor alvorlig det blir hvis det går galt.
- **Risikofaktorer** – forhold som påvirker sannsynlighet eller konsekvens.

### Fordeler
- **Hele teamet deltar** – flere perspektiver tas med.
- **Bedre treffsikkerhet** – samlet vurdering blir ofte bedre enn individuell.
- **Felles forståelse av risiko** – teamet blir enige om hva som er kritisk.

---

## Testdata

### Egenskaper ved gode testdata
- **Samme data hver gang** – testresultater kan sammenlignes.
- **Deterministisk prosess** – samme input gir samme output.
- **Forutsigbart testmiljø** – eksterne tilfeldigheter påvirker minst mulig.

### Fordeler
- **Enklere å isolere feil** – avvik blir lettere å forklare.
- **Mer presise testresultater** – resultatene blir mer pålitelige.
- **Bedre analyse av testutfall** – utviklere kan tolke funn mer sikkert.

---

## Mocking

### Hva mocking brukes til
- **Erstatte ekte og komplekse avhengigheter** – bytte ut systemer som er vanskelige eller upraktiske å bruke i test.
- **Isolere klasser / moduler i test** – teste én del uten ekte avhengigheter.

### Typiske avhengigheter som kan mocket
- **Database** – unngå ekte database i test.
- **Eksternt API** – unngå nettverkskall og ustabile svar.
- **Betalingstjeneste** – simulere betaling uten ekte transaksjoner.

### Hva som gjør mocking ideelt
- **Deterministiske svar** – testene får samme respons hver gang.
- **Samme grensesnitt som ekte avhengighet** – kan byttes inn uten å endre resten av koden.
- **Kombineres godt med dependency injection** – avhengigheter kan settes inn ved kjøring.

### Fordeler
- **Muliggjør isolert testing** – én del kan testes alene.
- **Gjør automatiserte tester mulige i flere situasjoner** – flere deler blir testbare.
- **Gir kontroll over testmiljøet** – reduserer usikkerhet i testkjøringen.

---

## Testfaser

### Faser i en test
1. **Oppsett** – forbered testdata og testmiljø.
2. **Gjennomføring** – utfør handlingene testen beskriver.
3. **Verifisering** – kontroller at resultatet ble som forventet.
4. **Opprydding** – fjern eller nullstill ressurser for neste test.

---

## Enhetstesting

### Kjennetegn
- **Tester individuelle klasser / funksjoner** – små deler testes isolert.
- **Fokus på små enheter** – enkel funksjonalitet står i sentrum.
- **Ofte utviklers ansvar** – utvikleren skriver og vedlikeholder testene.

### Fordeler
- **Automatisert** – enkelt å kjøre ofte.
- **Repeterbar** – gir like resultater ved samme input.
- **Kjøres i byggeprosessen** – naturlig del av utviklingsflyten.

### Mål
- **Finne feil tidlig** – feil fanges før de sprer seg.
- **Stoppe feil før integrasjon med andre deler** – hindrer at små feil blir større problemer.

---

## Integrasjonstesting

### Kjennetegn
- **Tester samspill mellom komponenter** – ser på hvordan delene virker sammen.
- **Bygger på at delene allerede er testet individuelt** – enhetstesting bør være gjort først.

### Mål
- **Oppdage feil i grensesnitt og samhandling** – avdekke problemer i koblinger mellom delene.

### Valg
- **Kan automatiseres** – mange integrasjonstester egner seg for automatisering.
- **Bør automatiseres der det er hensiktsmessig** – særlig ved hyppige og kritiske samspill.

---

## Systemtesting

### Kjennetegn
- **Tester hele systemet** – systemet ses som en helhet.
- **Sjekker at alle deler fungerer sammen** – helhetlig kvalitet kontrolleres.

### Fordeler
- **Finner feil mellom deler av systemet** – noen problemer oppstår bare i helheten.
- **Gir trygghet før levering** – bedre grunnlag for release.

### Mål
- **Sjekke at systemet oppfyller krav** – både funksjonelle og ofte ikke-funksjonelle krav.
- **Finne feil før bruk** – redusere risiko før sluttbruker møter løsningen.

### Valg
- **Kan utføres med verktøy som Selenium** – mulig å automatisere deler av helheten.
- **Kan være vanskelig å gjøre helt repeterbar** – mange avhengigheter påvirker resultatet.

---

## Akseptansetesting

### Kjennetegn
- **Type systemtesting** – skjer på høyt nivå i systemet.
- **Utføres for å verifisere at krav er oppfylt** – spesielt mot kundens eller brukerens forventninger.

### Viktig i BDD
- **Bygger på user stories** – kobling mellom krav og test.
- **Kan utvikles sammen med kunden** – gir bedre samsvar med behov.

### Kan være
- **Manuell** – mennesker går gjennom scenarier.
- **Automatisert** – scenarioer kan kjøres som automatiske tester.

---

## Regresjonstesting

### Hva det er
- **Tester at endringer ikke ødelegger eksisterende funksjonalitet** – gammel funksjon må fortsatt virke etter endringer.

### Når det skjer
- **Før og etter endringer** – for å sammenligne oppførsel.
- **Kontinuerlig i CI ved innsjekk av kode** – skjer ofte automatisk i moderne utvikling.

### Hvilke nivåer det kan finnes på
- **Enhetstestnivå** – små deler testes på nytt.
- **Integrasjonsnivå** – samspill testes på nytt.
- **Akseptansenivå** – brukerorientert oppførsel testes på nytt.

### Valg
- **Egner seg godt for automatisering** – samme tester kjøres mange ganger.

---

## Smoke-testing og sanity-testing

### Smoke-testing
- **Tester kritisk funksjonalitet** – sjekker at systemets viktigste deler virker.
- **Rask sjekk av om systemet “i det hele tatt fungerer”** – avgjør om videre testing er verdt å starte.

### Sanity-testing
- **Tester ny eller endret funksjonalitet** – fokuserer på siste endring.
- **Rask sjekk av om en spesifikk endring virker fornuftig** – smalere enn smoke-testing.

### Hvorfor de er nyttige
- **Avdekker tidlig om videre testing er hensiktsmessig** – sparer tid hvis systemet er for ustabilt.

---

## Destruktiv testing og utforskende testing

### Destruktiv testing
- **Kreativ testing for å få systemet til å feile** – tester bevisst grensene.
- **Kan ikke automatiseres** – bygger på menneskelig kreativitet.
- **Krever menneskelig erfaring og kreativitet** – testeren må tenke utradisjonelt.

### Utforskende testing
- **Tester med aktiv læring og utforsking underveis** – testdesign og gjennomføring skjer samtidig.
- **Bygger på innsikt i systemet og nye hypoteser** – man følger spor som dukker opp.

### Forskjell
- **Destruktiv testing: fokus på å bryte systemet** – målet er å finne svakheter ved å presse løsningen.
- **Utforskende testing: bredere utforsking og læring** – målet er både forståelse og feilfunn.

---

## Usabilitytesting

### Hva det tester
- **Brukervennlighet** – hvor lett systemet er å bruke.
- **GUI** – hvordan det grafiske brukergrensesnittet fungerer.
- **Om brukeren / kunden er fornøyd** – opplevd kvalitet og tilfredshet.

---

## Ytelsestesting

### Hva ytelsestesting undersøker
- **Hvor mye last systemet tåler** – kapasitet under normal eller høy belastning.
- **Hvor mye plutselig last systemet tåler** – reaksjon på raske topper.
- **Ytelse over tid** – stabilitet og ressursbruk ved langvarig drift.
- **Lekkasjer / ressursproblemer** – oppdage for eksempel minnelekkasjer.

### Hvordan ytelse måles
- **Antall samtidige brukere** – hvor mange som bruker systemet samtidig.
- **Transaksjoner per tidsenhet** – hvor mye arbeid systemet utfører per tidsrom.
- **Throughput** – mengde data eller arbeid som behandles over tid.
- **Responstid** – hvor lang tid systemet bruker på å svare.

### Hva flaskehalser er
- **Systemets svakeste / tregeste punkt** – delen som begrenser total ytelse.
- **Det som begrenser total ytelse** – det som holder resten tilbake.

### Vanlige årsaker til flaskehalser
- **CPU** – prosessoren er overbelastet.
- **Minne** – for lite eller ineffektiv bruk av RAM.
- **Tråder** – dårlig håndtering av parallellitet eller venting.
- **Databasetilkobling** – database eller forbindelser blir begrensningen.

### Typer ytelsestester
1. **Lasttest** – måler oppførsel ved forventet eller gradvis økende last.
2. **Stresstest** – finner yttergrensen der systemet bryter sammen.
3. **Spike-test** – tester reaksjon på plutselige lasttopper.
4. **Utholdenhetstest** – tester systemet under jevn belastning over tid.

---

## Black-box og white-box testing

### Black-box testing
- **Ingen innsikt i intern kode** – testeren ser bare input og output.
- **Bygger på krav, spesifikasjoner og forventet oppførsel** – ikke på intern implementasjon.

### White-box testing
- **Full innsikt i intern kode og struktur** – testeren kjenner logikken og oppbygningen.
- **Tester intern logikk og oppbygning** – dekker veier, betingelser og intern struktur.

---

## Automatisk vs manuell testing

### Fordeler ved automatiske tester
- **Raske** – kan kjøres ofte og på kort tid.
- **Nøyaktige** – samme fremgangsmåte hver gang.
- **Repeterbare** – resultatene blir konsistente.
- **Gode for kjente forventninger** – passer godt der riktig resultat er tydelig definert.

### Typiske automatiserte tester
- **Enhetstester** – små isolerte kodeenheter.
- **Regresjonstester** – sjekk av at gammel funksjonalitet fortsatt virker.
- **Mange integrasjonstester** – testing av samspill mellom komponenter.
- **Mange ytelsestester** – automatiske last- og stresstester.

### Ulemper ved automatiske tester
- **Krever vedlikehold** – testene må oppdateres når systemet endres.
- **Fanger ikke alt** – særlig dårlig på subjektive forhold.
- **Dårligere på kreative og uventede problemer** – mennesker er bedre til utforskning.

### Fordeler ved manuelle tester
- **Kreative** – testeren kan tenke fritt og prøve uventede ting.
- **Fanger ofte naturlige brukerfeil og uventede problemer** – realistisk menneskelig bruk avdekkes bedre.
- **Gode for utforsking og opplevelse** – særlig viktig for usability og ad hoc-testing.

### Typiske manuelle tester
- **Utforskende testing** – læring og test skjer samtidig.
- **Destruktiv testing** – kreativ testing for å bryte systemet.
- **Mye usabilitytesting** – vurdering av opplevelse og brukeradferd.

### Testtyper som kan være både manuelle og automatiske
- **Smoke-testing** – raske helsesjekker av løsning.
- **Sanity-testing** – raske sjekker av endret funksjonalitet.
- **Integrasjonstesting** – samspill mellom komponenter.
- **Systemtesting** – helhetlig testing av systemet.
- **Akseptansetesting** – verifisering mot behov og krav.
- **Ytelsestesting** – måling av kapasitet og responstid.

---

## GDPR

### Grunnleggende prinsipper i GDPR
1. **Lovlighet, rimelighet og gjennomsiktighet** – behandling må være lovlig, rettferdig og forståelig for den registrerte.
2. **Formålsbegrensning** – data skal bare brukes til tydelig definerte formål.
3. **Dataminimering** – bare nødvendige opplysninger skal samles inn.
4. **Riktighet** – opplysninger skal være korrekte og oppdaterte.
5. **Lagringsbegrensning** – data skal ikke lagres lenger enn nødvendig.
6. **Integritet og konfidensialitet** – data skal beskyttes mot uautorisert tilgang og tap.
7. **Ansvarliggjøring** – virksomheten må kunne dokumentere at reglene følges.

### De registrertes rettigheter
1. **Rett til informasjon** – få vite hvilke data som behandles og hvorfor.
2. **Rett til innsyn** – få tilgang til egne opplysninger.
3. **Rett til retting** – få uriktige opplysninger korrigert.
4. **Rett til sletting** – kreve at opplysninger fjernes i visse tilfeller.
5. **Rett til begrensning** – kreve at behandling stoppes midlertidig.
6. **Rett til å protestere** – motsette seg visse typer behandling.
7. **Rett til dataportabilitet** – få egne data ut i et maskinlesbart format.

### Typiske unntak / begrensninger
- **Juridisk forpliktelse** – behandling kan være nødvendig for å oppfylle lovkrav.
- **Offentlig sikkerhet** – noen rettigheter kan begrenses av samfunnshensyn.
- **Forskning** – særregler kan gjelde ved forskning og statistikk.

---

## Profesjonsetikk

### Ingeniørens ansvar omfatter blant annet
- **Sosialt ansvar** – teknologi påvirker samfunn, arbeidsliv og mennesker.
- **Sikkerhet og pålitelighet** – systemer må være trygge og til å stole på.
- **Brukeres velferd** – løsninger må ikke skade brukerne eller deres livssituasjon.
- **AI og militær bruk / alvorlige konsekvenser av teknologi** – utviklere må reflektere over alvorlige anvendelser og ansvar.

### Eksempler på NITO-prinsipper i pensum
- **Vise respekt for kolleger** – rettferdig og profesjonell behandling av andre.
- **Vedkjenne seg faglig ansvar** – stå inne for eget arbeid og egne vurderinger.
- **Følge anerkjente kvalitetsnormer** – bruke faglig gode standarder og praksiser.
- **Bidra til åpenhet om teknologiske konsekvenser** – ikke skjule risiko eller negative effekter.

### IEEE/ACM Code of Ethics – hovedområder
1. **Samfunn** – arbeid i offentlighetens interesse.
2. **Kunde og arbeidsgiver** – opptre ansvarlig overfor dem man arbeider for.
3. **Produkt** – sikre høy kvalitet i programvare og løsninger.
4. **Vurdering** – utvise integritet og faglig skjønn.
5. **Ledelse** – fremme etisk ledelse i utviklingsarbeid.
6. **Profesjon** – styrke profesjonens integritet og omdømme.
7. **Kolleger** – støtte og behandle kolleger rettferdig.
8. **Egen utvikling / livslang læring** – holde seg faglig oppdatert og utvikle seg videre.

### Nøkkelprinsipper i profesjonsetikken
- **Ærlighet og integritet** – vær sannferdig om begrensninger og risiko.
- **Respekt for personvern** – bygg løsninger som beskytter individet.
- **Kvalitetsbevissthet** – arbeid systematisk for god kvalitet.
- **Ansvar for konsekvenser** – vurder hvordan teknologien påvirker mennesker og samfunn.
- **Kontinuerlig vurdering** – etiske vurderinger må gjøres gjennom hele prosessen.

### Hvorfor profesjonsetikk henger sammen med kvalitet
- **Mer robuste systemer** – etisk bevissthet gir ofte bedre designvalg.
- **Færre sikkerhets- og personvernbrudd** – risiko håndteres tidligere.
- **Høyere brukertilfredshet** – brukere stoler mer på løsningen.
- **Beskytter omdømme** – både utviklere og virksomheter unngår tillitstap.
- **Reduserer risiko for bias og tillitsbrudd** – færre urettferdige eller skadelige løsninger.

---

## Prosjektplanlegging

### Visjonsdokument – hva det typisk inneholder
- **Formål** – hvorfor prosjektet finnes.
- **Omfang** – hva prosjektet skal og ikke skal dekke.
- **Hensikt** – hva man ønsker å oppnå.
- **Målgruppe** – hvem løsningen er for.
- **Funksjonelle krav** – hva systemet skal gjøre.
- **Ikke-funksjonelle krav** – kvalitetskrav som ytelse, sikkerhet og brukervennlighet.
- **Interessenter** – personer eller grupper som påvirkes av prosjektet.
- **Brukerbehov** – behovene løsningen skal dekke.

### Risikoanalyse – hva den brukes til
- **Identifisere risiko** – finne mulige problemer.
- **Prioritere risiko** – vurdere hva som er viktigst å håndtere.
- **Definere tiltak** – bestemme hva man skal gjøre med risikoene.
- **Forbedre beslutningsprosesser** – gi bedre grunnlag for valg.
- **Øke prosjektets robusthet** – gjøre prosjektet bedre rustet mot problemer.

---
```

## @real-eo

Lag alle begreper o.l i markdownen du lagde om til en TSV fil med:
begrep 1     definisjon 1
begrep 2     definisjon 2
begrep 3     definisjon 3

slik at jeg kan paste det inn i quizlet.


## Copilot

Her er TSV-formatet. Hver linje er `begrep<TAB>definisjon`, klart til å limes inn i Quizlet.

```tsv name=quizlet-begreper.tsv
Definer krav	Avklare brukerbehov, mål og rammer for løsningen.
Design alternativer	Lage flere mulige forslag til hvordan løsningen kan fungere.
Lag prototype	Gjøre designet konkret i en enkel eller avansert modell.
Evaluer	Vurdere om løsningen fungerer for brukerne og oppfyller kravene.
Ord	Tekst og språk som brukes i grensesnittet.
Visuelle representasjoner	Ikoner, farger, bilder, typografi og andre grafiske elementer.
Fysiske objekter og rom	Den fysiske konteksten eller enheten brukeren samhandler gjennom.
Tid	Hvordan interaksjonen utvikler seg over tid, for eksempel animasjoner, lyd og responstid.
Atferd	Hvordan systemet oppfører seg, og hvilke reaksjoner og opplevelser dette skaper hos brukeren.
Synlighet	Funksjoner og muligheter skal være lette å oppdage.
Feedback	Systemet skal gi tydelig tilbakemelding på hva som skjer.
Begrensninger	Designet bør begrense feil handlinger og lede brukeren riktig.
Avbilding (mapping)	Sammenhengen mellom kontroll og effekt bør være intuitiv.
Konsistens	Like ting bør fungere likt i hele systemet.
Tilbydelser / affordances	Designet skal signalisere hvilke handlinger som er mulige.
Utseende	Hvordan prototypen ser ut visuelt.
Innhold	Hvilken informasjon og hvilke elementer som er med.
Funksjonalitet	Hvilke funksjoner som er simulert eller implementert.
Interaktivitet	Hvor mye brukeren faktisk kan gjøre i prototypen.
Romlig struktur	Hvordan skjermbilder, elementer eller deler av løsningen er organisert.
Horisontal prototype	Bred prototype med mange funksjonsområder, men lite dybde.
Vertikal prototype	Smal prototype som går i detalj og dybde på én funksjon.
Evolusjonær prototype	Prototype som videreutvikles til en del av sluttproduktet.
Bruk-og-kast-prototype	Prototype som brukes til læring og deretter forkastes.
Lavoppløselig prototype	Enkel prototype med lite detalj og lite interaksjon, for eksempel papirskisse.
Høyoppløselig prototype	Mer realistisk prototype med mye detalj og ofte mer interaksjon.
Testing	Verifisering av om systemet fungerer teknisk riktig.
Evaluering	Vurdering av om løsningen er nyttig, brukbar og riktig for behovet.
Formativ evaluering	Evaluering underveis for å forbedre løsningen mens den utvikles.
Summativ evaluering	Evaluering av ferdig løsning for å vurdere sluttresultatet.
Brukertest	Brukere utfører oppgaver mens man observerer problemer og atferd.
A/B-test	To eller flere varianter sammenlignes for å se hvilken som fungerer best.
Feltstudie	Evaluering i brukerens naturlige omgivelser.
Opportunistisk evaluering	Rask tilbakemelding fra brukere på en idé eller problemstilling.
Heuristisk gjennomgang	Eksperter vurderer løsningen ut fra etablerte brukbarhetsprinsipper.
Prediktive modeller	Analytiske eller beregnende modeller brukes for å forutsi brukeropplevelse eller ytelse.
Pluralistisk gjennomgang	Brukere, utviklere og eksperter går sammen gjennom scenarioer og vurderer løsningen.
Observasjon	Se hvordan brukeren faktisk oppfører seg.
Spørre brukere	Samle innsikt gjennom intervju, samtale eller spørreskjema.
Direkte testing	Brukeren prøver konkrete oppgaver i løsningen.
Spørre eksperter	Hente vurderinger fra fagpersoner.
Modellering	Bruke modeller for å analysere eller forutsi bruk.
Kodevalidering	Sjekk av om kode og struktur følger krav eller standarder.
Testing i ulike nettlesere og på ulike plattformer	Sjekk av kompatibilitet på tvers av miljøer.
Testing av fleksibiliteten til et design	Vurdering av hvor godt designet fungerer under ulike forhold.
Testing av grad av universell utforming / brukskvalitet	Sjekk av tilgjengelighet og brukervennlighet.
Testing av feilmeldinger	Vurdering av om feilmeldinger er tydelige og hjelpsomme.
Konkret hensikt	Testen skal ha et tydelig mål.
Avgrenset formål	Man tester noe spesifikt, ikke alt på en gang.
Realistiske oppgaver	Oppgavene bør ligne ekte brukssituasjoner.
Observasjon av brukeren	Man ser hva brukeren faktisk gjør, ikke bare hva brukeren sier.
Enkel og intuitiv i bruk	Løsningen skal være lett å forstå.
Forståelig informasjon	Nødvendig informasjon skal kommuniseres tydelig.
Toleranse for feil	Designet skal redusere risiko og konsekvenser av feil.
Like muligheter for alle	Løsningen skal kunne brukes av personer med ulike ferdigheter.
Fleksibel i bruk	Løsningen skal støtte ulike preferanser og måter å bruke systemet på.
Lav fysisk anstrengelse	Løsningen skal kunne brukes med minst mulig belastning.
Størrelse og plass for tilgang og bruk	Fysisk og visuell utforming skal støtte tilgang og bruk.
Tilgang	Brukeren skal kunne nå og oppfatte løsningens elementer.
Rekkevidde	Brukeren skal kunne komme til funksjonene uavhengig av kroppslige forutsetninger.
Betjening og bruk	Løsningens elementer skal kunne brukes praktisk og sikkert.
Mer inkluderende	Flere mennesker kan bruke løsningen.
Enklere å bruke	God struktur og navigasjon hjelper alle brukere.
Mer mobiltilpasset	Tilgjengelige løsninger fungerer ofte bedre på små skjermer.
Mer synlig for Google / bedre SEO	God struktur og semantikk hjelper søkemotorer.
Mer lønnsomt	Flere brukere når fram, og supportbehov kan reduseres.
Mulig å oppfatte (Perceivable)	Innhold må kunne oppfattes av brukeren.
Mulig å betjene (Operable)	Grensesnittet må kunne brukes og navigeres.
Forståelig (Understandable)	Innhold og funksjonalitet må være forståelige.
Robust	Løsningen må fungere med ulike nettlesere og hjelpemidler.
Innhold skal være tilgjengelig via tastatur	Brukeren skal ikke være avhengig av mus.
Bilder skal ha alternativ tekst	Skjermlesere må kunne formidle bildeinnhold.
Video skal ha teksting eller alternativ lyd	Innholdet må være tilgjengelig ved ulike behov.
Skjema og formater skal være lette å forstå	Brukerens oppgaver må være tydelige.
Innhold skal være lett å forstå	Språk og struktur må støtte forståelse.
Use case-diagram	Viser aktører og hvilke mål eller funksjoner de bruker systemet til.
Domenemodell	Viser sentrale begreper i domenet og relasjonene mellom dem.
Sekvensdiagram	Viser meldinger og samspill mellom deltakere over tid.
Aktivitetsdiagram	Viser flyt av aktiviteter, beslutninger og parallelle handlinger.
Klassediagram	Viser klasser, attributter, metoder og relasjoner.
Pakkediagram	Viser hvordan elementer grupperes i pakker eller moduler.
Tilstandsmaskindiagram	Viser tilstander og overganger for et objekt eller system.
Deltakere	Aktører, objekter eller komponenter som deltar i samspillet.
Meldinger / funksjonskall	Kommunikasjon mellom deltakerne.
Levetidslinje	Stiplet linje som viser deltakerens eksistens over tid.
Aktiveringsboks	Viser når en deltaker utfører arbeid.
Rammer	Markerer kontrollstrukturer som valg eller repetisjon.
Aksjoner	Konkrete handlinger eller steg i en prosess.
Initial node	Startpunktet for aktiviteten.
Final node	Sluttpunktet for aktiviteten.
Decision node	Punkt der prosessen forgrenes ut fra betingelser.
Fork node	Deler prosessen i parallelle løp.
Join node	Samler parallelle løp igjen.
Merge node	Slår sammen alternative flyter.
Overganger / piler	Viser rekkefølge og flyt mellom aktiviteter.
Klasse	En type objekt med data og atferd.
Attributter	Data som hører til klassen.
Metoder	Funksjoner eller operasjoner klassen kan utføre.
Avhengighet (dependency)	En svak kobling der én klasse bruker en annen.
Assosiasjon	En strukturell kobling mellom to klasser.
Aggregering	Hel-del-relasjon der delen kan eksistere uten helheten.
Komposisjon	Sterk hel-del-relasjon der delen hører tett til helheten.
Arv / generalisering	En subklasse arver fra en superklasse.
Realisering	En klasse implementerer et grensesnitt.
Starttilstand	Tilstanden systemet eller objektet starter i.
Sluttilstand	Tilstanden der livsløpet avsluttes.
Tilstander	Ulike situasjoner objektet kan befinne seg i.
Overganger	Bevegelser fra én tilstand til en annen.
Triggere / hendelser	Det som utløser en overgang.
Som [rolle]	Beskriver hvem brukeren er.
vil jeg [mål/ønske]	Beskriver hva brukeren ønsker å gjøre.
slik at [nytte/verdi]	Beskriver hvorfor dette er viktig.
Forstå systemet tidlig	Gjør det lettere å se helheten før implementasjon.
Redusere kostnader	Tidlige gode valg sparer tid og penger senere.
Unngå duplisering av ressurser	Tydelig struktur reduserer overlappende løsninger.
Øke kvalitet	Bedre struktur gir bedre vedlikeholdbarhet og testbarhet.
Hjelpe risikostyring	Man oppdager tekniske utfordringer tidligere.
Støtte kommunikasjon mellom interessenter	Gir et felles bilde av systemet.
Gi retningslinjer for utviklere	Hjelper teamet å utvikle konsistent.
Splitt og hersk	Del opp problemet i mindre deler.
Lav kobling	Delene bør være minst mulig avhengige av hverandre.
Mer testbar kode	Mindre og tydeligere deler er enklere å teste.
Mer robust kode	Isolerte deler tåler endringer bedre.
Enklere delegering av ansvar	Team kan jobbe med ulike deler parallelt.
Presentasjonslag	Viser informasjon og håndterer brukerinteraksjon.
Forretningslogikklag	Utfører regler, prosessering og kjernefunksjonalitet.
Data access-lag	Håndterer lagring, henting og oppdatering av data.
Hvert lag har spesifikt ansvar	Gjør systemet mer oversiktlig.
Hvert lag yter tjenester til laget over / bruker laget under	Gir strukturert avhengighet.
Gir lav kobling	Endringer i ett lag påvirker ikke nødvendigvis alle andre.
Master	Styrer, fordeler arbeid og samler resultater.
Slaver	Utfører arbeid delegert av master.
Tydelig oversikt i master	Gir sentral kontroll over prosessen.
Slavene kan enhetstestes separat	Hver del kan testes isolert.
Master kan integrasjonstestes mot slavene	Samspillet kan testes samlet.
Event listener	Lytter etter hendelser.
Event source	Produserer eller sender hendelser.
Channel	Kanal eller emne der hendelser publiseres.
Event bus	Infrastrukturen som frakter hendelser mellom kilder og lyttere.
Model	Data og forretningslogikk.
View	Det brukeren ser i grensesnittet.
Controller	Håndterer input og styrer flyten mellom model og view.
Høyere kohesjon	Hver del får tydeligere ansvar.
Gjenbrukbarhet	Deler kan lettere brukes på nytt.
Skiller ansvar	Gjør systemet enklere å forstå og endre.
Single Responsibility Principle	Hver tjeneste bør ha ett tydelig hovedansvar.
Selvstendige tjenester	Hver tjeneste kan utvikles og driftes separat.
Én hovedoppgave per tjeneste	Tydelig ansvarsdeling.
Egen data	Tjenesten eier vanligvis sin egen datalagring.
Eget kjøremiljø	Tjenesten kan kjøres og deployes uavhengig.
Skalerbart	Tjenester kan skaleres separat.
Modulært	Systemet deles i mindre moduler.
Fleksibel teknologibruk	Ulike tjenester kan bruke ulik teknologi.
Høy tilgjengelighet / feil isoleres	Feil i én tjeneste stopper ikke nødvendigvis hele systemet.
Støtter kontinuerlig levering (CI/CD)	Tjenester kan oppdateres uavhengig.
Passer DevOps	Tett kobling mellom utvikling, drift og deploy.
Kompleks debugging	Feilsporing på tvers av tjenester er vanskeligere.
Kompleks logging på tvers av tjenester	Data om feil og flyt spres i flere systemer.
Krever automatisering	Bygg, test og deploy må ofte automatiseres sterkt.
Vanskelig å teste distribuerte systemer	Mange avhengigheter og miljøer kompliserer test.
Datainkonsistens kan oppstå	Data er fordelt og kan bli ute av synk.
Økt ressursforbruk	Mange tjenester krever mer infrastruktur.
God gjennomstrømning / lite overhead	Mindre kommunikasjon mellom separate tjenester.
Enklere å teste og debugge i starten	Alt er samlet i én applikasjon.
Vanskeligere å vedlikeholde ved vekst	Systemet blir tungt å endre når det blir stort.
Lite skalerbar	Hele systemet må ofte skaleres samlet.
Lite utvidbar sammenlignet med modulære løsninger	Struktur og vekst blir vanskeligere.
Tett koblet	Delene er ofte avhengige av hverandre.
Feil i én del kan stoppe hele systemet	Svak isolasjon av feil.
Kjerne-system	Grunnsystemet som gir basisfunksjonalitet.
Plugin-moduler / extensions	Tillegg som utvider funksjonaliteten.
Lav kobling	Plugins kan være relativt uavhengige av hverandre.
Høy isolasjon mellom funksjoner	Endringer i én plugin trenger ikke påvirke andre.
Fleksibelt	Funksjonalitet kan legges til eller fjernes.
Utvidbart	Systemet kan vokse gjennom nye plugins.
Endringer i kjernen kan ødelegge plugins	Bakoverkompatibilitet blir viktig.
Mange plugins kan redusere ytelsen	Ekstra moduler kan gi mer belastning.
Kompleks testing av hele systemet	Mange kombinasjoner må testes.
Chrome Web Store	Nettleserutvidelser.
IntelliJ	IDE med mange utvidelser.
VS Code	Editor med plugin-system.
Eclipse	Utviklingsmiljø bygget rundt plugins.
Applikasjoner kjøres direkte på fysiske servere	Programvaren installeres rett på maskinvaren.
Ressursallokering kan bli ineffektiv	Det er vanskelig å fordele kapasitet godt.
Én applikasjon kan ta for mye kapasitet	Andre systemer kan påvirkes negativt.
Flere virtuelle maskiner på én fysisk server	Én fysisk maskin deles opp logisk.
Hver VM har eget operativsystem	Gir sterk isolasjon mellom miljøene.
Ressurser reserveres selv om de ikke brukes	Effektiviteten kan bli lav.
Containere deler OS, men er isolerte	Lettere enn virtuelle maskiner, men fortsatt avgrenset.
Lettere enn virtuelle maskiner	Mindre overhead og raskere oppstart.
Docker	Teknologi for å bygge og kjøre containere.
Kubernetes	Plattform for orkestrering og styring av containere.
Enkel distribusjon	Lett å flytte og kjøre samme løsning flere steder.
Konsistent kjøremiljø	Det fungerer likt overalt.
Løst koblet	Tjenester kan holdes adskilt.
Distribuert	Egnet for moderne distribuerte systemer.
Elastisk	Kapasitet kan justeres dynamisk.
Vannfallsmodellen	Sekvensiell modell med faste faser.
Unified Process (UP)	Iterativ prosess med mye modellering og struktur.
Problem based	Store problemer brytes ned i mindre deler.
Collaborative	Flere roller samarbeider tett gjennom hele prosessen.
Iterativ	Løsningen utvikles og forbedres i gjentatte runder.
Adaptiv	Planen og løsningen tilpasses ny læring og endring.
Individer og interaksjoner fremfor prosesser og verktøy	Mennesker og samarbeid er viktigst.
Fungerende programvare fremfor omfattende dokumentasjon	Praktisk verdi prioriteres.
Kundesamarbeid fremfor kontraktsforhandlinger	Kontinuerlig dialog er viktigere enn låste avtaler.
Reagere på endring fremfor å følge en plan	Tilpasning er viktigere enn rigid planfølgning.
Lite dokumentasjon	Fokus på kode og praksis fremfor tunge dokumenter.
Lite modellering	Mindre vekt på omfattende forhåndsmodellering.
Tett feedback-loop	Raske tilbakemeldinger fra tester, kode og kunde.
Kort iterasjonstid	Små og hyppige leveranser.
29 regler	XP beskrives ofte som en metode med mange konkrete arbeidsregler.
Parprogrammering	To utviklere jobber sammen ved samme oppgave.
Skriv enhetstester før kode	Test først for å styre utviklingen.
Integrer én liten endring av gangen	Små endringer gjør feil lettere å oppdage.
Enkel og tydelig kode	Løsningen skal være så enkel som mulig.
Hyppig refaktorering	Forbedre kode kontinuerlig uten å endre atferd.
Korte feedback-looper	Rask respons på endringer og feil.
Hyppige tester	Kvalitet kontrolleres kontinuerlig.
Hyppige leveranser	Verdi leveres ofte.
Communication	Tydelig kommunikasjon i teamet.
Simplicity	Hold løsningen enkel.
Feedback	Lær raskt av tester og brukere.
Courage	Tør å endre og forbedre kode når det trengs.
Respect	Respekt for teamet, koden og arbeidet.
Skriv test først	Definer forventet oppførsel.
Kjør testen og se at den feiler	Bekreft at testen faktisk fanger mangel på funksjonalitet.
Skriv kode som får testen til å bestå	Implementer minimum som trengs.
Refaktorer	Forbedre koden uten å endre funksjonen.
Primært enhetstesting	Små isolerte funksjoner eller klasser.
Noen ganger integrasjonstesting	I enkelte tilfeller kan TDD brukes bredere.
Sjelden systemtesting	TDD brukes oftest nær kodenivå.
Bedre kodekvalitet	Design blir ofte ryddigere.
Høyere testdekning	Flere deler av koden får tester.
Rask tilbakemelding	Feil oppdages tidlig.
Økt tillit	Lettere å endre kode når testene beskytter funksjonaliteten.
Testene fungerer som dokumentasjon	Viser hva systemet skal gjøre.
Lærekurve	Krever ny måte å tenke på.
Tidsbruk til å skrive tester	Særlig i starten.
Vedlikehold av tester	Testene må oppdateres når systemet endres.
Kobler forretningsmål og teknologi	Teknisk utvikling knyttes til bruker- og forretningsverdi.
Beskriver systematferd fra brukerens perspektiv	Fokus på hva systemet skal gjøre for brukeren.
Bruker naturlig språk	Krav uttrykkes i språk flere kan forstå.
Given (Gitt)	Beskriver starttilstand eller kontekst.
When (Når)	Beskriver handlingen eller hendelsen.
Then (Så)	Beskriver forventet resultat.
Feature	Overordnet funksjonalitet eller egenskap.
Scenario	Konkret eksempel på oppførsel.
And	Ekstra steg som bygger videre på de andre.
Tydeligere akseptkriterier	Lettere å forstå hva som må være oppfylt.
Felles forståelse mellom forretning og utvikling	Mindre misforståelser.
Testbar spesifikasjon	Krav kan omsettes til tester.
Høyere fokus på brukerens perspektiv	Atferd sees fra sluttbrukerens side.
Tidsboksbasert smidig rammeverk	Arbeid organiseres i faste perioder kalt sprinter.
Kryssfunksjonelle team	Teamet skal samlet ha kompetansen som trengs.
Sprinter	Korte, faste iterasjoner.
Inkrementell fremgang	Produktet forbedres litt etter litt.
Sprint planning	Planlegging av hva som skal gjøres i sprinten.
Daily standup / daily scrum	Kort daglig møte for koordinering.
Sprint review	Gjennomgang av resultatet med interessenter.
Retrospektiv	Refleksjon over hvordan teamet kan forbedre arbeidsprosessen.
Product backlog	Prioritert liste over alt som kan gjøres i produktet.
Sprint backlog	Utvalget av arbeid som tas inn i en sprint.
Product backlog items (PBI)	Enkeltenheter i product backlog.
Scrum board	Visuell tavle for oppgaver i sprinten.
Eliminate waste	Fjern arbeid som ikke gir verdi.
Build quality in	Kvalitet skal bygges inn i prosessen, ikke bare sjekkes til slutt.
Create knowledge	Læring og tilbakemelding skal brukes aktivt.
Defer commitment	Vent med irreversible valg til man vet mer.
Deliver fast	Lever verdi raskt.
Respect people	Stol på og støtt menneskene i systemet.
Optimize the whole	Se helheten, ikke bare enkeltledd.
Flytbasert	Fokus på jevn gjennomstrømning av arbeid.
Kontinuerlig levering	Arbeid leveres fortløpende.
Ingen faste iterasjoner	I motsetning til Scrum er det ikke sprinter som styrer.
Visuell styring	Tavler brukes for å se status og flyt.
Kanban-board	Tavle som visualiserer arbeidsflyten.
Begrensning av arbeid i prosess (WIP)	Setter grenser for hvor mange oppgaver som kan være i arbeid samtidig.
Fokus på flaskehalser	Prosessen forbedres der arbeidet stopper opp.
Synliggjøre flaskehalser	Gjør problemer i flyten tydelige.
Forbedre flyt	Reduserer opphopning av arbeid.
Hjelpe teammedlemmer å bidra der det stopper opp	Fremmer samarbeid på tvers.
Høyt fokus på domenet	Utviklingen tar utgangspunkt i problemområdet.
Koden skal gjenspeile virkeligheten	Modell og kode bør bruke samme begreper som domenet.
Egnet for skalering og endring	God domeneforståelse gjør videreutvikling lettere.
Fokus på det viktigste i domenet	Prioriterer kjernebegreper og kjerneprosesser.
Utvikling (Dev)	Bygging og forbedring av programvare.
Drift (Ops)	Utrulling, overvåking og vedlikehold i drift.
Kontinuerlig integrasjon	Kode integreres ofte.
Kontinuerlig levering / deploy	Kode kan leveres raskt og trygt.
Tettere samarbeid mellom utvikling og drift	Færre siloer mellom team.
Hyppig integrasjon til felles gren	Små endringer flettes ofte inn.
Automatisk bygging	Systemet bygges automatisk ved endringer.
Automatisk testing	Tester kjøres automatisk som del av bygget.
Automatisk levering / deploy av kodeendringer	Endringer kan settes i drift med mindre manuelt arbeid.
GitLab / GitHub	Versjonskontroll og samarbeid.
Jira / Confluence	Planlegging og dokumentasjon.
Maven	Byggverktøy for Java.
Gradle	Fleksibelt byggverktøy.
Jenkins	Automatiserings- og CI-server.
JUnit	Testverktøy for Java.
Selenium	Verktøy for automatisert system-/UI-testing.
Helm	Pakkebehandling for Kubernetes.
Kibana	Visualisering av logger og søk.
Grafana	Visualisering av målinger og monitorering.
Klient-tjener	Klient og server har ulike roller og ansvar.
Ressurser identifiseres via URI-er	Data og funksjonalitet modelleres som ressurser.
Ressurser manipuleres via HTTP-metoder	Standardiserte operasjoner brukes for å hente og endre data.
GET	Hente data.
POST	Opprette ny ressurs.
PUT	Oppdatere eller erstatte ressurs.
DELETE	Slette ressurs.
Sikre riktig respons ved input/interaksjon	Systemet må reagere riktig på brukerhandlinger.
Finne bugs	Feil må oppdages før brukerne gjør det.
Verifisere ytelse under edge cases	Systemet må tåle vanskelige situasjoner.
Vurdere brukervennlighet	Løsningen må være god å bruke.
Kontrollere at krav er oppfylt	Systemet må gjøre det som er avtalt.
Kontrollere at systemet kan installeres i riktig miljø	Løsningen må fungere der den skal kjøres.
Kontrollere at systemet tåler endringer	Videreutvikling må ikke ødelegge eksisterende funksjonalitet.
Testing shows the presence of defects	Testing kan vise at feil finnes, ikke bevise at ingen feil finnes.
Exhaustive testing is impossible	Det er umulig å teste absolutt alt.
Early testing	Testing bør starte tidlig.
Defects clustering	Mange feil samler seg ofte i få deler av systemet.
Pesticide paradox	Samme tester finner færre nye feil over tid.
Testing is context dependent	Teststrategi må tilpasses situasjonen.
Absence of error fallacy	Et feilfritt system er ikke nyttig hvis det løser feil problem.
Utvikling og testing skjer separat	Et team lager systemet, et annet tester det.
QA-team kvalitetssikrer etter utvikling	Test kommer ofte sent i prosessen.
Mye tid går til kommunikasjon og overlevering	Feil blir dyrere og tregere å håndtere.
Utviklere tester egen kode kontinuerlig	Test skjer parallelt med utvikling.
Små inkrementer	Mindre endringer testes og leveres ofte.
Automatiserte tester brukes mye	Rask feedback er viktig.
Raskere feedback	Feil oppdages tidlig.
Tettere kobling mellom utvikling og kvalitet	Kvalitet bygges inn underveis.
QA kan fokusere på viktige scenarioer	Manuell test kan brukes der den gir mest verdi.
Ved opprettelse av pull request	Nye endringer testes før sammenslåing.
I CI-pipelines	Test inngår i automatisert byggflyt.
Ved nye kodeendringer	Hyppig kjøring gir rask tilbakemelding.
Enhetstester og integrasjonstester kjøres automatisk	Vanlige testnivåer for automatisering.
Resultater rapporteres raskt	Utviklere får rask oversikt over feil.
Rask feedback	Feil oppdages tidlig.
Høy hastighet	Mange tester kan kjøres fort.
Kontinuerlig kontroll	Kvalitet følges opp automatisk.
Forutsigbar kvalitet	Samme test kjøres likt hver gang.
Kostnadsbesparende over tid	Reduserer manuelt repeterende arbeid.
Høy oppstarts- og vedlikeholdskostnad	Testene må bygges og holdes oppdatert.
Krever riktig fokus og god testdesign	Dårlige automatiserte tester gir liten verdi.
Testmiljø speiler produksjonsmiljø	Test skjer i omgivelser som ligner virkeligheten.
Hele applikasjonen kan testes før release	Gir helhetlig kontroll.
Mer realistisk testing	Større sjanse for å finne reelle feil.
QA kan teste hele applikasjonen	Også på systemnivå.
Infrastructure as Code gjør oppsett enklere	Miljøer kan opprettes og vedlikeholdes systematisk.
Mindre diff mellom gammel og ny versjon	Endringer blir lettere å forstå.
Enklere isolering av feil	Lettere å finne hva som gikk galt.
Enklere sporing av endringer	Bedre oversikt over historikk.
Lavere sannsynlighet for feil	Små endringer er lettere å kontrollere.
Enklere rollback	Enklere å rulle tilbake en liten endring.
Finn riktig nivå på testdekning basert på risiko	Ikke alt må testes like mye.
Prioriter tester som gir størst verdi	Test der konsekvensen av feil er størst.
Prioriter tester som reduserer mest usikkerhet	Test der du vet minst eller er mest utsatt.
Risiko	Sannsynlighet for at noe går galt.
Konsekvens	Hvor alvorlig det blir hvis det går galt.
Risikofaktorer	Forhold som påvirker sannsynlighet eller konsekvens.
Hele teamet deltar	Flere perspektiver tas med.
Bedre treffsikkerhet	Samlet vurdering blir ofte bedre enn individuell.
Felles forståelse av risiko	Teamet blir enige om hva som er kritisk.
Samme data hver gang	Testresultater kan sammenlignes.
Deterministisk prosess	Samme input gir samme output.
Forutsigbart testmiljø	Eksterne tilfeldigheter påvirker minst mulig.
Enklere å isolere feil	Avvik blir lettere å forklare.
Mer presise testresultater	Resultatene blir mer pålitelige.
Bedre analyse av testutfall	Utviklere kan tolke funn mer sikkert.
Erstatte ekte og komplekse avhengigheter	Bytte ut systemer som er vanskelige eller upraktiske å bruke i test.
Isolere klasser / moduler i test	Teste én del uten ekte avhengigheter.
Database	Unngå ekte database i test.
Eksternt API	Unngå nettverkskall og ustabile svar.
Betalingstjeneste	Simulere betaling uten ekte transaksjoner.
Deterministiske svar	Testene får samme respons hver gang.
Samme grensesnitt som ekte avhengighet	Kan byttes inn uten å endre resten av koden.
Kombineres godt med dependency injection	Avhengigheter kan settes inn ved kjøring.
Muliggjør isolert testing	Én del kan testes alene.
Gjør automatiserte tester mulige i flere situasjoner	Flere deler blir testbare.
Gir kontroll over testmiljøet	Reduserer usikkerhet i testkjøringen.
Oppsett	Forbered testdata og testmiljø.
Gjennomføring	Utfør handlingene testen beskriver.
Verifisering	Kontroller at resultatet ble som forventet.
Opprydding	Fjern eller nullstill ressurser for neste test.
Tester individuelle klasser / funksjoner	Små deler testes isolert.
Fokus på små enheter	Enkel funksjonalitet står i sentrum.
Ofte utviklers ansvar	Utvikleren skriver og vedlikeholder testene.
Automatisert	Enkelt å kjøre ofte.
Repeterbar	Gir like resultater ved samme input.
Kjøres i byggeprosessen	Naturlig del av utviklingsflyten.
Finne feil tidlig	Feil fanges før de sprer seg.
Stoppe feil før integrasjon med andre deler	Hindrer at små feil blir større problemer.
Tester samspill mellom komponenter	Ser på hvordan delene virker sammen.
Bygger på at delene allerede er testet individuelt	Enhetstesting bør være gjort først.
Oppdage feil i grensesnitt og samhandling	Avdekke problemer i koblinger mellom delene.
Kan automatiseres	Mange integrasjonstester egner seg for automatisering.
Bør automatiseres der det er hensiktsmessig	Særlig ved hyppige og kritiske samspill.
Tester hele systemet	Systemet ses som en helhet.
Sjekker at alle deler fungerer sammen	Helhetlig kvalitet kontrolleres.
Finner feil mellom deler av systemet	Noen problemer oppstår bare i helheten.
Gir trygghet før levering	Bedre grunnlag for release.
Sjekke at systemet oppfyller krav	Både funksjonelle og ofte ikke-funksjonelle krav.
Finne feil før bruk	Redusere risiko før sluttbruker møter løsningen.
Kan utføres med verktøy som Selenium	Mulig å automatisere deler av helheten.
Kan være vanskelig å gjøre helt repeterbar	Mange avhengigheter påvirker resultatet.
Type systemtesting	Skjer på høyt nivå i systemet.
Utføres for å verifisere at krav er oppfylt	Spesielt mot kundens eller brukerens forventninger.
Bygger på user stories	Kobling mellom krav og test.
Kan utvikles sammen med kunden	Gir bedre samsvar med behov.
Manuell	Mennesker går gjennom scenarier.
Automatisert	Scenarioer kan kjøres som automatiske tester.
Tester at endringer ikke ødelegger eksisterende funksjonalitet	Gammel funksjon må fortsatt virke etter endringer.
Før og etter endringer	For å sammenligne oppførsel.
Kontinuerlig i CI ved innsjekk av kode	Skjer ofte automatisk i moderne utvikling.
Enhetstestnivå	Små deler testes på nytt.
Integrasjonsnivå	Samspill testes på nytt.
Akseptansenivå	Brukerorientert oppførsel testes på nytt.
Egner seg godt for automatisering	Samme tester kjøres mange ganger.
Tester kritisk funksjonalitet	Sjekker at systemets viktigste deler virker.
Rask sjekk av om systemet i det hele tatt fungerer	Avgjør om videre testing er verdt å starte.
Tester ny eller endret funksjonalitet	Fokuserer på siste endring.
Rask sjekk av om en spesifikk endring virker fornuftig	Smalere enn smoke-testing.
Avdekker tidlig om videre testing er hensiktsmessig	Sparer tid hvis systemet er for ustabilt.
Kreativ testing for å få systemet til å feile	Tester bevisst grensene.
Kan ikke automatiseres	Bygger på menneskelig kreativitet.
Krever menneskelig erfaring og kreativitet	Testeren må tenke utradisjonelt.
Tester med aktiv læring og utforsking underveis	Testdesign og gjennomføring skjer samtidig.
Bygger på innsikt i systemet og nye hypoteser	Man følger spor som dukker opp.
Destruktiv testing: fokus på å bryte systemet	Målet er å finne svakheter ved å presse løsningen.
Utforskende testing: bredere utforsking og læring	Målet er både forståelse og feilfunn.
Brukervennlighet	Hvor lett systemet er å bruke.
GUI	Hvordan det grafiske brukergrensesnittet fungerer.
Om brukeren / kunden er fornøyd	Opplevd kvalitet og tilfredshet.
Hvor mye last systemet tåler	Kapasitet under normal eller høy belastning.
Hvor mye plutselig last systemet tåler	Reaksjon på raske topper.
Ytelse over tid	Stabilitet og ressursbruk ved langvarig drift.
Lekkasjer / ressursproblemer	Oppdage for eksempel minnelekkasjer.
Antall samtidige brukere	Hvor mange som bruker systemet samtidig.
Transaksjoner per tidsenhet	Hvor mye arbeid systemet utfører per tidsrom.
Throughput	Mengde data eller arbeid som behandles over tid.
Responstid	Hvor lang tid systemet bruker på å svare.
Systemets svakeste / tregeste punkt	Delen som begrenser total ytelse.
Det som begrenser total ytelse	Det som holder resten tilbake.
CPU	Prosessoren er overbelastet.
Minne	For lite eller ineffektiv bruk av RAM.
Tråder	Dårlig håndtering av parallellitet eller venting.
Databasetilkobling	Database eller forbindelser blir begrensningen.
Lasttest	Måler oppførsel ved forventet eller gradvis økende last.
Stresstest	Finner yttergrensen der systemet bryter sammen.
Spike-test	Tester reaksjon på plutselige lasttopper.
Utholdenhetstest	Tester systemet under jevn belastning over tid.
Ingen innsikt i intern kode	Testeren ser bare input og output.
Bygger på krav, spesifikasjoner og forventet oppførsel	Ikke på intern implementasjon.
Full innsikt i intern kode og struktur	Testeren kjenner logikken og oppbygningen.
Tester intern logikk og oppbygning	Dekker veier, betingelser og intern struktur.
Raske	Kan kjøres ofte og på kort tid.
Nøyaktige	Samme fremgangsmåte hver gang.
Repeterbare	Resultatene blir konsistente.
Gode for kjente forventninger	Passer godt der riktig resultat er tydelig definert.
Enhetstester	Små isolerte kodeenheter.
Regresjonstester	Sjekk av at gammel funksjonalitet fortsatt virker.
Mange integrasjonstester	Testing av samspill mellom komponenter.
Mange ytelsestester	Automatiske last- og stresstester.
Krever vedlikehold	Testene må oppdateres når systemet endres.
Fanger ikke alt	Særlig dårlig på subjektive forhold.
Dårligere på kreative og uventede problemer	Mennesker er bedre til utforskning.
Kreative	Testeren kan tenke fritt og prøve uventede ting.
Fanger ofte naturlige brukerfeil og uventede problemer	Realistisk menneskelig bruk avdekkes bedre.
Gode for utforsking og opplevelse	Særlig viktig for usability og ad hoc-testing.
Utforskende testing	Læring og test skjer samtidig.
Destruktiv testing	Kreativ testing for å bryte systemet.
Mye usabilitytesting	Vurdering av opplevelse og brukeradferd.
Smoke-testing	Raske helsesjekker av løsning.
Sanity-testing	Raske sjekker av endret funksjonalitet.
Integrasjonstesting	Samspill mellom komponenter.
Systemtesting	Helhetlig testing av systemet.
Akseptansetesting	Verifisering mot behov og krav.
Ytelsestesting	Måling av kapasitet og responstid.
Lovlighet, rimelighet og gjennomsiktighet	Behandling må være lovlig, rettferdig og forståelig for den registrerte.
Formålsbegrensning	Data skal bare brukes til tydelig definerte formål.
Dataminimering	Bare nødvendige opplysninger skal samles inn.
Riktighet	Opplysninger skal være korrekte og oppdaterte.
Lagringsbegrensning	Data skal ikke lagres lenger enn nødvendig.
Integritet og konfidensialitet	Data skal beskyttes mot uautorisert tilgang og tap.
Ansvarliggjøring	Virksomheten må kunne dokumentere at reglene følges.
Rett til informasjon	Få vite hvilke data som behandles og hvorfor.
Rett til innsyn	Få tilgang til egne opplysninger.
Rett til retting	Få uriktige opplysninger korrigert.
Rett til sletting	Kreve at opplysninger fjernes i visse tilfeller.
Rett til begrensning	Kreve at behandling stoppes midlertidig.
Rett til å protestere	Motsette seg visse typer behandling.
Rett til dataportabilitet	Få egne data ut i et maskinlesbart format.
Juridisk forpliktelse	Behandling kan være nødvendig for å oppfylle lovkrav.
Offentlig sikkerhet	Noen rettigheter kan begrenses av samfunnshensyn.
Forskning	Særregler kan gjelde ved forskning og statistikk.
Sosialt ansvar	Teknologi påvirker samfunn, arbeidsliv og mennesker.
Sikkerhet og pålitelighet	Systemer må være trygge og til å stole på.
Brukeres velferd	Løsninger må ikke skade brukerne eller deres livssituasjon.
AI og militær bruk / alvorlige konsekvenser av teknologi	Utviklere må reflektere over alvorlige anvendelser og ansvar.
Vise respekt for kolleger	Rettferdig og profesjonell behandling av andre.
Vedkjenne seg faglig ansvar	Stå inne for eget arbeid og egne vurderinger.
Følge anerkjente kvalitetsnormer	Bruke faglig gode standarder og praksiser.
Bidra til åpenhet om teknologiske konsekvenser	Ikke skjule risiko eller negative effekter.
Samfunn	Arbeid i offentlighetens interesse.
Kunde og arbeidsgiver	Opptre ansvarlig overfor dem man arbeider for.
Produkt	Sikre høy kvalitet i programvare og løsninger.
Vurdering	Utvise integritet og faglig skjønn.
Ledelse	Fremme etisk ledelse i utviklingsarbeid.
Profesjon	Styrke profesjonens integritet og omdømme.
Kolleger	Støtte og behandle kolleger rettferdig.
Egen utvikling / livslang læring	Holde seg faglig oppdatert og utvikle seg videre.
Ærlighet og integritet	Vær sannferdig om begrensninger og risiko.
Respekt for personvern	Bygg løsninger som beskytter individet.
Kvalitetsbevissthet	Arbeid systematisk for god kvalitet.
Ansvar for konsekvenser	Vurder hvordan teknologien påvirker mennesker og samfunn.
Kontinuerlig vurdering	Etiske vurderinger må gjøres gjennom hele prosessen.
Mer robuste systemer	Etisk bevissthet gir ofte bedre designvalg.
Færre sikkerhets- og personvernbrudd	Risiko håndteres tidligere.
Høyere brukertilfredshet	Brukere stoler mer på løsningen.
Beskytter omdømme	Både utviklere og virksomheter unngår tillitstap.
Reduserer risiko for bias og tillitsbrudd	Færre urettferdige eller skadelige løsninger.
Formål	Hvorfor prosjektet finnes.
Omfang	Hva prosjektet skal og ikke skal dekke.
Hensikt	Hva man ønsker å oppnå.
Målgruppe	Hvem løsningen er for.
Funksjonelle krav	Hva systemet skal gjøre.
Ikke-funksjonelle krav	Kvalitetskrav som ytelse, sikkerhet og brukervennlighet.
Interessenter	Personer eller grupper som påvirkes av prosjektet.
Brukerbehov	Behovene løsningen skal dekke.
Identifisere risiko	Finne mulige problemer.
Prioritere risiko	Vurdere hva som er viktigst å håndtere.
Definere tiltak	Bestemme hva man skal gjøre med risikoene.
Forbedre beslutningsprosesser	Gi bedre grunnlag for valg.
Øke prosjektets robusthet	Gjøre prosjektet bedre rustet mot problemer.
```

Hvis du vil, kan jeg også lage en **renset TSV v2** der jeg:
- fjerner duplikater,
- standardiserer begrepene,
- og gjør dem mer “flashcard-vennlige” med kortere definisjoner.

## @real-eo

ja, lag en v2. men ikke gjør dem kortere, men mer konsise uten å fjerne fagbegrep 

## Copilot

Her er en **renset TSV v2** med:
- **duplikater fjernet**
- **begreper standardisert**
- **definisjoner gjort mer konsise**, uten å gjøre dem kortere på en måte som fjerner faginnhold
- **fagbegreper beholdt**

```tsv name=quizlet-begreper-v2.tsv
Definer krav	Avklare brukerbehov, mål og rammer for løsningen.
Design alternativer	Utvikle flere mulige forslag til hvordan løsningen kan fungere.
Lag prototype	Gjøre designet konkret i en enkel eller avansert modell.
Evaluer	Vurdere om løsningen fungerer for brukerne og oppfyller kravene.
Ord	Tekst og språk som brukes i grensesnittet.
Visuelle representasjoner	Ikoner, farger, bilder, typografi og andre grafiske elementer i grensesnittet.
Fysiske objekter og rom	Den fysiske konteksten eller enheten brukeren samhandler gjennom.
Tid	Hvordan interaksjonen utvikler seg over tid, for eksempel animasjoner, lyd og responstid.
Atferd	Hvordan systemet oppfører seg, og hvilke reaksjoner og opplevelser dette skaper hos brukeren.
Synlighet	Funksjoner og muligheter skal være lette å oppdage.
Feedback	Systemet skal gi tydelig tilbakemelding på hva som skjer.
Begrensninger	Designet bør begrense feil handlinger og lede brukeren i riktig retning.
Avbilding (mapping)	Sammenhengen mellom kontroll og effekt bør være intuitiv.
Konsistens	Like ting bør fungere likt i hele systemet.
Tilbydelser / affordances	Designet skal signalisere hvilke handlinger som er mulige.
Utseende	Hvordan prototypen ser ut visuelt.
Innhold	Hvilken informasjon og hvilke elementer som er med i prototypen.
Funksjonalitet	Hvilke funksjoner som er simulert eller implementert i prototypen.
Interaktivitet	Hvor mye brukeren faktisk kan gjøre i prototypen.
Romlig struktur	Hvordan skjermbilder, elementer eller deler av løsningen er organisert.
Horisontal prototype	Bred prototype med mange funksjonsområder, men liten dybde.
Vertikal prototype	Smal prototype som går i detalj og dybde på én funksjon.
Evolusjonær prototype	Prototype som videreutvikles til en del av sluttproduktet.
Bruk-og-kast-prototype	Prototype som brukes til læring og deretter forkastes.
Lavoppløselig prototype	Enkel prototype med lite detalj og lite interaksjon, for eksempel en papirskisse.
Høyoppløselig prototype	Mer realistisk prototype med mye detalj og ofte mer interaksjon.
Testing	Verifisering av om systemet fungerer teknisk riktig.
Evaluering	Vurdering av om løsningen er nyttig, brukbar og riktig for behovet.
Formativ evaluering	Evaluering underveis for å forbedre løsningen mens den utvikles.
Summativ evaluering	Evaluering av en ferdig løsning for å vurdere sluttresultatet.
Brukertest	Brukere utfører oppgaver mens man observerer problemer og atferd.
A/B-test	To eller flere varianter sammenlignes for å se hvilken som fungerer best.
Feltstudie	Evaluering i brukerens naturlige omgivelser.
Opportunistisk evaluering	Rask tilbakemelding fra brukere på en idé eller problemstilling.
Heuristisk gjennomgang	Eksperter vurderer løsningen ut fra etablerte brukbarhetsprinsipper.
Prediktive modeller	Analytiske eller beregnende modeller som brukes til å forutsi brukeropplevelse eller ytelse.
Pluralistisk gjennomgang	Brukere, utviklere og eksperter går sammen gjennom scenarioer og vurderer løsningen.
Observasjon	Se hvordan brukeren faktisk oppfører seg.
Spørre brukere	Samle innsikt gjennom intervju, samtale eller spørreskjema.
Direkte testing	Brukeren prøver konkrete oppgaver i løsningen.
Spørre eksperter	Hente vurderinger fra fagpersoner.
Modellering	Bruke modeller til å analysere eller forutsi bruk.
Kodevalidering	Sjekk av om kode og struktur følger krav eller standarder.
Testing i ulike nettlesere og på ulike plattformer	Sjekk av kompatibilitet på tvers av miljøer.
Testing av fleksibiliteten til et design	Vurdering av hvor godt designet fungerer under ulike forhold.
Testing av grad av universell utforming / brukskvalitet	Sjekk av tilgjengelighet og brukervennlighet.
Testing av feilmeldinger	Vurdering av om feilmeldinger er tydelige og hjelpsomme.
Konkret hensikt	Testen skal ha et tydelig mål.
Avgrenset formål	Man tester noe spesifikt, ikke alt samtidig.
Realistiske oppgaver	Oppgavene bør ligne ekte brukssituasjoner.
Observasjon av brukeren	Man ser hva brukeren faktisk gjør, ikke bare hva brukeren sier.
Enkel og intuitiv i bruk	Løsningen skal være lett å forstå.
Forståelig informasjon	Nødvendig informasjon skal kommuniseres tydelig.
Toleranse for feil	Designet skal redusere risiko og konsekvenser av feil.
Like muligheter for alle	Løsningen skal kunne brukes av personer med ulike ferdigheter.
Fleksibel i bruk	Løsningen skal støtte ulike preferanser og måter å bruke systemet på.
Lav fysisk anstrengelse	Løsningen skal kunne brukes med minst mulig belastning.
Størrelse og plass for tilgang og bruk	Fysisk og visuell utforming skal støtte tilgang og bruk.
Tilgang	Brukeren skal kunne nå og oppfatte løsningens elementer.
Rekkevidde	Brukeren skal kunne komme til funksjonene uavhengig av kroppslige forutsetninger.
Betjening og bruk	Løsningens elementer skal kunne brukes praktisk og sikkert.
Mer inkluderende	Flere mennesker kan bruke løsningen.
Enklere å bruke	God struktur og navigasjon hjelper alle brukere.
Mer mobiltilpasset	Tilgjengelige løsninger fungerer ofte bedre på små skjermer.
Mer synlig for Google / bedre SEO	God struktur og semantikk hjelper søkemotorer.
Mer lønnsomt	Flere brukere når fram, og supportbehov kan reduseres.
Mulig å oppfatte (Perceivable)	Innhold må kunne oppfattes av brukeren.
Mulig å betjene (Operable)	Grensesnittet må kunne brukes og navigeres.
Forståelig (Understandable)	Innhold og funksjonalitet må være forståelige.
Robust	Løsningen må fungere med ulike nettlesere og hjelpemidler.
Innhold tilgjengelig via tastatur	Brukeren skal ikke være avhengig av mus.
Alternativ tekst på bilder	Skjermlesere må kunne formidle bildeinnhold.
Teksting eller alternativ lyd på video	Innholdet må være tilgjengelig ved ulike behov.
Skjema og formater lette å forstå	Brukerens oppgaver må være tydelige.
Innhold lett å forstå	Språk og struktur må støtte forståelse.
Use case-diagram	Viser aktører og hvilke mål eller funksjoner de bruker systemet til.
Domenemodell	Viser sentrale begreper i domenet og relasjonene mellom dem.
Sekvensdiagram	Viser meldinger og samspill mellom deltakere over tid.
Aktivitetsdiagram	Viser flyt av aktiviteter, beslutninger og parallelle handlinger.
Klassediagram	Viser klasser, attributter, metoder og relasjoner.
Pakkediagram	Viser hvordan elementer grupperes i pakker eller moduler.
Tilstandsmaskindiagram	Viser tilstander og overganger for et objekt eller system.
Deltakere	Aktører, objekter eller komponenter som deltar i samspillet.
Meldinger / funksjonskall	Kommunikasjon mellom deltakerne.
Levetidslinje	Stiplet linje som viser deltakerens eksistens over tid.
Aktiveringsboks	Viser når en deltaker utfører arbeid.
Rammer	Markerer kontrollstrukturer som valg eller repetisjon.
Aksjoner	Konkrete handlinger eller steg i en prosess.
Initial node	Startpunktet for aktiviteten.
Final node	Sluttpunktet for aktiviteten.
Decision node	Punkt der prosessen forgrenes ut fra betingelser.
Fork node	Deler prosessen i parallelle løp.
Join node	Samler parallelle løp igjen.
Merge node	Slår sammen alternative flyter.
Overganger / piler	Viser rekkefølge og flyt mellom aktiviteter.
Klasse	En type objekt med data og atferd.
Attributter	Data som hører til klassen.
Metoder	Funksjoner eller operasjoner klassen kan utføre.
Avhengighet (dependency)	En svak kobling der én klasse bruker en annen.
Assosiasjon	En strukturell kobling mellom to klasser.
Aggregering	Hel-del-relasjon der delen kan eksistere uten helheten.
Komposisjon	Sterk hel-del-relasjon der delen hører tett til helheten.
Arv / generalisering	En subklasse arver fra en superklasse.
Realisering	En klasse implementerer et grensesnitt.
Starttilstand	Tilstanden systemet eller objektet starter i.
Sluttilstand	Tilstanden der livsløpet avsluttes.
Tilstander	Ulike situasjoner objektet kan befinne seg i.
Overganger	Bevegelser fra én tilstand til en annen.
Triggere / hendelser	Det som utløser en overgang.
Som [rolle]	Beskriver hvem brukeren er.
vil jeg [mål/ønske]	Beskriver hva brukeren ønsker å gjøre.
slik at [nytte/verdi]	Beskriver hvorfor dette er viktig.
Forstå systemet tidlig	Gjør det lettere å se helheten før implementasjon.
Redusere kostnader	Tidlige gode valg sparer tid og penger senere.
Unngå duplisering av ressurser	Tydelig struktur reduserer overlappende løsninger.
Øke kvalitet	Bedre struktur gir bedre vedlikeholdbarhet og testbarhet.
Hjelpe risikostyring	Man oppdager tekniske utfordringer tidligere.
Støtte kommunikasjon mellom interessenter	Gir et felles bilde av systemet.
Gi retningslinjer for utviklere	Hjelper teamet å utvikle konsistent.
Splitt og hersk	Dele opp problemet i mindre deler.
Lav kobling	Delene bør være minst mulig avhengige av hverandre.
Mer testbar kode	Mindre og tydeligere deler er enklere å teste.
Mer robust kode	Isolerte deler tåler endringer bedre.
Enklere delegering av ansvar	Team kan jobbe med ulike deler parallelt.
Presentasjonslag	Viser informasjon og håndterer brukerinteraksjon.
Forretningslogikklag	Utfører regler, prosessering og kjernefunksjonalitet.
Data access-lag	Håndterer lagring, henting og oppdatering av data.
Hvert lag har spesifikt ansvar	Gjør systemet mer oversiktlig.
Hvert lag yter tjenester til laget over / bruker laget under	Gir strukturert avhengighet.
Master	Styrer, fordeler arbeid og samler resultater.
Slave	Utfører arbeid delegert av master.
Tydelig oversikt i master	Gir sentral kontroll over prosessen.
Slaver kan enhetstestes separat	Hver del kan testes isolert.
Master kan integrasjonstestes mot slavene	Samspillet kan testes samlet.
Event listener	Lytter etter hendelser.
Event source	Produserer eller sender hendelser.
Channel	Kanal eller emne der hendelser publiseres.
Event bus	Infrastrukturen som frakter hendelser mellom kilder og lyttere.
Model	Data og forretningslogikk.
View	Det brukeren ser i grensesnittet.
Controller	Håndterer input og styrer flyten mellom model og view.
Høyere kohesjon	Hver del får tydeligere ansvar.
Gjenbrukbarhet	Deler kan lettere brukes på nytt.
Skille ansvar	Gjør systemet enklere å forstå og endre.
Single Responsibility Principle	Hver tjeneste bør ha ett tydelig hovedansvar.
Selvstendige tjenester	Hver tjeneste kan utvikles og driftes separat.
Én hovedoppgave per tjeneste	Tydelig ansvarsdeling.
Egen data	Tjenesten eier vanligvis sin egen datalagring.
Eget kjøremiljø	Tjenesten kan kjøres og deployes uavhengig.
Skalerbart	Tjenester kan skaleres separat.
Modulært	Systemet deles i mindre moduler.
Fleksibel teknologibruk	Ulike tjenester kan bruke ulik teknologi.
Høy tilgjengelighet / feilisolering	Feil i én tjeneste stopper ikke nødvendigvis hele systemet.
Støtter kontinuerlig levering (CI/CD)	Tjenester kan oppdateres uavhengig.
Passer DevOps	Tett kobling mellom utvikling, drift og deploy.
Kompleks debugging	Feilsporing på tvers av tjenester er vanskeligere.
Kompleks logging på tvers av tjenester	Data om feil og flyt spres i flere systemer.
Krever automatisering	Bygg, test og deploy må ofte automatiseres sterkt.
Vanskelig å teste distribuerte systemer	Mange avhengigheter og miljøer kompliserer testarbeidet.
Datainkonsistens	Data er fordelt og kan komme ut av synk.
Økt ressursforbruk	Mange tjenester krever mer infrastruktur.
Monolittarkitektur	Arkitektur der alle deler av systemet er samlet i én applikasjon.
God gjennomstrømning / lite overhead	Mindre kommunikasjon mellom separate tjenester gir mindre overhead.
Enklere å teste og debugge i starten	Alt er samlet i én applikasjon.
Vanskeligere å vedlikeholde ved vekst	Systemet blir tungt å endre når det blir stort.
Lite skalerbar	Hele systemet må ofte skaleres samlet.
Lite utvidbar sammenlignet med modulære løsninger	Struktur og vekst blir vanskeligere å håndtere.
Tett koblet	Delene er ofte sterkt avhengige av hverandre.
Feil i én del kan stoppe hele systemet	Svak isolasjon av feil gir større konsekvenser.
Kjerne-system	Grunnsystemet som gir basisfunksjonalitet.
Plugin-moduler / extensions	Tillegg som utvider funksjonaliteten.
Høy isolasjon mellom funksjoner	Endringer i én plugin trenger ikke påvirke andre.
Fleksibelt	Funksjonalitet kan legges til eller fjernes.
Utvidbart	Systemet kan vokse gjennom nye plugins.
Endringer i kjernen kan ødelegge plugins	Bakoverkompatibilitet blir viktig.
Mange plugins kan redusere ytelsen	Ekstra moduler kan gi mer belastning.
Kompleks testing av hele systemet	Mange kombinasjoner og avhengigheter må testes.
Chrome Web Store	Eksempel på plattform for nettleserutvidelser.
IntelliJ	Eksempel på IDE med mange utvidelser.
VS Code	Eksempel på editor med plugin-system.
Eclipse	Eksempel på utviklingsmiljø bygget rundt plugins.
Tradisjonell deployment	Applikasjoner kjøres direkte på fysiske servere.
Ressursallokering kan bli ineffektiv	Det er vanskelig å fordele kapasitet godt på fysiske servere.
Én applikasjon kan ta for mye kapasitet	Andre systemer kan påvirkes negativt.
Virtualisering (VMs)	Flere virtuelle maskiner kjøres på én fysisk server.
Hver VM har eget operativsystem	Gir sterk isolasjon mellom miljøene.
Ressurser reserveres selv om de ikke brukes	Effektiviteten kan bli lav i virtuelle miljøer.
Container-deployment	Containere deler operativsystem, men er isolerte.
Containere deler OS, men er isolerte	Gir lettere isolasjon enn full virtualisering.
Lettere enn virtuelle maskiner	Mindre overhead og raskere oppstart.
Docker	Teknologi for å bygge og kjøre containere.
Kubernetes	Plattform for orkestrering og styring av containere.
Enkel distribusjon	Løsningen er lett å flytte og kjøre flere steder.
Konsistent kjøremiljø	Løsningen fungerer likt i ulike miljøer.
Løst koblet	Tjenester kan holdes adskilt.
Distribuert	Egnet for moderne distribuerte systemer.
Elastisk	Kapasitet kan justeres dynamisk.
Vannfallsmodellen	Sekvensiell utviklingsmodell med faste faser.
Unified Process (UP)	Iterativ prosess med mye modellering og struktur.
Problem based	Store problemer brytes ned i mindre deler.
Collaborative	Flere roller samarbeider tett gjennom hele prosessen.
Iterativ	Løsningen utvikles og forbedres i gjentatte runder.
Adaptiv	Planen og løsningen tilpasses ny læring og endring.
Individer og interaksjoner fremfor prosesser og verktøy	Mennesker og samarbeid prioriteres over rigide prosesser og verktøy.
Fungerende programvare fremfor omfattende dokumentasjon	Praktisk verdi prioriteres over tung dokumentasjon.
Kundesamarbeid fremfor kontraktsforhandlinger	Kontinuerlig dialog er viktigere enn låste avtaler.
Reagere på endring fremfor å følge en plan	Tilpasning er viktigere enn rigid planfølgning.
Lite dokumentasjon	Fokus på kode og praksis framfor tunge dokumenter.
Lite modellering	Mindre vekt på omfattende forhåndsmodellering.
Tett feedback-loop	Raske tilbakemeldinger fra tester, kode og kunde.
Kort iterasjonstid	Små og hyppige leveranser.
29 regler	XP beskrives ofte som en metode med mange konkrete arbeidsregler.
Parprogrammering	To utviklere jobber sammen ved samme oppgave.
Skriv enhetstester før kode	Test først for å styre utviklingen.
Integrer én liten endring av gangen	Små endringer gjør feil lettere å oppdage.
Enkel og tydelig kode	Løsningen skal være så enkel som mulig.
Hyppig refaktorering	Forbedre kode kontinuerlig uten å endre atferd.
Korte feedback-looper	Rask respons på endringer og feil.
Hyppige tester	Kvalitet kontrolleres kontinuerlig.
Hyppige leveranser	Verdi leveres ofte.
Communication	Tydelig kommunikasjon i teamet.
Simplicity	Hold løsningen enkel.
Courage	Tør å endre og forbedre kode når det trengs.
Respect	Respekt for teamet, koden og arbeidet.
Skriv test først	Definere forventet oppførsel før implementasjon.
Kjør testen og se at den feiler	Bekrefte at testen faktisk fanger manglende funksjonalitet.
Skriv kode som får testen til å bestå	Implementere minimum som trengs for å få testen grønn.
Refaktorer	Forbedre koden uten å endre funksjonaliteten.
Primært enhetstesting	TDD brukes hovedsakelig på små isolerte funksjoner eller klasser.
Noen ganger integrasjonstesting	TDD kan i enkelte tilfeller brukes bredere enn enhetstester.
Sjelden systemtesting	TDD brukes oftest nær kodenivå, ikke på helsystemnivå.
Bedre kodekvalitet	Designet blir ofte ryddigere og mer gjennomtenkt.
Høyere testdekning	Flere deler av koden får tester.
Rask tilbakemelding	Feil oppdages tidlig i utviklingen.
Økt tillit	Det blir lettere å endre kode når testene beskytter funksjonaliteten.
Testene fungerer som dokumentasjon	Testene viser hva systemet skal gjøre.
Lærekurve	TDD krever en ny måte å tenke og arbeide på.
Tidsbruk til å skrive tester	Det krever ekstra innsats, særlig i starten.
Vedlikehold av tester	Testene må oppdateres når systemet endres.
Kobler forretningsmål og teknologi	Teknisk utvikling knyttes til bruker- og forretningsverdi.
Beskriver systematferd fra brukerens perspektiv	Fokus på hva systemet skal gjøre for brukeren.
Bruker naturlig språk	Krav uttrykkes i et språk flere kan forstå.
Given (Gitt)	Beskriver starttilstand eller kontekst.
When (Når)	Beskriver handlingen eller hendelsen.
Then (Så)	Beskriver forventet resultat.
Feature	Overordnet funksjonalitet eller egenskap.
Scenario	Konkret eksempel på oppførsel.
And	Ekstra steg som bygger videre på de andre.
Tydeligere akseptkriterier	Det blir lettere å forstå hva som må være oppfylt.
Felles forståelse mellom forretning og utvikling	Misforståelser reduseres mellom tekniske og ikke-tekniske parter.
Testbar spesifikasjon	Krav kan omsettes til tester.
Høyere fokus på brukerens perspektiv	Atferd beskrives og vurderes fra sluttbrukerens side.
Scrum	Tidsboksbasert smidig rammeverk der arbeid organiseres i sprinter.
Kryssfunksjonelle team	Teamet skal samlet ha kompetansen som trengs.
Sprinter	Korte, faste iterasjoner i Scrum.
Inkrementell fremgang	Produktet forbedres litt etter litt.
Sprint planning	Planlegging av hva som skal gjøres i sprinten.
Daily standup / daily scrum	Kort daglig møte for koordinering.
Sprint review	Gjennomgang av sprintresultatet med interessenter.
Retrospektiv	Refleksjon over hvordan teamet kan forbedre arbeidsprosessen.
Product backlog	Prioritert liste over alt som kan gjøres i produktet.
Sprint backlog	Utvalget av arbeid som tas inn i en sprint.
Product backlog items (PBI)	Enkeltenheter i product backlog.
Scrum board	Visuell tavle for oppgaver i sprinten.
Eliminate waste	Fjern arbeid som ikke gir verdi.
Build quality in	Kvalitet skal bygges inn i prosessen, ikke bare kontrolleres til slutt.
Create knowledge	Læring og tilbakemelding skal brukes aktivt.
Defer commitment	Vent med irreversible valg til man vet mer.
Deliver fast	Lever verdi raskt.
Respect people	Stol på og støtt menneskene i systemet.
Optimize the whole	Se helheten, ikke bare enkeltledd.
Kanban	Flytbasert arbeidsmåte med kontinuerlig levering og visuell styring.
Flytbasert	Fokus på jevn gjennomstrømning av arbeid.
Kontinuerlig levering	Arbeid leveres fortløpende.
Ingen faste iterasjoner	I motsetning til Scrum styres ikke arbeidet av sprinter.
Visuell styring	Tavler brukes til å synliggjøre status og flyt.
Kanban-board	Tavle som visualiserer arbeidsflyten.
Begrensning av arbeid i prosess (WIP)	Setter grenser for hvor mange oppgaver som kan være i arbeid samtidig.
Fokus på flaskehalser	Prosessen forbedres der arbeidet stopper opp.
Synliggjøre flaskehalser	Gjør problemer i flyten tydelige.
Forbedre flyt	Reduserer opphopning av arbeid.
Hjelpe teammedlemmer å bidra der det stopper opp	Fremmer samarbeid på tvers av oppgaver og kolonner.
Domain-Driven Design (DDD)	Utviklingstilnærming med høyt fokus på domenet og domenets begreper.
Høyt fokus på domenet	Utviklingen tar utgangspunkt i problemområdet.
Koden skal gjenspeile virkeligheten	Modell og kode bør bruke samme begreper som domenet.
Egnet for skalering og endring	God domeneforståelse gjør videreutvikling lettere.
Fokus på det viktigste i domenet	Prioriterer kjernebegreper og kjerneprosesser.
Utvikling (Dev)	Bygging og forbedring av programvare.
Drift (Ops)	Utrulling, overvåking og vedlikehold i produksjon.
Kontinuerlig integrasjon	Kode integreres ofte i en felles gren.
Kontinuerlig levering / deploy	Kode kan leveres eller settes i drift raskt og trygt.
Tettere samarbeid mellom utvikling og drift	Færre siloer mellom team og ansvar.
Hyppig integrasjon til felles gren	Små endringer flettes ofte inn.
Automatisk bygging	Systemet bygges automatisk ved endringer.
Automatisk testing	Tester kjøres automatisk som del av byggprosessen.
Automatisk levering / deploy av kodeendringer	Endringer kan settes i drift med mindre manuelt arbeid.
GitLab / GitHub	Versjonskontroll og samarbeid om kode.
Jira / Confluence	Verktøy for planlegging og dokumentasjon.
Maven	Byggverktøy for Java.
Gradle	Fleksibelt byggverktøy.
Jenkins	Automatiserings- og CI-server.
JUnit	Testverktøy for Java.
Selenium	Verktøy for automatisert system- og UI-testing.
Helm	Pakkebehandling for Kubernetes.
Kibana	Visualisering av logger og søk.
Grafana	Visualisering av målinger og monitorering.
REST	Arkitekturstil der ressurser identifiseres via URI-er og manipuleres med HTTP-metoder.
Klient-tjener	Klient og server har ulike roller og ansvar.
Ressurser identifiseres via URI-er	Data og funksjonalitet modelleres som ressurser.
Ressurser manipuleres via HTTP-metoder	Standardiserte operasjoner brukes for å hente og endre data.
GET	Hente data.
POST	Opprette ny ressurs.
PUT	Oppdatere eller erstatte en ressurs.
DELETE	Slette en ressurs.
Sikre riktig respons ved input/interaksjon	Systemet må reagere riktig på brukerhandlinger.
Finne bugs	Feil må oppdages før brukerne gjør det.
Verifisere ytelse under edge cases	Systemet må tåle krevende eller uvanlige situasjoner.
Vurdere brukervennlighet	Løsningen må være god å bruke.
Kontrollere at krav er oppfylt	Systemet må gjøre det som er avtalt.
Kontrollere at systemet kan installeres i riktig miljø	Løsningen må fungere der den skal kjøres.
Kontrollere at systemet tåler endringer	Videreutvikling må ikke ødelegge eksisterende funksjonalitet.
Testing shows the presence of defects	Testing kan vise at feil finnes, men ikke bevise at ingen feil finnes.
Exhaustive testing is impossible	Det er umulig å teste absolutt alt.
Early testing	Testing bør starte tidlig.
Defects clustering	Mange feil samler seg ofte i noen få deler av systemet.
Pesticide paradox	De samme testene finner færre nye feil over tid.
Testing is context dependent	Teststrategien må tilpasses situasjonen.
Absence of error fallacy	Et feilfritt system er ikke nyttig hvis det løser feil problem.
Tradisjonell testing	Utvikling og testing skjer separat, ofte med eget QA-team.
Utvikling og testing skjer separat	Et team lager systemet, et annet tester det.
QA-team kvalitetssikrer etter utvikling	Test kommer ofte sent i prosessen.
Mye tid går til kommunikasjon og overlevering	Feil blir dyrere og tregere å håndtere.
Smidig testing	Utviklere tester egen kode kontinuerlig gjennom små inkrementer og automatisering.
Utviklere tester egen kode kontinuerlig	Test skjer parallelt med utviklingen.
Små inkrementer	Mindre endringer testes og leveres ofte.
Automatiserte tester brukes mye	Rask feedback er viktig i smidig utvikling.
Raskere feedback	Feil oppdages tidlig.
Tettere kobling mellom utvikling og kvalitet	Kvalitet bygges inn underveis.
QA kan fokusere på viktige scenarioer	Manuell test kan brukes der den gir størst verdi.
Ved opprettelse av pull request	Nye endringer testes før sammenslåing.
I CI-pipelines	Testing inngår i automatisert byggflyt.
Ved nye kodeendringer	Hyppig kjøring gir rask tilbakemelding.
Enhetstester og integrasjonstester kjøres automatisk	Vanlige testnivåer for automatisering.
Resultater rapporteres raskt	Utviklere får rask oversikt over feil.
Høy hastighet	Mange tester kan kjøres raskt.
Kontinuerlig kontroll	Kvalitet følges opp automatisk.
Forutsigbar kvalitet	Samme test kjøres likt hver gang.
Kostnadsbesparende over tid	Reduserer manuelt, repeterende arbeid.
Høy oppstarts- og vedlikeholdskostnad	Testene må bygges og holdes oppdatert.
Krever riktig fokus og god testdesign	Dårlige automatiserte tester gir liten verdi.
Testmiljø speiler produksjonsmiljø	Test skjer i omgivelser som ligner virkeligheten.
Hele applikasjonen kan testes før release	Gir helhetlig kontroll før utrulling.
Mer realistisk testing	Større sjanse for å finne reelle feil.
QA kan teste hele applikasjonen	Test kan gjennomføres også på systemnivå.
Infrastructure as Code gjør oppsett enklere	Miljøer kan opprettes og vedlikeholdes systematisk.
Mindre diff mellom gammel og ny versjon	Endringer blir lettere å forstå.
Enklere isolering av feil	Det blir lettere å finne hva som gikk galt.
Enklere sporing av endringer	Bedre oversikt over historikk og årsak.
Lavere sannsynlighet for feil	Små endringer er lettere å kontrollere.
Enklere rollback	Det blir enklere å rulle tilbake en liten endring.
Finn riktig nivå på testdekning basert på risiko	Ikke alt må testes like mye.
Prioriter tester som gir størst verdi	Test der konsekvensen av feil er størst.
Prioriter tester som reduserer mest usikkerhet	Test der usikkerheten er størst.
Risiko	Sannsynlighet for at noe går galt.
Konsekvens	Hvor alvorlig det blir hvis det går galt.
Risikofaktorer	Forhold som påvirker sannsynlighet eller konsekvens.
Hele teamet deltar	Flere perspektiver tas med i vurderingen.
Bedre treffsikkerhet	Samlet vurdering blir ofte bedre enn individuell vurdering.
Felles forståelse av risiko	Teamet blir enige om hva som er kritisk.
Samme data hver gang	Testresultater kan sammenlignes pålitelig.
Deterministisk prosess	Samme input gir samme output.
Forutsigbart testmiljø	Eksterne tilfeldigheter påvirker minst mulig.
Enklere å isolere feil	Avvik blir lettere å forklare.
Mer presise testresultater	Resultatene blir mer pålitelige.
Bedre analyse av testutfall	Utviklere kan tolke funn mer sikkert.
Mocking	Teknikk der ekte og komplekse avhengigheter erstattes med kontrollerte testdobler.
Erstatte ekte og komplekse avhengigheter	Systemer byttes ut når de er upraktiske eller ustabile i test.
Isolere klasser / moduler i test	Teste én del uten ekte avhengigheter.
Database	Kan mocket for å unngå ekte database i test.
Eksternt API	Kan mocket for å unngå nettverkskall og ustabile svar.
Betalingstjeneste	Kan mocket for å simulere betaling uten ekte transaksjoner.
Deterministiske svar	Testene får samme respons hver gang.
Samme grensesnitt som ekte avhengighet	Kan byttes inn uten å endre resten av koden.
Kombineres godt med dependency injection	Avhengigheter kan settes inn ved kjøring.
Muliggjør isolert testing	Én del kan testes alene.
Gjør automatiserte tester mulige i flere situasjoner	Flere deler av systemet blir testbare.
Gir kontroll over testmiljøet	Reduserer usikkerhet i testkjøringen.
Oppsett	Forberede testdata og testmiljø.
Gjennomføring	Utføre handlingene testen beskriver.
Verifisering	Kontrollere at resultatet ble som forventet.
Opprydding	Fjerne eller nullstille ressurser før neste test.
Enhetstesting	Testing av små, isolerte funksjoner eller klasser.
Tester individuelle klasser / funksjoner	Små deler testes isolert.
Fokus på små enheter	Enkel funksjonalitet står i sentrum.
Ofte utviklers ansvar	Utvikleren skriver og vedlikeholder ofte testene.
Automatisert	Kan enkelt kjøres ofte.
Repeterbar	Gir like resultater ved samme input.
Kjøres i byggeprosessen	Er en naturlig del av utviklingsflyten.
Finne feil tidlig	Feil fanges før de sprer seg videre.
Stoppe feil før integrasjon med andre deler	Hindrer at små feil blir større problemer.
Integrasjonstesting	Testing av samspill mellom komponenter.
Tester samspill mellom komponenter	Ser på hvordan delene virker sammen.
Bygger på at delene allerede er testet individuelt	Enhetstesting bør være gjennomført først.
Oppdage feil i grensesnitt og samhandling	Avdekker problemer i koblingene mellom delene.
Kan automatiseres	Mange integrasjonstester egner seg godt for automatisering.
Bør automatiseres der det er hensiktsmessig	Særlig ved hyppige og kritiske samspill.
Systemtesting	Testing av hele systemet som en helhet.
Tester hele systemet	Systemet ses og vurderes som en helhet.
Sjekker at alle deler fungerer sammen	Helhetlig kvalitet kontrolleres.
Finner feil mellom deler av systemet	Noen problemer oppstår bare i helheten.
Gir trygghet før levering	Gir bedre grunnlag for release.
Sjekke at systemet oppfyller krav	Både funksjonelle og ofte ikke-funksjonelle krav vurderes.
Finne feil før bruk	Redusere risiko før sluttbruker møter løsningen.
Kan utføres med verktøy som Selenium	Deler av helheten kan automatiseres.
Kan være vanskelig å gjøre helt repeterbar	Mange avhengigheter påvirker resultatet.
Akseptansetesting	Systemtesting som verifiserer at krav og behov er oppfylt.
Type systemtesting	Foregår på høyt nivå i systemet.
Utføres for å verifisere at krav er oppfylt	Særlig mot kundens eller brukerens forventninger.
Bygger på user stories	Kobler krav og test tett sammen.
Kan utvikles sammen med kunden	Gir bedre samsvar med behovene.
Manuell testing	Mennesker går gjennom scenarier og vurderer resultatene.
Automatisert testing	Scenarioer kan kjøres automatisk.
Regresjonstesting	Testing som sikrer at endringer ikke ødelegger eksisterende funksjonalitet.
Tester at endringer ikke ødelegger eksisterende funksjonalitet	Gammel funksjon må fortsatt virke etter endringer.
Før og etter endringer	Brukes for å sammenligne oppførsel.
Kontinuerlig i CI ved innsjekk av kode	Skjer ofte automatisk i moderne utvikling.
Enhetstestnivå	Små deler testes på nytt.
Integrasjonsnivå	Samspill testes på nytt.
Akseptansenivå	Brukerorientert oppførsel testes på nytt.
Egner seg godt for automatisering	De samme testene kjøres mange ganger.
Smoke-testing	Rask test av kritisk funksjonalitet for å se om systemet i det hele tatt fungerer.
Tester kritisk funksjonalitet	Sjekker at systemets viktigste deler virker.
Rask sjekk av om systemet i det hele tatt fungerer	Avgjør om videre testing er verdt å starte.
Sanity-testing	Rask test av ny eller endret funksjonalitet for å se om endringen virker rimelig.
Tester ny eller endret funksjonalitet	Fokuserer på den siste endringen.
Rask sjekk av om en spesifikk endring virker fornuftig	Er smalere enn smoke-testing.
Avdekker tidlig om videre testing er hensiktsmessig	Sparer tid hvis systemet er for ustabilt.
Destruktiv testing	Kreativ testing der målet er å få systemet til å feile.
Kreativ testing for å få systemet til å feile	Systemets grenser og svakheter presses bevisst.
Kan ikke automatiseres	Bygger på menneskelig kreativitet og erfaring.
Krever menneskelig erfaring og kreativitet	Testeren må tenke utradisjonelt.
Utforskende testing	Testing der læring, testdesign og testgjennomføring skjer samtidig.
Tester med aktiv læring og utforsking underveis	Testeren justerer testene mens innsikten øker.
Bygger på innsikt i systemet og nye hypoteser	Man følger spor og ideer som oppstår underveis.
Destruktiv testing: fokus på å bryte systemet	Målet er å finne svakheter ved å presse løsningen.
Utforskende testing: bredere utforsking og læring	Målet er både forståelse og feilfunn.
Usabilitytesting	Testing av brukervennlighet og brukeropplevelse.
Brukervennlighet	Hvor lett systemet er å bruke.
GUI	Hvordan det grafiske brukergrensesnittet fungerer.
Om brukeren / kunden er fornøyd	Opplevd kvalitet og tilfredshet.
Ytelsestesting	Testing av kapasitet, responstid og stabilitet under belastning.
Hvor mye last systemet tåler	Kapasitet under normal eller høy belastning.
Hvor mye plutselig last systemet tåler	Systemets reaksjon på raske lasttopper.
Ytelse over tid	Stabilitet og ressursbruk ved langvarig drift.
Lekkasjer / ressursproblemer	For eksempel minnelekkasjer eller ressursoppbygging over tid.
Antall samtidige brukere	Hvor mange som bruker systemet samtidig.
Transaksjoner per tidsenhet	Hvor mye arbeid systemet utfører per tidsrom.
Throughput	Mengde data eller arbeid som behandles over tid.
Responstid	Hvor lang tid systemet bruker på å svare.
Flaskehals	Systemets svakeste eller tregeste punkt som begrenser total ytelse.
CPU	Prosessoren er overbelastet.
Minne	For lite eller ineffektiv bruk av RAM.
Tråder	Dårlig håndtering av parallellitet eller venting.
Databasetilkobling	Database eller forbindelser blir begrensningen.
Lasttest	Måler oppførsel ved forventet eller gradvis økende last.
Stresstest	Finner yttergrensen der systemet bryter sammen.
Spike-test	Tester reaksjon på plutselige lasttopper.
Utholdenhetstest	Tester systemet under jevn belastning over tid.
Black-box testing	Testing uten innsikt i intern kode, basert på input og output.
Ingen innsikt i intern kode	Testeren ser bare input og output.
Bygger på krav, spesifikasjoner og forventet oppførsel	Testingen tar utgangspunkt i ytre oppførsel, ikke intern implementasjon.
White-box testing	Testing med innsikt i intern kode og struktur.
Full innsikt i intern kode og struktur	Testeren kjenner logikk og oppbygning.
Tester intern logikk og oppbygning	Dekker veier, betingelser og intern struktur.
Raske	Kan kjøres ofte og på kort tid.
Nøyaktige	Samme fremgangsmåte brukes hver gang.
Repeterbare	Resultatene blir konsistente ved lik input.
Gode for kjente forventninger	Passer godt der riktig resultat er tydelig definert.
Enhetstester	Tester små, isolerte kodeenheter.
Regresjonstester	Sjekker at gammel funksjonalitet fortsatt virker.
Mange integrasjonstester	Tester samspill mellom komponenter.
Mange ytelsestester	Automatiske last- og stresstester.
Krever vedlikehold	Testene må oppdateres når systemet endres.
Fanger ikke alt	Automatiserte tester er særlig svake på subjektive forhold.
Dårligere på kreative og uventede problemer	Mennesker er bedre til utforskning og improvisasjon.
Kreative	Testeren kan tenke fritt og prøve uventede ting.
Fanger ofte naturlige brukerfeil og uventede problemer	Realistisk menneskelig bruk avdekkes bedre.
Gode for utforsking og opplevelse	Spesielt viktig for usability og ad hoc-testing.
Lovlighet, rimelighet og gjennomsiktighet	Behandling må være lovlig, rettferdig og forståelig for den registrerte.
Formålsbegrensning	Data skal bare brukes til tydelig definerte formål.
Dataminimering	Bare nødvendige opplysninger skal samles inn.
Riktighet	Opplysninger skal være korrekte og oppdaterte.
Lagringsbegrensning	Data skal ikke lagres lenger enn nødvendig.
Integritet og konfidensialitet	Data skal beskyttes mot uautorisert tilgang og tap.
Ansvarliggjøring	Virksomheten må kunne dokumentere at reglene følges.
Rett til informasjon	Den registrerte skal få vite hvilke data som behandles og hvorfor.
Rett til innsyn	Den registrerte skal få tilgang til egne opplysninger.
Rett til retting	Den registrerte skal få uriktige opplysninger korrigert.
Rett til sletting	Den registrerte kan kreve at opplysninger fjernes i visse tilfeller.
Rett til begrensning	Den registrerte kan kreve at behandling stoppes midlertidig.
Rett til å protestere	Den registrerte kan motsette seg visse typer behandling.
Rett til dataportabilitet	Den registrerte kan få egne data ut i et maskinlesbart format.
Juridisk forpliktelse	Behandling kan være nødvendig for å oppfylle lovkrav.
Offentlig sikkerhet	Noen rettigheter kan begrenses av samfunnshensyn.
Forskning	Særregler kan gjelde ved forskning og statistikk.
Sosialt ansvar	Teknologi påvirker samfunn, arbeidsliv og mennesker.
Sikkerhet og pålitelighet	Systemer må være trygge og til å stole på.
Brukeres velferd	Løsninger må ikke skade brukerne eller deres livssituasjon.
AI og militær bruk / alvorlige konsekvenser av teknologi	Utviklere må reflektere over alvorlige anvendelser og ansvar.
Vise respekt for kolleger	Rettferdig og profesjonell behandling av andre.
Vedkjenne seg faglig ansvar	Stå inne for eget arbeid og egne vurderinger.
Følge anerkjente kvalitetsnormer	Bruke faglig gode standarder og praksiser.
Bidra til åpenhet om teknologiske konsekvenser	Ikke skjule risiko eller negative effekter.
Samfunn	Arbeid i offentlighetens interesse.
Kunde og arbeidsgiver	Opptre ansvarlig overfor dem man arbeider for.
Produkt	Sikre høy kvalitet i programvare og løsninger.
Vurdering	Utvise integritet og faglig skjønn.
Ledelse	Fremme etisk ledelse i utviklingsarbeid.
Profesjon	Styrke profesjonens integritet og omdømme.
Kolleger	Støtte og behandle kolleger rettferdig.
Egen utvikling / livslang læring	Holde seg faglig oppdatert og utvikle seg videre.
Ærlighet og integritet	Være sannferdig om begrensninger og risiko.
Respekt for personvern	Bygge løsninger som beskytter individet.
Kvalitetsbevissthet	Arbeide systematisk for god kvalitet.
Ansvar for konsekvenser	Vurdere hvordan teknologien påvirker mennesker og samfunn.
Kontinuerlig vurdering	Etiske vurderinger må gjøres gjennom hele prosessen.
Mer robuste systemer	Etisk bevissthet gir ofte bedre designvalg.
Færre sikkerhets- og personvernbrudd	Risiko håndteres tidligere i utviklingen.
Høyere brukertilfredshet	Brukere stoler mer på løsningen.
Beskytter omdømme	Både utviklere og virksomheter unngår tillitstap.
Reduserer risiko for bias og tillitsbrudd	Færre urettferdige eller skadelige løsninger.
Formål	Hvorfor prosjektet finnes.
Omfang	Hva prosjektet skal og ikke skal dekke.
Hensikt	Hva man ønsker å oppnå.
Målgruppe	Hvem løsningen er for.
Funksjonelle krav	Hva systemet skal gjøre.
Ikke-funksjonelle krav	Kvalitetskrav som ytelse, sikkerhet og brukervennlighet.
Interessenter	Personer eller grupper som påvirkes av prosjektet.
Brukerbehov	Behovene løsningen skal dekke.
Identifisere risiko	Finne mulige problemer.
Prioritere risiko	Vurdere hva som er viktigst å håndtere.
Definere tiltak	Bestemme hva man skal gjøre med risikoene.
Forbedre beslutningsprosesser	Gi bedre grunnlag for valg.
Øke prosjektets robusthet	Gjøre prosjektet bedre rustet mot problemer.
```

Hvis du vil, kan jeg lage en **v3** som er enda bedre for Quizlet ved å:
- splitte blandede linjer som “fordel/ulempe”-utsagn fra rene fagbegreper,
- normalisere norsk/engelsk begrepsbruk,
- og gruppere kortene i **tema-bolker** uten å endre TSV-formatet.

## @real-eo

dette her må endres. Det bør være: "Dimensjonene i IxD: Fysiske objekter og rom" - "den fysiske konteksten eller enheten brukeren samhandler gjennom.".

Gjør dette for alle steder der det er fornuftig

## Copilot

Ja — det du peker på er riktig. For Quizlet/flashcards fungerer mange av kortene bedre hvis **begrepet inkluderer konteksten/kategorien**, ikke bare selve underpunktet. Ellers blir kort som **“Fysiske objekter og rom”** for løsrevet og tvetydig.

Det betyr at begreper bør skrives som for eksempel:

- **Dimensjonene i IxD: Fysiske objekter og rom** → den fysiske konteksten eller enheten brukeren samhandler gjennom.
- **Don Normans prinsipper: Feedback** → systemet skal gi tydelig tilbakemelding på hva som skjer.
- **De fire prinsippene i WCAG: Robust** → løsningen må fungere med ulike nettlesere og hjelpemidler.

Under har jeg derfor laget en **TSV v3** der jeg har gjort dette **systematisk alle steder det er fornuftig**:
- lagt til **kontekst-prefiks** for underpunkter i lister
- beholdt fagbegrepene
- gjort kortene mer entydige i Quizlet
- unngått prefiks der begrepet allerede er tydelig nok alene

```tsv name=quizlet-begreper-v3-kontekstualisert.tsv
Prosess for interaksjonsdesign: Definer krav	Avklare brukerbehov, mål og rammer for løsningen.
Prosess for interaksjonsdesign: Design alternativer	Utvikle flere mulige forslag til hvordan løsningen kan fungere.
Prosess for interaksjonsdesign: Lag prototype	Gjøre designet konkret i en enkel eller avansert modell.
Prosess for interaksjonsdesign: Evaluer	Vurdere om løsningen fungerer for brukerne og oppfyller kravene.
Dimensjonene i IxD: Ord	Tekst og språk som brukes i grensesnittet.
Dimensjonene i IxD: Visuelle representasjoner	Ikoner, farger, bilder, typografi og andre grafiske elementer i grensesnittet.
Dimensjonene i IxD: Fysiske objekter og rom	Den fysiske konteksten eller enheten brukeren samhandler gjennom.
Dimensjonene i IxD: Tid	Hvordan interaksjonen utvikler seg over tid, for eksempel animasjoner, lyd og responstid.
Dimensjonene i IxD: Atferd	Hvordan systemet oppfører seg, og hvilke reaksjoner og opplevelser dette skaper hos brukeren.
Don Normans prinsipper: Synlighet	Funksjoner og muligheter skal være lette å oppdage.
Don Normans prinsipper: Feedback	Systemet skal gi tydelig tilbakemelding på hva som skjer.
Don Normans prinsipper: Begrensninger	Designet bør begrense feil handlinger og lede brukeren i riktig retning.
Don Normans prinsipper: Avbilding (mapping)	Sammenhengen mellom kontroll og effekt bør være intuitiv.
Don Normans prinsipper: Konsistens	Like ting bør fungere likt i hele systemet.
Don Normans prinsipper: Tilbydelser / affordances	Designet skal signalisere hvilke handlinger som er mulige.
Dimensjoner ved prototyping: Utseende	Hvordan prototypen ser ut visuelt.
Dimensjoner ved prototyping: Innhold	Hvilken informasjon og hvilke elementer som er med i prototypen.
Dimensjoner ved prototyping: Funksjonalitet	Hvilke funksjoner som er simulert eller implementert i prototypen.
Dimensjoner ved prototyping: Interaktivitet	Hvor mye brukeren faktisk kan gjøre i prototypen.
Dimensjoner ved prototyping: Romlig struktur	Hvordan skjermbilder, elementer eller deler av løsningen er organisert.
Klasser av prototyping: Horisontal prototype	Bred prototype med mange funksjonsområder, men liten dybde.
Klasser av prototyping: Vertikal prototype	Smal prototype som går i detalj og dybde på én funksjon.
Aspekter ved utvikling av prototyper: Evolusjonær prototype	Prototype som videreutvikles til en del av sluttproduktet.
Aspekter ved utvikling av prototyper: Bruk-og-kast-prototype	Prototype som brukes til læring og deretter forkastes.
Aspekter ved utvikling av prototyper: Lavoppløselig prototype	Enkel prototype med lite detalj og lite interaksjon, for eksempel en papirskisse.
Aspekter ved utvikling av prototyper: Høyoppløselig prototype	Mer realistisk prototype med mye detalj og ofte mer interaksjon.
Testing	Verifisering av om systemet fungerer teknisk riktig.
Evaluering	Vurdering av om løsningen er nyttig, brukbar og riktig for behovet.
Evalueringsformer: Formativ evaluering	Evaluering underveis for å forbedre løsningen mens den utvikles.
Evalueringsformer: Summativ evaluering	Evaluering av en ferdig løsning for å vurdere sluttresultatet.
Evaluering som involverer brukere: Brukertest	Brukere utfører oppgaver mens man observerer problemer og atferd.
Evaluering som involverer brukere: A/B-test	To eller flere varianter sammenlignes for å se hvilken som fungerer best.
Evaluering som involverer brukere: Feltstudie	Evaluering i brukerens naturlige omgivelser.
Evaluering som involverer brukere: Opportunistisk evaluering	Rask tilbakemelding fra brukere på en idé eller problemstilling.
Evaluering som ikke involverer brukere: Heuristisk gjennomgang	Eksperter vurderer løsningen ut fra etablerte brukbarhetsprinsipper.
Evaluering som ikke involverer brukere: Prediktive modeller	Analytiske eller beregnende modeller som brukes til å forutsi brukeropplevelse eller ytelse.
Evaluering som kan involvere både eksperter og brukere: Pluralistisk gjennomgang	Brukere, utviklere og eksperter går sammen gjennom scenarioer og vurderer løsningen.
Evalueringsmetoder: Observasjon	Se hvordan brukeren faktisk oppfører seg.
Evalueringsmetoder: Spørre brukere	Samle innsikt gjennom intervju, samtale eller spørreskjema.
Evalueringsmetoder: Direkte testing	Brukeren prøver konkrete oppgaver i løsningen.
Evalueringsmetoder: Spørre eksperter	Hente vurderinger fra fagpersoner.
Evalueringsmetoder: Modellering	Bruke modeller til å analysere eller forutsi bruk.
Evalueringsteknikker: Kodevalidering	Sjekk av om kode og struktur følger krav eller standarder.
Evalueringsteknikker: Testing i ulike nettlesere og på ulike plattformer	Sjekk av kompatibilitet på tvers av miljøer.
Evalueringsteknikker: Testing av fleksibiliteten til et design	Vurdering av hvor godt designet fungerer under ulike forhold.
Evalueringsteknikker: Testing av grad av universell utforming / brukskvalitet	Sjekk av tilgjengelighet og brukervennlighet.
Evalueringsteknikker: Testing av feilmeldinger	Vurdering av om feilmeldinger er tydelige og hjelpsomme.
Kjennetegn ved god brukertesting: Konkret hensikt	Testen skal ha et tydelig mål.
Kjennetegn ved god brukertesting: Avgrenset formål	Man tester noe spesifikt, ikke alt samtidig.
Kjennetegn ved god brukertesting: Realistiske oppgaver	Oppgavene bør ligne ekte brukssituasjoner.
Kjennetegn ved god brukertesting: Observasjon av brukeren	Man ser hva brukeren faktisk gjør, ikke bare hva brukeren sier.
Prinsipper for universell utforming: Enkel og intuitiv i bruk	Løsningen skal være lett å forstå.
Prinsipper for universell utforming: Forståelig informasjon	Nødvendig informasjon skal kommuniseres tydelig.
Prinsipper for universell utforming: Toleranse for feil	Designet skal redusere risiko og konsekvenser av feil.
Prinsipper for universell utforming: Like muligheter for alle	Løsningen skal kunne brukes av personer med ulike ferdigheter.
Prinsipper for universell utforming: Fleksibel i bruk	Løsningen skal støtte ulike preferanser og måter å bruke systemet på.
Prinsipper for universell utforming: Lav fysisk anstrengelse	Løsningen skal kunne brukes med minst mulig belastning.
Prinsipper for universell utforming: Størrelse og plass for tilgang og bruk	Fysisk og visuell utforming skal støtte tilgang og bruk.
Størrelse og plass for tilgang og bruk skal muliggjøre: Tilgang	Brukeren skal kunne nå og oppfatte løsningens elementer.
Størrelse og plass for tilgang og bruk skal muliggjøre: Rekkevidde	Brukeren skal kunne komme til funksjonene uavhengig av kroppslige forutsetninger.
Størrelse og plass for tilgang og bruk skal muliggjøre: Betjening og bruk	Løsningens elementer skal kunne brukes praktisk og sikkert.
Argumenter for universell utforming: Mer inkluderende	Flere mennesker kan bruke løsningen.
Argumenter for universell utforming: Enklere å bruke	God struktur og navigasjon hjelper alle brukere.
Argumenter for universell utforming: Mer mobiltilpasset	Tilgjengelige løsninger fungerer ofte bedre på små skjermer.
Argumenter for universell utforming: Mer synlig for Google / bedre SEO	God struktur og semantikk hjelper søkemotorer.
Argumenter for universell utforming: Mer lønnsomt	Flere brukere når fram, og supportbehov kan reduseres.
De fire prinsippene i WCAG: Mulig å oppfatte (Perceivable)	Innhold må kunne oppfattes av brukeren.
De fire prinsippene i WCAG: Mulig å betjene (Operable)	Grensesnittet må kunne brukes og navigeres.
De fire prinsippene i WCAG: Forståelig (Understandable)	Innhold og funksjonalitet må være forståelige.
De fire prinsippene i WCAG: Robust	Løsningen må fungere med ulike nettlesere og hjelpemidler.
Eksempler på krav i WCAG: Innhold tilgjengelig via tastatur	Brukeren skal ikke være avhengig av mus.
Eksempler på krav i WCAG: Alternativ tekst på bilder	Skjermlesere må kunne formidle bildeinnhold.
Eksempler på krav i WCAG: Teksting eller alternativ lyd på video	Innholdet må være tilgjengelig ved ulike behov.
Eksempler på krav i WCAG: Skjema og formater lette å forstå	Brukerens oppgaver må være tydelige.
Eksempler på krav i WCAG: Innhold lett å forstå	Språk og struktur må støtte forståelse.
UML-diagramtype: Use case-diagram	Viser aktører og hvilke mål eller funksjoner de bruker systemet til.
UML-diagramtype: Domenemodell	Viser sentrale begreper i domenet og relasjonene mellom dem.
UML-diagramtype: Sekvensdiagram	Viser meldinger og samspill mellom deltakere over tid.
UML-diagramtype: Aktivitetsdiagram	Viser flyt av aktiviteter, beslutninger og parallelle handlinger.
UML-diagramtype: Klassediagram	Viser klasser, attributter, metoder og relasjoner.
UML-diagramtype: Pakkediagram	Viser hvordan elementer grupperes i pakker eller moduler.
UML-diagramtype: Tilstandsmaskindiagram	Viser tilstander og overganger for et objekt eller system.
Elementer i sekvensdiagram: Deltakere	Aktører, objekter eller komponenter som deltar i samspillet.
Elementer i sekvensdiagram: Meldinger / funksjonskall	Kommunikasjon mellom deltakerne.
Elementer i sekvensdiagram: Levetidslinje	Stiplet linje som viser deltakerens eksistens over tid.
Elementer i sekvensdiagram: Aktiveringsboks	Viser når en deltaker utfører arbeid.
Elementer i sekvensdiagram: Rammer	Markerer kontrollstrukturer som valg eller repetisjon.
Elementer i aktivitetsdiagram: Aksjoner	Konkrete handlinger eller steg i en prosess.
Elementer i aktivitetsdiagram: Initial node	Startpunktet for aktiviteten.
Elementer i aktivitetsdiagram: Final node	Sluttpunktet for aktiviteten.
Elementer i aktivitetsdiagram: Decision node	Punkt der prosessen forgrenes ut fra betingelser.
Elementer i aktivitetsdiagram: Fork node	Deler prosessen i parallelle løp.
Elementer i aktivitetsdiagram: Join node	Samler parallelle løp igjen.
Elementer i aktivitetsdiagram: Merge node	Slår sammen alternative flyter.
Elementer i aktivitetsdiagram: Overganger / piler	Viser rekkefølge og flyt mellom aktiviteter.
Elementer i klassediagram: Klasse	En type objekt med data og atferd.
Elementer i klassediagram: Attributter	Data som hører til klassen.
Elementer i klassediagram: Metoder	Funksjoner eller operasjoner klassen kan utføre.
Relasjoner i klassediagram: Avhengighet (dependency)	En svak kobling der én klasse bruker en annen.
Relasjoner i klassediagram: Assosiasjon	En strukturell kobling mellom to klasser.
Relasjoner i klassediagram: Aggregering	Hel-del-relasjon der delen kan eksistere uten helheten.
Relasjoner i klassediagram: Komposisjon	Sterk hel-del-relasjon der delen hører tett til helheten.
Relasjoner i klassediagram: Arv / generalisering	En subklasse arver fra en superklasse.
Relasjoner i klassediagram: Realisering	En klasse implementerer et grensesnitt.
Hovedelementer i tilstandsmaskindiagram: Starttilstand	Tilstanden systemet eller objektet starter i.
Hovedelementer i tilstandsmaskindiagram: Sluttilstand	Tilstanden der livsløpet avsluttes.
Hovedelementer i tilstandsmaskindiagram: Tilstander	Ulike situasjoner objektet kan befinne seg i.
Hovedelementer i tilstandsmaskindiagram: Overganger	Bevegelser fra én tilstand til en annen.
Hovedelementer i tilstandsmaskindiagram: Triggere / hendelser	Det som utløser en overgang.
Brukerhistorie-format: Som [rolle]	Beskriver hvem brukeren er.
Brukerhistorie-format: vil jeg [mål/ønske]	Beskriver hva brukeren ønsker å gjøre.
Brukerhistorie-format: slik at [nytte/verdi]	Beskriver hvorfor dette er viktig.
Hvorfor programvarearkitektur er viktig: Forstå systemet tidlig	Gjør det lettere å se helheten før implementasjon.
Hvorfor programvarearkitektur er viktig: Redusere kostnader	Tidlige gode valg sparer tid og penger senere.
Hvorfor programvarearkitektur er viktig: Unngå duplisering av ressurser	Tydelig struktur reduserer overlappende løsninger.
Hvorfor programvarearkitektur er viktig: Øke kvalitet	Bedre struktur gir bedre vedlikeholdbarhet og testbarhet.
Hvorfor programvarearkitektur er viktig: Hjelpe risikostyring	Man oppdager tekniske utfordringer tidligere.
Hvorfor programvarearkitektur er viktig: Støtte kommunikasjon mellom interessenter	Gir et felles bilde av systemet.
Hvorfor programvarearkitektur er viktig: Gi retningslinjer for utviklere	Hjelper teamet å utvikle konsistent.
Kompleksitetshåndtering: Splitt og hersk	Dele opp problemet i mindre deler.
Kompleksitetshåndtering: Lav kobling	Delene bør være minst mulig avhengige av hverandre.
Kompleksitetshåndtering: Mer testbar kode	Mindre og tydeligere deler er enklere å teste.
Kompleksitetshåndtering: Mer robust kode	Isolerte deler tåler endringer bedre.
Kompleksitetshåndtering: Enklere delegering av ansvar	Team kan jobbe med ulike deler parallelt.
De tre lagene i trelagsarkitektur: Presentasjonslag	Viser informasjon og håndterer brukerinteraksjon.
De tre lagene i trelagsarkitektur: Forretningslogikklag	Utfører regler, prosessering og kjernefunksjonalitet.
De tre lagene i trelagsarkitektur: Data access-lag	Håndterer lagring, henting og oppdatering av data.
Hovedidé i lagdeling: Hvert lag har spesifikt ansvar	Gjør systemet mer oversiktlig.
Hovedidé i lagdeling: Hvert lag yter tjenester til laget over / bruker laget under	Gir strukturert avhengighet.
Hovedidé i lagdeling: Gir lav kobling	Endringer i ett lag påvirker ikke nødvendigvis andre lag direkte.
Hoveddeler i master-slave pattern: Master	Styrer, fordeler arbeid og samler resultater.
Hoveddeler i master-slave pattern: Slave	Utfører arbeid delegert av master.
Fordeler med master-slave pattern: Tydelig oversikt i master	Gir sentral kontroll over prosessen.
Fordeler med master-slave pattern: Slaver kan enhetstestes separat	Hver del kan testes isolert.
Fordeler med master-slave pattern: Master kan integrasjonstestes mot slavene	Samspillet kan testes samlet.
Fire hovedkomponenter i event-bus pattern: Event listener	Lytter etter hendelser.
Fire hovedkomponenter i event-bus pattern: Event source	Produserer eller sender hendelser.
Fire hovedkomponenter i event-bus pattern: Channel	Kanal eller emne der hendelser publiseres.
Fire hovedkomponenter i event-bus pattern: Event bus	Infrastrukturen som frakter hendelser mellom kilder og lyttere.
Tre deler i MVC: Model	Data og forretningslogikk.
Tre deler i MVC: View	Det brukeren ser i grensesnittet.
Tre deler i MVC: Controller	Håndterer input og styrer flyten mellom model og view.
Fordeler med MVC: Høyere kohesjon	Hver del får tydeligere ansvar.
Fordeler med MVC: Gjenbrukbarhet	Deler kan lettere brukes på nytt.
Fordeler med MVC: Skille ansvar	Gjør systemet enklere å forstå og endre.
Mikrotjenester er basert på: Single Responsibility Principle	Hver tjeneste bør ha ett tydelig hovedansvar.
Kjennetegn ved mikrotjenester: Selvstendige tjenester	Hver tjeneste kan utvikles og driftes separat.
Kjennetegn ved mikrotjenester: Én hovedoppgave per tjeneste	Tydelig ansvarsdeling.
Kjennetegn ved mikrotjenester: Egen data	Tjenesten eier vanligvis sin egen datalagring.
Kjennetegn ved mikrotjenester: Eget kjøremiljø	Tjenesten kan kjøres og deployes uavhengig.
Fordeler med mikrotjenester: Skalerbart	Tjenester kan skaleres separat.
Fordeler med mikrotjenester: Modulært	Systemet deles i mindre moduler.
Fordeler med mikrotjenester: Fleksibel teknologibruk	Ulike tjenester kan bruke ulik teknologi.
Fordeler med mikrotjenester: Høy tilgjengelighet / feilisolering	Feil i én tjeneste stopper ikke nødvendigvis hele systemet.
Fordeler med mikrotjenester: Støtter kontinuerlig levering (CI/CD)	Tjenester kan oppdateres uavhengig.
Fordeler med mikrotjenester: Passer DevOps	Tett kobling mellom utvikling, drift og deploy.
Ulemper med mikrotjenester: Kompleks debugging	Feilsporing på tvers av tjenester er vanskeligere.
Ulemper med mikrotjenester: Kompleks logging på tvers av tjenester	Data om feil og flyt spres i flere systemer.
Ulemper med mikrotjenester: Krever automatisering	Bygg, test og deploy må ofte automatiseres sterkt.
Ulemper med mikrotjenester: Vanskelig å teste distribuerte systemer	Mange avhengigheter og miljøer kompliserer testarbeidet.
Ulemper med mikrotjenester: Datainkonsistens	Data er fordelt og kan komme ut av synk.
Ulemper med mikrotjenester: Økt ressursforbruk	Mange tjenester krever mer infrastruktur.
Monolittarkitektur	Arkitektur der alle deler av systemet er samlet i én applikasjon.
Fordeler med monolittarkitektur: God gjennomstrømning / lite overhead	Mindre kommunikasjon mellom separate tjenester gir mindre overhead.
Fordeler med monolittarkitektur: Enklere å teste og debugge i starten	Alt er samlet i én applikasjon.
Ulemper med monolittarkitektur: Vanskeligere å vedlikeholde ved vekst	Systemet blir tungt å endre når det blir stort.
Ulemper med monolittarkitektur: Lite skalerbar	Hele systemet må ofte skaleres samlet.
Ulemper med monolittarkitektur: Lite utvidbar sammenlignet med modulære løsninger	Struktur og vekst blir vanskeligere å håndtere.
Ulemper med monolittarkitektur: Tett koblet	Delene er ofte sterkt avhengige av hverandre.
Ulemper med monolittarkitektur: Feil i én del kan stoppe hele systemet	Svak isolasjon av feil gir større konsekvenser.
Hoveddeler i plugin-basert arkitektur: Kjerne-system	Grunnsystemet som gir basisfunksjonalitet.
Hoveddeler i plugin-basert arkitektur: Plugin-moduler / extensions	Tillegg som utvider funksjonaliteten.
Fordeler med plugin-basert arkitektur: Lav kobling	Plugins kan være relativt uavhengige av hverandre.
Fordeler med plugin-basert arkitektur: Høy isolasjon mellom funksjoner	Endringer i én plugin trenger ikke påvirke andre.
Fordeler med plugin-basert arkitektur: Fleksibelt	Funksjonalitet kan legges til eller fjernes.
Fordeler med plugin-basert arkitektur: Utvidbart	Systemet kan vokse gjennom nye plugins.
Ulemper med plugin-basert arkitektur: Endringer i kjernen kan ødelegge plugins	Bakoverkompatibilitet blir viktig.
Ulemper med plugin-basert arkitektur: Mange plugins kan redusere ytelsen	Ekstra moduler kan gi mer belastning.
Ulemper med plugin-basert arkitektur: Kompleks testing av hele systemet	Mange kombinasjoner og avhengigheter må testes.
Eksempel på plugin-basert arkitektur: Chrome Web Store	Plattform for nettleserutvidelser.
Eksempel på plugin-basert arkitektur: IntelliJ	IDE med mange utvidelser.
Eksempel på plugin-basert arkitektur: VS Code	Editor med plugin-system.
Eksempel på plugin-basert arkitektur: Eclipse	Utviklingsmiljø bygget rundt plugins.
Tradisjonell deployment	Applikasjoner kjøres direkte på fysiske servere.
Utfordringer ved tradisjonell deployment: Ressursallokering kan bli ineffektiv	Det er vanskelig å fordele kapasitet godt på fysiske servere.
Utfordringer ved tradisjonell deployment: Én applikasjon kan ta for mye kapasitet	Andre systemer kan påvirkes negativt.
Virtualisering (VMs)	Flere virtuelle maskiner kjøres på én fysisk server.
Virtualisering (VMs): Hver VM har eget operativsystem	Gir sterk isolasjon mellom miljøene.
Ulempe ved virtualisering: Ressurser reserveres selv om de ikke brukes	Effektiviteten kan bli lav i virtuelle miljøer.
Container-deployment	Containere deler operativsystem, men er isolerte.
Container-deployment: Containere deler OS, men er isolerte	Gir lettere isolasjon enn full virtualisering.
Container-deployment: Lettere enn virtuelle maskiner	Mindre overhead og raskere oppstart.
Nøkkelteknologier i container-deployment: Docker	Teknologi for å bygge og kjøre containere.
Nøkkelteknologier i container-deployment: Kubernetes	Plattform for orkestrering og styring av containere.
Fordeler med containere: Enkel distribusjon	Løsningen er lett å flytte og kjøre flere steder.
Fordeler med containere: Konsistent kjøremiljø	Løsningen fungerer likt i ulike miljøer.
Fordeler med containere: Løst koblet	Tjenester kan holdes adskilt.
Fordeler med containere: Distribuert	Egnet for moderne distribuerte systemer.
Fordeler med containere: Elastisk	Kapasitet kan justeres dynamisk.
Før smidige metoder: Vannfallsmodellen	Sekvensiell utviklingsmodell med faste faser.
Før smidige metoder: Unified Process (UP)	Iterativ prosess med mye modellering og struktur.
Grunnleggende prinsipper i smidig metode: Problem based	Store problemer brytes ned i mindre deler.
Grunnleggende prinsipper i smidig metode: Collaborative	Flere roller samarbeider tett gjennom hele prosessen.
Grunnleggende prinsipper i smidig metode: Iterativ	Løsningen utvikles og forbedres i gjentatte runder.
Grunnleggende prinsipper i smidig metode: Adaptiv	Planen og løsningen tilpasses ny læring og endring.
Agile Manifesto – fire hovedverdier: Individer og interaksjoner fremfor prosesser og verktøy	Mennesker og samarbeid prioriteres over rigide prosesser og verktøy.
Agile Manifesto – fire hovedverdier: Fungerende programvare fremfor omfattende dokumentasjon	Praktisk verdi prioriteres over tung dokumentasjon.
Agile Manifesto – fire hovedverdier: Kundesamarbeid fremfor kontraktsforhandlinger	Kontinuerlig dialog er viktigere enn låste avtaler.
Agile Manifesto – fire hovedverdier: Reagere på endring fremfor å følge en plan	Tilpasning er viktigere enn rigid planfølgning.
Kjennetegn ved XP: Lite dokumentasjon	Fokus på kode og praksis framfor tunge dokumenter.
Kjennetegn ved XP: Lite modellering	Mindre vekt på omfattende forhåndsmodellering.
Kjennetegn ved XP: Tett feedback-loop	Raske tilbakemeldinger fra tester, kode og kunde.
Kjennetegn ved XP: Kort iterasjonstid	Små og hyppige leveranser.
Antall faste regler i XP: 29 regler	XP beskrives ofte som en metode med mange konkrete arbeidsregler.
Eksempler på XP-regler: Parprogrammering	To utviklere jobber sammen ved samme oppgave.
Eksempler på XP-regler: Skriv enhetstester før kode	Test først for å styre utviklingen.
Eksempler på XP-regler: Integrer én liten endring av gangen	Små endringer gjør feil lettere å oppdage.
Eksempler på XP-regler: Enkel og tydelig kode	Løsningen skal være så enkel som mulig.
Eksempler på XP-regler: Hyppig refaktorering	Forbedre kode kontinuerlig uten å endre atferd.
Eksempler på XP-regler: Korte feedback-looper	Rask respons på endringer og feil.
Eksempler på XP-regler: Hyppige tester	Kvalitet kontrolleres kontinuerlig.
Eksempler på XP-regler: Hyppige leveranser	Verdi leveres ofte.
Fem sentrale verdier i XP: Communication	Tydelig kommunikasjon i teamet.
Fem sentrale verdier i XP: Simplicity	Hold løsningen enkel.
Fem sentrale verdier i XP: Feedback	Lær raskt av tester og brukere.
Fem sentrale verdier i XP: Courage	Tør å endre og forbedre kode når det trengs.
Fem sentrale verdier i XP: Respect	Respekt for teamet, koden og arbeidet.
Grunnidé i TDD: Skriv test først	Definere forventet oppførsel før implementasjon.
Grunnidé i TDD: Kjør testen og se at den feiler	Bekrefte at testen faktisk fanger manglende funksjonalitet.
Grunnidé i TDD: Skriv kode som får testen til å bestå	Implementere minimum som trengs for å få testen grønn.
Grunnidé i TDD: Refaktorer	Forbedre koden uten å endre funksjonaliteten.
Fokus i TDD: Primært enhetstesting	TDD brukes hovedsakelig på små isolerte funksjoner eller klasser.
Fokus i TDD: Noen ganger integrasjonstesting	TDD kan i enkelte tilfeller brukes bredere enn enhetstester.
Fokus i TDD: Sjelden systemtesting	TDD brukes oftest nær kodenivå, ikke på helsystemnivå.
Fordeler med TDD: Bedre kodekvalitet	Designet blir ofte ryddigere og mer gjennomtenkt.
Fordeler med TDD: Høyere testdekning	Flere deler av koden får tester.
Fordeler med TDD: Rask tilbakemelding	Feil oppdages tidlig i utviklingen.
Fordeler med TDD: Økt tillit	Det blir lettere å endre kode når testene beskytter funksjonaliteten.
Fordeler med TDD: Testene fungerer som dokumentasjon	Testene viser hva systemet skal gjøre.
Ulemper med TDD: Lærekurve	TDD krever en ny måte å tenke og arbeide på.
Ulemper med TDD: Tidsbruk til å skrive tester	Det krever ekstra innsats, særlig i starten.
Ulemper med TDD: Vedlikehold av tester	Testene må oppdateres når systemet endres.
Hovedidé i BDD: Kobler forretningsmål og teknologi	Teknisk utvikling knyttes til bruker- og forretningsverdi.
Hovedidé i BDD: Beskriver systematferd fra brukerens perspektiv	Fokus på hva systemet skal gjøre for brukeren.
Hovedidé i BDD: Bruker naturlig språk	Krav uttrykkes i et språk flere kan forstå.
Given-When-Then-formatet: Given (Gitt)	Beskriver starttilstand eller kontekst.
Given-When-Then-formatet: When (Når)	Beskriver handlingen eller hendelsen.
Given-When-Then-formatet: Then (Så)	Beskriver forventet resultat.
Nøkkelelementer i Gherkin: Feature	Overordnet funksjonalitet eller egenskap.
Nøkkelelementer i Gherkin: Scenario	Konkret eksempel på oppførsel.
Nøkkelelementer i Gherkin: Given	Forutsetning eller starttilstand i et scenario.
Nøkkelelementer i Gherkin: When	Handling eller hendelse i et scenario.
Nøkkelelementer i Gherkin: Then	Forventet resultat i et scenario.
Nøkkelelementer i Gherkin: And	Ekstra steg som bygger videre på de andre.
Hva BDD bidrar til: Tydeligere akseptkriterier	Det blir lettere å forstå hva som må være oppfylt.
Hva BDD bidrar til: Felles forståelse mellom forretning og utvikling	Misforståelser reduseres mellom tekniske og ikke-tekniske parter.
Hva BDD bidrar til: Testbar spesifikasjon	Krav kan omsettes til tester.
Hva BDD bidrar til: Høyere fokus på brukerens perspektiv	Atferd beskrives og vurderes fra sluttbrukerens side.
Scrum	Tidsboksbasert smidig rammeverk der arbeid organiseres i sprinter.
Fokus i Scrum: Kryssfunksjonelle team	Teamet skal samlet ha kompetansen som trengs.
Fokus i Scrum: Sprinter	Korte, faste iterasjoner i Scrum.
Fokus i Scrum: Inkrementell fremgang	Produktet forbedres litt etter litt.
Scrum-seremonier: Sprint planning	Planlegging av hva som skal gjøres i sprinten.
Scrum-seremonier: Daily standup / daily scrum	Kort daglig møte for koordinering.
Scrum-seremonier: Sprint review	Gjennomgang av sprintresultatet med interessenter.
Scrum-seremonier: Retrospektiv	Refleksjon over hvordan teamet kan forbedre arbeidsprosessen.
Typiske artefakter i Scrum: Product backlog	Prioritert liste over alt som kan gjøres i produktet.
Typiske artefakter i Scrum: Sprint backlog	Utvalget av arbeid som tas inn i en sprint.
Typiske artefakter i Scrum: Product backlog items (PBI)	Enkeltenheter i product backlog.
Typiske artefakter i Scrum: Scrum board	Visuell tavle for oppgaver i sprinten.
Lean-prinsipper: Eliminate waste	Fjern arbeid som ikke gir verdi.
Lean-prinsipper: Build quality in	Kvalitet skal bygges inn i prosessen, ikke bare kontrolleres til slutt.
Lean-prinsipper: Create knowledge	Læring og tilbakemelding skal brukes aktivt.
Lean-prinsipper: Defer commitment	Vent med irreversible valg til man vet mer.
Lean-prinsipper: Deliver fast	Lever verdi raskt.
Lean-prinsipper: Respect people	Stol på og støtt menneskene i systemet.
Lean-prinsipper: Optimize the whole	Se helheten, ikke bare enkeltledd.
Kanban	Flytbasert arbeidsmåte med kontinuerlig levering og visuell styring.
Kjennetegn ved Kanban: Flytbasert	Fokus på jevn gjennomstrømning av arbeid.
Kjennetegn ved Kanban: Kontinuerlig levering	Arbeid leveres fortløpende.
Kjennetegn ved Kanban: Ingen faste iterasjoner	I motsetning til Scrum styres ikke arbeidet av sprinter.
Kjennetegn ved Kanban: Visuell styring	Tavler brukes til å synliggjøre status og flyt.
Viktige elementer i Kanban: Kanban-board	Tavle som visualiserer arbeidsflyten.
Viktige elementer i Kanban: Begrensning av arbeid i prosess (WIP)	Setter grenser for hvor mange oppgaver som kan være i arbeid samtidig.
Viktige elementer i Kanban: Fokus på flaskehalser	Prosessen forbedres der arbeidet stopper opp.
Formål med WIP-begrensning: Synliggjøre flaskehalser	Gjør problemer i flyten tydelige.
Formål med WIP-begrensning: Forbedre flyt	Reduserer opphopning av arbeid.
Formål med WIP-begrensning: Hjelpe teammedlemmer å bidra der det stopper opp	Fremmer samarbeid på tvers av oppgaver og kolonner.
Domain-Driven Design (DDD)	Utviklingstilnærming med høyt fokus på domenet og domenets begreper.
Kjennetegn ved DDD: Høyt fokus på domenet	Utviklingen tar utgangspunkt i problemområdet.
Kjennetegn ved DDD: Koden skal gjenspeile virkeligheten	Modell og kode bør bruke samme begreper som domenet.
Kjennetegn ved DDD: Egnet for skalering og endring	God domeneforståelse gjør videreutvikling lettere.
Kjennetegn ved DDD: Fokus på det viktigste i domenet	Prioriterer kjernebegreper og kjerneprosesser.
Hva DevOps kombinerer: Utvikling (Dev)	Bygging og forbedring av programvare.
Hva DevOps kombinerer: Drift (Ops)	Utrulling, overvåking og vedlikehold i produksjon.
DevOps skal sikre: Kontinuerlig integrasjon	Kode integreres ofte i en felles gren.
DevOps skal sikre: Kontinuerlig levering / deploy	Kode kan leveres eller settes i drift raskt og trygt.
DevOps skal sikre: Tettere samarbeid mellom utvikling og drift	Færre siloer mellom team og ansvar.
CI (Continuous Integration): Hyppig integrasjon til felles gren	Små endringer flettes ofte inn.
CI (Continuous Integration): Automatisk bygging	Systemet bygges automatisk ved endringer.
CI (Continuous Integration): Automatisk testing	Tester kjøres automatisk som del av byggprosessen.
CD (Continuous Delivery / Deployment): Automatisk levering / deploy av kodeendringer	Endringer kan settes i drift med mindre manuelt arbeid.
DevOps-verktøy: GitLab / GitHub	Versjonskontroll og samarbeid om kode.
DevOps-verktøy: Jira / Confluence	Verktøy for planlegging og dokumentasjon.
DevOps-verktøy: Maven	Byggverktøy for Java.
DevOps-verktøy: Gradle	Fleksibelt byggverktøy.
DevOps-verktøy: Jenkins	Automatiserings- og CI-server.
DevOps-verktøy: JUnit	Testverktøy for Java.
DevOps-verktøy: Selenium	Verktøy for automatisert system- og UI-testing.
DevOps-verktøy: Kubernetes	Plattform for orkestrering og styring av containere.
DevOps-verktøy: Helm	Pakkebehandling for Kubernetes.
DevOps-verktøy: Docker	Teknologi for å bygge og kjøre containere.
DevOps-verktøy: Kibana	Visualisering av logger og søk.
DevOps-verktøy: Grafana	Visualisering av målinger og monitorering.
REST	Arkitekturstil der ressurser identifiseres via URI-er og manipuleres med HTTP-metoder.
REST-prinsipper i pensum: Klient-tjener	Klient og server har ulike roller og ansvar.
REST-prinsipper i pensum: Ressurser identifiseres via URI-er	Data og funksjonalitet modelleres som ressurser.
REST-prinsipper i pensum: Ressurser manipuleres via HTTP-metoder	Standardiserte operasjoner brukes for å hente og endre data.
HTTP-metoder i pensum: GET	Hente data.
HTTP-metoder i pensum: POST	Opprette ny ressurs.
HTTP-metoder i pensum: PUT	Oppdatere eller erstatte en ressurs.
HTTP-metoder i pensum: DELETE	Slette en ressurs.
Hvorfor teste: Sikre riktig respons ved input/interaksjon	Systemet må reagere riktig på brukerhandlinger.
Hvorfor teste: Finne bugs	Feil må oppdages før brukerne gjør det.
Hvorfor teste: Verifisere ytelse under edge cases	Systemet må tåle krevende eller uvanlige situasjoner.
Hvorfor teste: Vurdere brukervennlighet	Løsningen må være god å bruke.
Hvorfor teste: Kontrollere at krav er oppfylt	Systemet må gjøre det som er avtalt.
Hvorfor teste: Kontrollere at systemet kan installeres i riktig miljø	Løsningen må fungere der den skal kjøres.
Hvorfor teste: Kontrollere at systemet tåler endringer	Videreutvikling må ikke ødelegge eksisterende funksjonalitet.
Testing principles: Testing shows the presence of defects	Testing kan vise at feil finnes, men ikke bevise at ingen feil finnes.
Testing principles: Exhaustive testing is impossible	Det er umulig å teste absolutt alt.
Testing principles: Early testing	Testing bør starte tidlig.
Testing principles: Defects clustering	Mange feil samler seg ofte i noen få deler av systemet.
Testing principles: Pesticide paradox	De samme testene finner færre nye feil over tid.
Testing principles: Testing is context dependent	Teststrategien må tilpasses situasjonen.
Testing principles: Absence of error fallacy	Et feilfritt system er ikke nyttig hvis det løser feil problem.
Tradisjonell testing	Utvikling og testing skjer separat, ofte med eget QA-team.
Tradisjonell testing: Utvikling og testing skjer separat	Et team lager systemet, et annet tester det.
Tradisjonell testing: QA-team kvalitetssikrer etter utvikling	Test kommer ofte sent i prosessen.
Ulempe ved tradisjonell testing: Mye tid går til kommunikasjon og overlevering	Feil blir dyrere og tregere å håndtere.
Smidig testing	Utviklere tester egen kode kontinuerlig gjennom små inkrementer og automatisering.
Smidig testing: Utviklere tester egen kode kontinuerlig	Test skjer parallelt med utviklingen.
Smidig testing: Små inkrementer	Mindre endringer testes og leveres ofte.
Smidig testing: Automatiserte tester brukes mye	Rask feedback er viktig i smidig utvikling.
Fordeler ved smidig testing: Raskere feedback	Feil oppdages tidlig.
Fordeler ved smidig testing: Tettere kobling mellom utvikling og kvalitet	Kvalitet bygges inn underveis.
Fordeler ved smidig testing: QA kan fokusere på viktige scenarioer	Manuell test kan brukes der den gir størst verdi.
Når automatiserte tester ofte kjøres: Ved opprettelse av pull request	Nye endringer testes før sammenslåing.
Når automatiserte tester ofte kjøres: I CI-pipelines	Testing inngår i automatisert byggflyt.
Når automatiserte tester ofte kjøres: Ved nye kodeendringer	Hyppig kjøring gir rask tilbakemelding.
Kjennetegn ved automatiserte tester: Enhetstester og integrasjonstester kjøres automatisk	Vanlige testnivåer for automatisering.
Kjennetegn ved automatiserte tester: Resultater rapporteres raskt	Utviklere får rask oversikt over feil.
Fordeler ved automatiserte tester: Rask feedback	Feil oppdages tidlig.
Fordeler ved automatiserte tester: Høy hastighet	Mange tester kan kjøres raskt.
Fordeler ved automatiserte tester: Kontinuerlig kontroll	Kvalitet følges opp automatisk.
Fordeler ved automatiserte tester: Forutsigbar kvalitet	Samme test kjøres likt hver gang.
Fordeler ved automatiserte tester: Kostnadsbesparende over tid	Reduserer manuelt, repeterende arbeid.
Ulemper / utfordringer ved automatiserte tester: Høy oppstarts- og vedlikeholdskostnad	Testene må bygges og holdes oppdatert.
Ulemper / utfordringer ved automatiserte tester: Krever riktig fokus og god testdesign	Dårlige automatiserte tester gir liten verdi.
Kjennetegn ved egne test-/staging-miljøer: Testmiljø speiler produksjonsmiljø	Test skjer i omgivelser som ligner virkeligheten.
Kjennetegn ved egne test-/staging-miljøer: Hele applikasjonen kan testes før release	Gir helhetlig kontroll før utrulling.
Fordeler ved egne test-/staging-miljøer: Mer realistisk testing	Større sjanse for å finne reelle feil.
Fordeler ved egne test-/staging-miljøer: QA kan teste hele applikasjonen	Test kan gjennomføres også på systemnivå.
Fordeler ved egne test-/staging-miljøer: Infrastructure as Code gjør oppsett enklere	Miljøer kan opprettes og vedlikeholdes systematisk.
Fordeler med CI og små endringer: Mindre diff mellom gammel og ny versjon	Endringer blir lettere å forstå.
Fordeler med CI og små endringer: Enklere isolering av feil	Det blir lettere å finne hva som gikk galt.
Fordeler med CI og små endringer: Enklere sporing av endringer	Bedre oversikt over historikk og årsak.
Fordeler med CI og små endringer: Lavere sannsynlighet for feil	Små endringer er lettere å kontrollere.
Fordeler med CI og små endringer: Enklere rollback	Det blir enklere å rulle tilbake en liten endring.
Viktige prinsipper ved prioritering av testing: Finn riktig nivå på testdekning basert på risiko	Ikke alt må testes like mye.
Viktige prinsipper ved prioritering av testing: Prioriter tester som gir størst verdi	Test der konsekvensen av feil er størst.
Viktige prinsipper ved prioritering av testing: Prioriter tester som reduserer mest usikkerhet	Test der usikkerheten er størst.
Hva man vurderer i risk poker: Risiko	Sannsynlighet for at noe går galt.
Hva man vurderer i risk poker: Konsekvens	Hvor alvorlig det blir hvis det går galt.
Hva man vurderer i risk poker: Risikofaktorer	Forhold som påvirker sannsynlighet eller konsekvens.
Fordeler ved risk poker: Hele teamet deltar	Flere perspektiver tas med i vurderingen.
Fordeler ved risk poker: Bedre treffsikkerhet	Samlet vurdering blir ofte bedre enn individuell vurdering.
Fordeler ved risk poker: Felles forståelse av risiko	Teamet blir enige om hva som er kritisk.
Egenskaper ved gode testdata: Samme data hver gang	Testresultater kan sammenlignes pålitelig.
Egenskaper ved gode testdata: Deterministisk prosess	Samme input gir samme output.
Egenskaper ved gode testdata: Forutsigbart testmiljø	Eksterne tilfeldigheter påvirker minst mulig.
Fordeler ved testdata: Enklere å isolere feil	Avvik blir lettere å forklare.
Fordeler ved testdata: Mer presise testresultater	Resultatene blir mer pålitelige.
Fordeler ved testdata: Bedre analyse av testutfall	Utviklere kan tolke funn mer sikkert.
Mocking	Teknikk der ekte og komplekse avhengigheter erstattes med kontrollerte testdobler.
Hva mocking brukes til: Erstatte ekte og komplekse avhengigheter	Systemer byttes ut når de er upraktiske eller ustabile i test.
Hva mocking brukes til: Isolere klasser / moduler i test	Teste én del uten ekte avhengigheter.
Typiske avhengigheter som kan mocket: Database	Kan mocket for å unngå ekte database i test.
Typiske avhengigheter som kan mocket: Eksternt API	Kan mocket for å unngå nettverkskall og ustabile svar.
Typiske avhengigheter som kan mocket: Betalingstjeneste	Kan mocket for å simulere betaling uten ekte transaksjoner.
Hva som gjør mocking ideelt: Deterministiske svar	Testene får samme respons hver gang.
Hva som gjør mocking ideelt: Samme grensesnitt som ekte avhengighet	Kan byttes inn uten å endre resten av koden.
Hva som gjør mocking ideelt: Kombineres godt med dependency injection	Avhengigheter kan settes inn ved kjøring.
Fordeler ved mocking: Muliggjør isolert testing	Én del kan testes alene.
Fordeler ved mocking: Gjør automatiserte tester mulige i flere situasjoner	Flere deler av systemet blir testbare.
Fordeler ved mocking: Gir kontroll over testmiljøet	Reduserer usikkerhet i testkjøringen.
Testfaser: Oppsett	Forberede testdata og testmiljø.
Testfaser: Gjennomføring	Utføre handlingene testen beskriver.
Testfaser: Verifisering	Kontrollere at resultatet ble som forventet.
Testfaser: Opprydding	Fjerne eller nullstille ressurser før neste test.
Enhetstesting	Testing av små, isolerte funksjoner eller klasser.
Kjennetegn ved enhetstesting: Tester individuelle klasser / funksjoner	Små deler testes isolert.
Kjennetegn ved enhetstesting: Fokus på små enheter	Enkel funksjonalitet står i sentrum.
Kjennetegn ved enhetstesting: Ofte utviklers ansvar	Utvikleren skriver og vedlikeholder ofte testene.
Fordeler ved enhetstesting: Automatisert	Kan enkelt kjøres ofte.
Fordeler ved enhetstesting: Repeterbar	Gir like resultater ved samme input.
Fordeler ved enhetstesting: Kjøres i byggeprosessen	Er en naturlig del av utviklingsflyten.
Mål med enhetstesting: Finne feil tidlig	Feil fanges før de sprer seg videre.
Mål med enhetstesting: Stoppe feil før integrasjon med andre deler	Hindrer at små feil blir større problemer.
Integrasjonstesting	Testing av samspill mellom komponenter.
Kjennetegn ved integrasjonstesting: Tester samspill mellom komponenter	Ser på hvordan delene virker sammen.
Kjennetegn ved integrasjonstesting: Bygger på at delene allerede er testet individuelt	Enhetstesting bør være gjennomført først.
Mål med integrasjonstesting: Oppdage feil i grensesnitt og samhandling	Avdekker problemer i koblingene mellom delene.
Valg ved integrasjonstesting: Kan automatiseres	Mange integrasjonstester egner seg godt for automatisering.
Valg ved integrasjonstesting: Bør automatiseres der det er hensiktsmessig	Særlig ved hyppige og kritiske samspill.
Systemtesting	Testing av hele systemet som en helhet.
Kjennetegn ved systemtesting: Tester hele systemet	Systemet ses og vurderes som en helhet.
Kjennetegn ved systemtesting: Sjekker at alle deler fungerer sammen	Helhetlig kvalitet kontrolleres.
Fordeler ved systemtesting: Finner feil mellom deler av systemet	Noen problemer oppstår bare i helheten.
Fordeler ved systemtesting: Gir trygghet før levering	Gir bedre grunnlag for release.
Mål med systemtesting: Sjekke at systemet oppfyller krav	Både funksjonelle og ofte ikke-funksjonelle krav vurderes.
Mål med systemtesting: Finne feil før bruk	Redusere risiko før sluttbruker møter løsningen.
Valg ved systemtesting: Kan utføres med verktøy som Selenium	Deler av helheten kan automatiseres.
Valg ved systemtesting: Kan være vanskelig å gjøre helt repeterbar	Mange avhengigheter påvirker resultatet.
Akseptansetesting	Systemtesting som verifiserer at krav og behov er oppfylt.
Kjennetegn ved akseptansetesting: Type systemtesting	Foregår på høyt nivå i systemet.
Kjennetegn ved akseptansetesting: Utføres for å verifisere at krav er oppfylt	Særlig mot kundens eller brukerens forventninger.
Viktig i BDD: Bygger på user stories	Kobler krav og test tett sammen.
Viktig i BDD: Kan utvikles sammen med kunden	Gir bedre samsvar med behovene.
Akseptansetesting kan være: Manuell testing	Mennesker går gjennom scenarier og vurderer resultatene.
Akseptansetesting kan være: Automatisert testing	Scenarioer kan kjøres automatisk.
Regresjonstesting	Testing som sikrer at endringer ikke ødelegger eksisterende funksjonalitet.
Hva regresjonstesting er: Tester at endringer ikke ødelegger eksisterende funksjonalitet	Gammel funksjon må fortsatt virke etter endringer.
Når regresjonstesting skjer: Før og etter endringer	Brukes for å sammenligne oppførsel.
Når regresjonstesting skjer: Kontinuerlig i CI ved innsjekk av kode	Skjer ofte automatisk i moderne utvikling.
Regresjonstesting kan finnes på: Enhetstestnivå	Små deler testes på nytt.
Regresjonstesting kan finnes på: Integrasjonsnivå	Samspill testes på nytt.
Regresjonstesting kan finnes på: Akseptansenivå	Brukerorientert oppførsel testes på nytt.
Valg ved regresjonstesting: Egner seg godt for automatisering	De samme testene kjøres mange ganger.
Smoke-testing	Rask test av kritisk funksjonalitet for å se om systemet i det hele tatt fungerer.
Smoke-testing: Tester kritisk funksjonalitet	Sjekker at systemets viktigste deler virker.
Smoke-testing: Rask sjekk av om systemet i det hele tatt fungerer	Avgjør om videre testing er verdt å starte.
Sanity-testing	Rask test av ny eller endret funksjonalitet for å se om endringen virker rimelig.
Sanity-testing: Tester ny eller endret funksjonalitet	Fokuserer på den siste endringen.
Sanity-testing: Rask sjekk av om en spesifikk endring virker fornuftig	Er smalere enn smoke-testing.
Hvorfor smoke-testing og sanity-testing er nyttige: Avdekker tidlig om videre testing er hensiktsmessig	Sparer tid hvis systemet er for ustabilt.
Destruktiv testing	Kreativ testing der målet er å få systemet til å feile.
Destruktiv testing: Kreativ testing for å få systemet til å feile	Systemets grenser og svakheter presses bevisst.
Destruktiv testing: Kan ikke automatiseres	Bygger på menneskelig kreativitet og erfaring.
Destruktiv testing: Krever menneskelig erfaring og kreativitet	Testeren må tenke utradisjonelt.
Utforskende testing	Testing der læring, testdesign og testgjennomføring skjer samtidig.
Utforskende testing: Tester med aktiv læring og utforsking underveis	Testeren justerer testene mens innsikten øker.
Utforskende testing: Bygger på innsikt i systemet og nye hypoteser	Man følger spor og ideer som oppstår underveis.
Forskjell: Destruktiv testing	Fokus er å bryte systemet og finne svakheter ved å presse løsningen.
Forskjell: Utforskende testing	Fokus er bredere utforsking, læring og feilfunn underveis.
Usabilitytesting	Testing av brukervennlighet og brukeropplevelse.
Usabilitytesting tester: Brukervennlighet	Hvor lett systemet er å bruke.
Usabilitytesting tester: GUI	Hvordan det grafiske brukergrensesnittet fungerer.
Usabilitytesting tester: Om brukeren / kunden er fornøyd	Opplevd kvalitet og tilfredshet.
Ytelsestesting	Testing av kapasitet, responstid og stabilitet under belastning.
Ytelsestesting undersøker: Hvor mye last systemet tåler	Kapasitet under normal eller høy belastning.
Ytelsestesting undersøker: Hvor mye plutselig last systemet tåler	Systemets reaksjon på raske lasttopper.
Ytelsestesting undersøker: Ytelse over tid	Stabilitet og ressursbruk ved langvarig drift.
Ytelsestesting undersøker: Lekkasjer / ressursproblemer	For eksempel minnelekkasjer eller ressursoppbygging over tid.
Hvordan ytelse måles: Antall samtidige brukere	Hvor mange som bruker systemet samtidig.
Hvordan ytelse måles: Transaksjoner per tidsenhet	Hvor mye arbeid systemet utfører per tidsrom.
Hvordan ytelse måles: Throughput	Mengde data eller arbeid som behandles over tid.
Hvordan ytelse måles: Responstid	Hvor lang tid systemet bruker på å svare.
Flaskehals	Systemets svakeste eller tregeste punkt som begrenser total ytelse.
Vanlige årsaker til flaskehalser: CPU	Prosessoren er overbelastet.
Vanlige årsaker til flaskehalser: Minne	For lite eller ineffektiv bruk av RAM.
Vanlige årsaker til flaskehalser: Tråder	Dårlig håndtering av parallellitet eller venting.
Vanlige årsaker til flaskehalser: Databasetilkobling	Database eller forbindelser blir begrensningen.
Typer ytelsestester: Lasttest	Måler oppførsel ved forventet eller gradvis økende last.
Typer ytelsestester: Stresstest	Finner yttergrensen der systemet bryter sammen.
Typer ytelsestester: Spike-test	Tester reaksjon på plutselige lasttopper.
Typer ytelsestester: Utholdenhetstest	Tester systemet under jevn belastning over tid.
Black-box testing	Testing uten innsikt i intern kode, basert på input og output.
Black-box testing: Ingen innsikt i intern kode	Testeren ser bare input og output.
Black-box testing: Bygger på krav, spesifikasjoner og forventet oppførsel	Testingen tar utgangspunkt i ytre oppførsel, ikke intern implementasjon.
White-box testing	Testing med innsikt i intern kode og struktur.
White-box testing: Full innsikt i intern kode og struktur	Testeren kjenner logikk og oppbygning.
White-box testing: Tester intern logikk og oppbygning	Dekker veier, betingelser og intern struktur.
Fordeler ved automatiske tester: Raske	Kan kjøres ofte og på kort tid.
Fordeler ved automatiske tester: Nøyaktige	Samme fremgangsmåte brukes hver gang.
Fordeler ved automatiske tester: Repeterbare	Resultatene blir konsistente ved lik input.
Fordeler ved automatiske tester: Gode for kjente forventninger	Passer godt der riktig resultat er tydelig definert.
Typiske automatiserte tester: Enhetstester	Tester små, isolerte kodeenheter.
Typiske automatiserte tester: Regresjonstester	Sjekker at gammel funksjonalitet fortsatt virker.
Typiske automatiserte tester: Mange integrasjonstester	Tester samspill mellom komponenter.
Typiske automatiserte tester: Mange ytelsestester	Automatiske last- og stresstester.
Ulemper ved automatiske tester: Krever vedlikehold	Testene må oppdateres når systemet endres.
Ulemper ved automatiske tester: Fanger ikke alt	Automatiserte tester er særlig svake på subjektive forhold.
Ulemper ved automatiske tester: Dårligere på kreative og uventede problemer	Mennesker er bedre til utforskning og improvisasjon.
Fordeler ved manuelle tester: Kreative	Testeren kan tenke fritt og prøve uventede ting.
Fordeler ved manuelle tester: Fanger ofte naturlige brukerfeil og uventede problemer	Realistisk menneskelig bruk avdekkes bedre.
Fordeler ved manuelle tester: Gode for utforsking og opplevelse	Spesielt viktig for usability og ad hoc-testing.
Typiske manuelle tester: Utforskende testing	Læring og test skjer samtidig.
Typiske manuelle tester: Destruktiv testing	Kreativ testing for å bryte systemet.
Typiske manuelle tester: Mye usabilitytesting	Vurdering av opplevelse og brukeradferd.
Testtyper som kan være både manuelle og automatiske: Smoke-testing	Rask helsesjekk av løsning.
Testtyper som kan være både manuelle og automatiske: Sanity-testing	Rask sjekk av endret funksjonalitet.
Testtyper som kan være både manuelle og automatiske: Integrasjonstesting	Testing av samspill mellom komponenter.
Testtyper som kan være både manuelle og automatiske: Systemtesting	Helhetlig testing av systemet.
Testtyper som kan være både manuelle og automatiske: Akseptansetesting	Verifisering mot behov og krav.
Testtyper som kan være både manuelle og automatiske: Ytelsestesting	Måling av kapasitet og responstid.
GDPR-prinsipp: Lovlighet, rimelighet og gjennomsiktighet	Behandling må være lovlig, rettferdig og forståelig for den registrerte.
GDPR-prinsipp: Formålsbegrensning	Data skal bare brukes til tydelig definerte formål.
GDPR-prinsipp: Dataminimering	Bare nødvendige opplysninger skal samles inn.
GDPR-prinsipp: Riktighet	Opplysninger skal være korrekte og oppdaterte.
GDPR-prinsipp: Lagringsbegrensning	Data skal ikke lagres lenger enn nødvendig.
GDPR-prinsipp: Integritet og konfidensialitet	Data skal beskyttes mot uautorisert tilgang og tap.
GDPR-prinsipp: Ansvarliggjøring	Virksomheten må kunne dokumentere at reglene følges.
De registrertes rettigheter: Rett til informasjon	Den registrerte skal få vite hvilke data som behandles og hvorfor.
De registrertes rettigheter: Rett til innsyn	Den registrerte skal få tilgang til egne opplysninger.
De registrertes rettigheter: Rett til retting	Den registrerte skal få uriktige opplysninger korrigert.
De registrertes rettigheter: Rett til sletting	Den registrerte kan kreve at opplysninger fjernes i visse tilfeller.
De registrertes rettigheter: Rett til begrensning	Den registrerte kan kreve at behandling stoppes midlertidig.
De registrertes rettigheter: Rett til å protestere	Den registrerte kan motsette seg visse typer behandling.
De registrertes rettigheter: Rett til dataportabilitet	Den registrerte kan få egne data ut i et maskinlesbart format.
Typiske unntak / begrensninger i GDPR: Juridisk forpliktelse	Behandling kan være nødvendig for å oppfylle lovkrav.
Typiske unntak / begrensninger i GDPR: Offentlig sikkerhet	Noen rettigheter kan begrenses av samfunnshensyn.
Typiske unntak / begrensninger i GDPR: Forskning	Særregler kan gjelde ved forskning og statistikk.
Ingeniørens ansvar omfatter blant annet: Sosialt ansvar	Teknologi påvirker samfunn, arbeidsliv og mennesker.
Ingeniørens ansvar omfatter blant annet: Sikkerhet og pålitelighet	Systemer må være trygge og til å stole på.
Ingeniørens ansvar omfatter blant annet: Brukeres velferd	Løsninger må ikke skade brukerne eller deres livssituasjon.
Ingeniørens ansvar omfatter blant annet: AI og militær bruk / alvorlige konsekvenser av teknologi	Utviklere må reflektere over alvorlige anvendelser og ansvar.
Eksempler på NITO-prinsipper: Vise respekt for kolleger	Rettferdig og profesjonell behandling av andre.
Eksempler på NITO-prinsipper: Vedkjenne seg faglig ansvar	Stå inne for eget arbeid og egne vurderinger.
Eksempler på NITO-prinsipper: Følge anerkjente kvalitetsnormer	Bruke faglig gode standarder og praksiser.
Eksempler på NITO-prinsipper: Bidra til åpenhet om teknologiske konsekvenser	Ikke skjule risiko eller negative effekter.
IEEE/ACM Code of Ethics – hovedområder: Samfunn	Arbeid i offentlighetens interesse.
IEEE/ACM Code of Ethics – hovedområder: Kunde og arbeidsgiver	Opptre ansvarlig overfor dem man arbeider for.
IEEE/ACM Code of Ethics – hovedområder: Produkt	Sikre høy kvalitet i programvare og løsninger.
IEEE/ACM Code of Ethics – hovedområder: Vurdering	Utvise integritet og faglig skjønn.
IEEE/ACM Code of Ethics – hovedområder: Ledelse	Fremme etisk ledelse i utviklingsarbeid.
IEEE/ACM Code of Ethics – hovedområder: Profesjon	Styrke profesjonens integritet og omdømme.
IEEE/ACM Code of Ethics – hovedområder: Kolleger	Støtte og behandle kolleger rettferdig.
IEEE/ACM Code of Ethics – hovedområder: Egen utvikling / livslang læring	Holde seg faglig oppdatert og utvikle seg videre.
Nøkkelprinsipper i profesjonsetikken: Ærlighet og integritet	Være sannferdig om begrensninger og risiko.
Nøkkelprinsipper i profesjonsetikken: Respekt for personvern	Bygge løsninger som beskytter individet.
Nøkkelprinsipper i profesjonsetikken: Kvalitetsbevissthet	Arbeide systematisk for god kvalitet.
Nøkkelprinsipper i profesjonsetikken: Ansvar for konsekvenser	Vurdere hvordan teknologien påvirker mennesker og samfunn.
Nøkkelprinsipper i profesjonsetikken: Kontinuerlig vurdering	Etiske vurderinger må gjøres gjennom hele prosessen.
Hvorfor profesjonsetikk henger sammen med kvalitet: Mer robuste systemer	Etisk bevissthet gir ofte bedre designvalg.
Hvorfor profesjonsetikk henger sammen med kvalitet: Færre sikkerhets- og personvernbrudd	Risiko håndteres tidligere i utviklingen.
Hvorfor profesjonsetikk henger sammen med kvalitet: Høyere brukertilfredshet	Brukere stoler mer på løsningen.
Hvorfor profesjonsetikk henger sammen med kvalitet: Beskytter omdømme	Både utviklere og virksomheter unngår tillitstap.
Hvorfor profesjonsetikk henger sammen med kvalitet: Reduserer risiko for bias og tillitsbrudd	Færre urettferdige eller skadelige løsninger.
Visjonsdokument – typisk innhold: Formål	Hvorfor prosjektet finnes.
Visjonsdokument – typisk innhold: Omfang	Hva prosjektet skal og ikke skal dekke.
Visjonsdokument – typisk innhold: Hensikt	Hva man ønsker å oppnå.
Visjonsdokument – typisk innhold: Målgruppe	Hvem løsningen er for.
Visjonsdokument – typisk innhold: Funksjonelle krav	Hva systemet skal gjøre.
Visjonsdokument – typisk innhold: Ikke-funksjonelle krav	Kvalitetskrav som ytelse, sikkerhet og brukervennlighet.
Visjonsdokument – typisk innhold: Interessenter	Personer eller grupper som påvirkes av prosjektet.
Visjonsdokument – typisk innhold: Brukerbehov	Behovene løsningen skal dekke.
Risikoanalyse – hva den brukes til: Identifisere risiko	Finne mulige problemer.
Risikoanalyse – hva den brukes til: Prioritere risiko	Vurdere hva som er viktigst å håndtere.
Risikoanalyse – hva den brukes til: Definere tiltak	Bestemme hva man skal gjøre med risikoene.
Risikoanalyse – hva den brukes til: Forbedre beslutningsprosesser	Gi bedre grunnlag for valg.
Risikoanalyse – hva den brukes til: Øke prosjektets robusthet	Gjøre prosjektet bedre rustet mot problemer.
```

Hvis du vil, kan jeg nå lage en **endelig v4** som bare gjør én ting til:
- **sorterer alt tematisk og alfabetisk innen hvert tema**, slik at det blir lettere å vedlikeholde og importere.
