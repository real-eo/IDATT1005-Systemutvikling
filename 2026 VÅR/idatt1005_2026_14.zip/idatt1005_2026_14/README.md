## Course Information
- **Course:** IDATT1005 - System Engineering
- **Institution:** NTNU (Norwegian University of Science and Technology)
- **Academic Year:** 2026

# Help Me Help (HmH) Application
![Team 14](https://img.shields.io/badge/Team-14-2F3E46?color=2F3E46)

A JavaFX desktop application designed to help users donate to trustworthy organizations verified by Innsamlingskontrollen (IK).

## Project Description

The Help Me Help application provides a user-friendly platform for making donations to verified charitable organizations. The application ensures transparency and trust by integrating with Innsamlingskontrollen's verification system.

### Key Features
- Browse verified charitable organizations
- Make secure donations to organizations
- Track personal donation history
- Manage user profile and preferences
- Filter organizations by category and verification status

## Team Members

- **Elias Alexander Wiklund Ottersbo** - [Role]
- **Adrian Wei Wang-Kristiansen** - [Role]
- **Nikolai Oliver Aasheim Lydvo** - [Role]

## Project Structure

```
hmh-application/
├── pom.xml                                 # Maven project configuration
├── Team 14- Collaboration Agreement.pdf    # Collaboration agreement document
├── README.md                               # Project documentation
├── .gitignore                              # Git ignore rules
└── src/
    ├── main/
    │   ├── java/
    │   │   └── no/ntnu/idatx1005/hmh/
    │   │       ├── HmHApp.java                     # Main class
    │   │       ├── model/                                  # Data models
    │   │       │   ├── User.java
    │   │       │   ├── Organization.java
    │   │       │   ├── Donation.java
    │   │       │   └── Profile.java
    │   │       ├── view/                                   # View layer (see resources/fxml)
    │   │       ├── controller/                             # JavaFX controllers
    │   │       │   ├── MainController.java
    │   │       │   ├── UserProfileController.java
    │   │       │   ├── OrganizationListController.java
    │   │       │   └── DonationController.java
    │   │       ├── dao/                                    # Data Access Objects
    │   │       │   ├── DatabaseConnection.java
    │   │       │   ├── UserDAO.java
    │   │       │   ├── OrganizationDAO.java
    │   │       │   └── DonationDAO.java
    │   │       ├── service/                                # Business logic layer
    │   │       │   ├── UserService.java
    │   │       │   ├── OrganizationService.java
    │   │       │   ├── DonationService.java
    │   │       │   └── InnsamlingsKontrollenService.java
    │   │       └── util/                                   # Utility classes
    │   └── resources/
    │       ├── fxml/                                       # FXML view files
    │       │   ├── MainView.fxml
    │       │   ├── UserProfileView.fxml
    │       │   ├── OrganizationListView.fxml
    │       │   └── DonationView.fxml
    │       ├── css/                                        # Stylesheets
    │       │   └── styles.css
    │       ├── images/                                     # Image assets
    │       └── database/                                   # Database schemas
    │           └── schema.sql
    └── test/
        └── java/
            └── no/ntnu/idatx1005/hmh/              # Test classes
                ├── model/
                ├── service/
                └── dao/
```

