# Checklist
## Already done
- JavaFX desktop app entry point exists in HmHApp.java
- SQLite persistence is wired through DatabaseConnection.java
- Database schema exists in schema.sql
- Core domain models exist for user, organization, donation, and profile
- DAO layer exists for users, organizations, and donations
- Service layer exists with validation and business logic
- FXML views exist for the main screen, user profile, organization list, and donation view
- Basic styling exists in styles.css
- Unit tests compile and pass; mvn test succeeded with 40 tests

## Must finish for a solid MVP
- Wire the main navigation in MainController.java so menu/buttons actually switch views instead of printing placeholder text
- Finish the organization table binding in OrganizationListController.java so rows show real data
- Implement organization detail handling instead of the placeholder selection behavior in OrganizationListController.java
- Replace the hardcoded currentUserId = 1L in DonationController.java with real session or selected-user handling
- Make the user profile load a real current user instead of leaving the session/context TODO in UserProfileController.java
- Add proper preferred-causes editing from the profile screen if that is part of your intended core features
- Decide and implement the Innsamlingskontrollen source: API or CSV, then replace the placeholder methods in InnsamlingsKontrollenService.java
- Ensure organizations are actually populated from the IK source or seeded data, not only from an empty local database
- Add a clear app startup flow so the app opens into a usable screen with real data
- Verify that donation creation, profile save/update, and organization browsing work together as one end-to-end flow

## Must finish for the assignment submission
- Document any AI usage in source code comments and in the report, as required by the brief
- Complete the project manual attachments: collaboration agreement, plan, timesheets, meeting minutes, and board screenshots
- Complete the vision document
- Finish the wiki pages and ensure the landing page includes the full team names
- Publish or prepare the JavaDoc link as required
- Write the final report and individual reflection report
- Package source code and JavaDoc for submission
- Make sure the Git repository is on NTNU GitHub and accessible to teachers

# Status
Technically, you are past the prototype stage and into MVP territory.
Functionally, the app is not yet complete enough to feel like a finished standalone product because several key flows are still placeholders.
Documentation and submission materials are likely the bigger remaining workload than the raw code.