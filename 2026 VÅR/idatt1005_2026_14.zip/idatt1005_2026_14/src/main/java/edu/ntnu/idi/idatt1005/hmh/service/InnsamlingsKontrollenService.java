package edu.ntnu.idi.idatt1005.hmh.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Service class for integrating with Innsamlingskontrollen (IK) API.
 * Provides functionality to verify organizations against IK's registry.
 * 
 * @author IDATT1005 Group 14
 */
public class InnsamlingsKontrollenService {

    /**
     * Constructs an InnsamlingsKontrollenService.
     */
    public InnsamlingsKontrollenService() {
        // Initialize API connection parameters
    }

    /**
     * Verifies an organization's status with Innsamlingskontrollen.
     * This is a placeholder for future API integration.
     *
     * @param registrationNumber the organization's registration number
     * @return the verification status from IK
     */
    public String verifyOrganization(String registrationNumber) {
        if (registrationNumber == null || registrationNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Registration number cannot be empty");
        }

        String status = lookupStatus(registrationNumber);
        return status != null ? status : "NOT_FOUND";
    }

    /**
     * Checks if an organization is registered with Innsamlingskontrollen.
     * This is a placeholder for future API integration.
     *
     * @param registrationNumber the organization's registration number
     * @return true if organization is registered with IK
     */
    public boolean isRegisteredWithIK(String registrationNumber) {
        if (registrationNumber == null || registrationNumber.trim().isEmpty()) {
            return false;
        }

        return lookupStatus(registrationNumber) != null;
    }

    /**
     * Retrieves detailed information about an organization from Innsamlingskontrollen.
     * This is a placeholder for future API integration.
     *
     * @param registrationNumber the organization's registration number
     * @return detailed information about the organization
     */
    public String getOrganizationDetails(String registrationNumber) {
        if (registrationNumber == null || registrationNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Registration number cannot be empty");
        }

        String details = lookupDetails(registrationNumber);
        return details != null ? details : "Organization details not available";
    }

    private String lookupStatus(String registrationNumber) {
        for (String[] record : loadData()) {
            if (record[1].equals(registrationNumber)) {
                return record[6];
            }
        }
        return null;
    }

    private String lookupDetails(String registrationNumber) {
        for (String[] record : loadData()) {
            if (record[1].equals(registrationNumber)) {
                return record[0] + " - " + record[2] + " (" + record[3] + ")";
            }
        }
        return null;
    }

    private List<String[]> loadData() {
        List<String[]> rows = new ArrayList<>();

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("database/organizations.csv")) {
            if (inputStream == null) {
                return rows;
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
                String line = reader.readLine();
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty()) {
                        continue;
                    }
                    String[] columns = line.split(",", -1);
                    if (columns.length >= 7) {
                        rows.add(columns);
                    }
                }
            }
        } catch (IOException e) {
            return rows;
        }

        return rows;
    }
}
