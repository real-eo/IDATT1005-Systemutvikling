package edu.ntnu.idi.idatt1005.hmh.util;

import edu.ntnu.idi.idatt1005.hmh.model.User;
import edu.ntnu.idi.idatt1005.hmh.service.UserService;

import java.sql.SQLException;
import java.util.List;

/**
 * Shared in-memory application state for the current user.
 *
 * @author IDATT1005 Group 14
 */
public final class AppSession {

    private static AppSession instance;

    private final UserService userService;
    private User currentUser;

    private AppSession() {
        this.userService = new UserService();
    }

    public static synchronized AppSession getInstance() {
        if (instance == null) {
            instance = new AppSession();
        }
        return instance;
    }

    public synchronized void initialize() throws SQLException {
        if (currentUser != null) {
            return;
        }

        List<User> users = userService.getAllUsers();
        if (!users.isEmpty()) {
            currentUser = users.get(0);
            return;
        }

        User demoUser = new User();
        demoUser.setName("Demo User");
        demoUser.setEmail("demo@hmh.local");
        demoUser.setPhoneNumber("+4700000000");
        demoUser.getPreferredCauses().add("Humanitarian aid");
        currentUser = userService.createUser(demoUser);
    }

    public synchronized User getCurrentUser() {
        return currentUser;
    }

    public synchronized Long getCurrentUserId() {
        return currentUser != null ? currentUser.getUserId() : null;
    }

    public synchronized void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
}