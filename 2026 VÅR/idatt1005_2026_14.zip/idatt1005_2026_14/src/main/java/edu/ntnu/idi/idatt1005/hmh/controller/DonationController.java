package edu.ntnu.idi.idatt1005.hmh.controller;

import edu.ntnu.idi.idatt1005.hmh.util.AppSession;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.*;
import edu.ntnu.idi.idatt1005.hmh.model.Donation;
import edu.ntnu.idi.idatt1005.hmh.model.Organization;
import edu.ntnu.idi.idatt1005.hmh.service.DonationService;
import edu.ntnu.idi.idatt1005.hmh.service.OrganizationService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/**
 * Controller for the donation view.
 * Handles donation processing and confirmation.
 * 
 * @author IDATT1005 Group 14
 */
public class DonationController {

    @FXML
    private ComboBox<Organization> organizationComboBox;

    @FXML
    private TextField amountField;

    @FXML
    private TextArea notesArea;

    @FXML
    private Button donateButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Label statusLabel;

    @FXML
    private Label totalDonatedLabel;

    private DonationService donationService;
    private OrganizationService organizationService;
    private Long currentUserId;                         // TODO: Get from session/context (#27)

    /**
     * Initializes the controller.
     * Called automatically after FXML loading.
     */
    @FXML
    public void initialize() {
        donationService = new DonationService();
        organizationService = new OrganizationService();
        
        loadCurrentUser();
        loadOrganizations();
        setupAmountValidation();
        setupOrganizationDisplay();
    }

    private void loadCurrentUser() {
        currentUserId = AppSession.getInstance().getCurrentUserId();
        if (currentUserId == null) {
            statusLabel.setText("No active user profile found");
        }
    }

    /**
     * Loads available organizations into the combo box.
     */
    private void loadOrganizations() {
        try {
            List<Organization> organizations = organizationService.getVerifiedOrganizations();
            organizationComboBox.getItems().setAll(organizations);
            if (!organizations.isEmpty()) {
                organizationComboBox.getSelectionModel().selectFirst();
            }
        } catch (SQLException e) {
            statusLabel.setText("Error loading organizations: " + e.getMessage());
        }
    }

    private void setupOrganizationDisplay() {
        organizationComboBox.setCellFactory(listView -> new ListCell<>() {
            @Override
            protected void updateItem(Organization item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getName());
            }
        });
        organizationComboBox.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Organization item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? "Select an organization" : item.getName());
            }
        });
    }

    /**
     * Sets up validation for the amount field.
     */
    private void setupAmountValidation() {
        amountField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*(\\.\\d{0,2})?")) {
                amountField.setText(oldValue);
            }
        });
    }

    /**
     * Handles the donate button action.
     * Processes the donation and saves it to the database.
     */
    @FXML
    public void handleDonate() {
        try {
            Organization selectedOrg = organizationComboBox.getValue();
            if (selectedOrg == null) {
                statusLabel.setText("Please select an organization");
                return;
            }

            String amountText = amountField.getText();
            if (amountText == null || amountText.trim().isEmpty()) {
                statusLabel.setText("Please enter a donation amount");
                return;
            }

            BigDecimal amount = new BigDecimal(amountText);
            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                statusLabel.setText("Donation amount must be greater than zero");
                return;
            }

            if (currentUserId == null) {
                statusLabel.setText("Please create or load a user profile first");
                return;
            }

            Donation donation = new Donation();
            donation.setUserId(currentUserId);
            donation.setOrganizationId(selectedOrg.getOrganizationId());
            donation.setAmount(amount);
            donation.setNotes(notesArea.getText());
            
            donationService.createDonation(donation);
            
            statusLabel.setText("Donation of " + amount + " NOK to " + 
                              selectedOrg.getName() + " successful!");
            
            clearForm(false);
            updateTotalDonated();

        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid amount format");
        } catch (SQLException e) {
            statusLabel.setText("Error processing donation: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            statusLabel.setText("Validation error: " + e.getMessage());
        }
    }

    /**
     * Handles the cancel button action.
     * Clears the form.
     */
    @FXML
    public void handleCancel() {
        clearForm(true);
    }

    /**
     * Clears all form fields.
     */
    private void clearForm(boolean clearStatus) {
        organizationComboBox.setValue(null);
        amountField.clear();
        notesArea.clear();
        if (clearStatus) {
            statusLabel.setText("");
        }
    }

    /**
     * Updates the total donated amount display.
     */
    private void updateTotalDonated() {
        try {
            if (currentUserId != null) {
                BigDecimal total = donationService.calculateTotalDonationsByUser(currentUserId);
                totalDonatedLabel.setText("Total donated: " + total + " NOK");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total donations: " + e.getMessage());
        }
    }

    /**
     * Sets the current user ID.
     *
     * @param userId the user ID to set
     */
    public void setCurrentUserId(Long userId) {
        this.currentUserId = userId;
        updateTotalDonated();
    }
}
