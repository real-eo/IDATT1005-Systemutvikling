package edu.ntnu.idi.idatt1005.hmh.controller;

import edu.ntnu.idi.idatt1005.hmh.util.AppSession;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import edu.ntnu.idi.idatt1005.hmh.model.User;
import edu.ntnu.idi.idatt1005.hmh.service.UserService;

import java.sql.SQLException;

/**
 * Controller for the user profile view.
 * Handles user profile display and editing functionality.
 * 
 * @author IDATT1005 Group 14
 */
public class UserProfileController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextArea preferredCausesArea;

    @FXML
    private Label statusLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private UserService userService;
    private User currentUser;

    /**
     * Initializes the controller.
     * Called automatically after FXML loading.
     */
    @FXML
    public void initialize() {
        userService = new UserService();
        loadCurrentUserFromSession();
    }

    private void loadCurrentUserFromSession() {
        loadUser(AppSession.getInstance().getCurrentUser());
    }

    /**
     * Loads user data into the form fields.
     *
     * @param user the user to display
     */
    public void loadUser(User user) {
        this.currentUser = user;
        if (user != null) {
            nameField.setText(user.getName());
            emailField.setText(user.getEmail());
            phoneField.setText(user.getPhoneNumber());
            if (user.getPreferredCauses() != null) {
                preferredCausesArea.setText(String.join(", ", user.getPreferredCauses()));
            }
        } else {
            clearForm();
        }
    }

    /**
     * Handles the save button action.
     * Saves or updates user profile.
     */
    @FXML
    public void handleSave() {
        try {
            if (currentUser == null) {
                currentUser = new User();
            }

            currentUser.setName(nameField.getText());
            currentUser.setEmail(emailField.getText());
            currentUser.setPhoneNumber(phoneField.getText());
            currentUser.setPreferredCauses(parsePreferredCauses(preferredCausesArea.getText()));

            if (currentUser.getUserId() == null) {
                currentUser = userService.createUser(currentUser);
                statusLabel.setText("User profile created successfully!");
            } else {
                userService.updateUser(currentUser);
                statusLabel.setText("User profile updated successfully!");
            }

            AppSession.getInstance().setCurrentUser(currentUser);
        } catch (SQLException e) {
            statusLabel.setText("Error saving user: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            statusLabel.setText("Validation error: " + e.getMessage());
        }
    }

    /**
     * Handles the cancel button action.
     * Clears the form or returns to previous view.
     */
    @FXML
    public void handleCancel() {
        loadCurrentUserFromSession();
        statusLabel.setText("Changes discarded");
    }

    /**
     * Clears all form fields.
     */
    private void clearForm() {
        nameField.clear();
        emailField.clear();
        phoneField.clear();
        preferredCausesArea.clear();
        statusLabel.setText("");
    }

    private java.util.List<String> parsePreferredCauses(String value) {
        if (value == null || value.trim().isEmpty()) {
            return new java.util.ArrayList<>();
        }

        return java.util.Arrays.stream(value.split(","))
                .map(String::trim)
                .filter(text -> !text.isEmpty())
                .collect(java.util.stream.Collectors.toList());
    }
}
