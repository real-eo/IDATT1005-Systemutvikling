package edu.ntnu.idi.idatt1005.hmh.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import edu.ntnu.idi.idatt1005.hmh.model.Organization;
import edu.ntnu.idi.idatt1005.hmh.service.OrganizationService;

import java.sql.SQLException;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * Controller for the organization list view.
 * Handles displaying and filtering organizations.
 * 
 * @author IDATT1005 Group 14
 */
public class OrganizationListController {

    @FXML
    private TableView<Organization> organizationTable;

    @FXML
    private TableColumn<Organization, String> nameColumn;

    @FXML
    private TableColumn<Organization, String> categoryColumn;

    @FXML
    private TableColumn<Organization, Boolean> verifiedColumn;

    @FXML
    private TextField searchField;

    @FXML
    private ComboBox<String> categoryFilter;

    @FXML
    private CheckBox verifiedOnlyCheckBox;

    @FXML
    private Button refreshButton;

    @FXML
    private Label statusLabel;

    private OrganizationService organizationService;
    private ObservableList<Organization> organizationList;

    /**
     * Initializes the controller.
     * Called automatically after FXML loading.
     */
    @FXML
    public void initialize() {
        organizationService = new OrganizationService();
        organizationList = FXCollections.observableArrayList();
        
        setupTableColumns();
        setupCategoryFilter();
        refreshOrganizations();
    }

    /**
     * Sets up table columns with cell value factories.
     */
    private void setupTableColumns() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        verifiedColumn.setCellValueFactory(new PropertyValueFactory<>("verified"));
        verifiedColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item ? "Yes" : "No");
            }
        });
    }

    /**
     * Populates the category filter with distinct organization categories.
     */
    private void setupCategoryFilter() {
        try {
            List<Organization> organizations = organizationService.getAllOrganizations();
            List<String> categories = organizations.stream()
                    .map(Organization::getCategory)
                    .filter(category -> category != null && !category.isBlank())
                    .distinct()
                    .sorted()
                    .collect(Collectors.toList());

            categoryFilter.getItems().setAll("All");
            categoryFilter.getItems().addAll(categories);
            categoryFilter.getSelectionModel().selectFirst();
        } catch (SQLException e) {
            statusLabel.setText("Error loading categories: " + e.getMessage());
        }
    }

    /**
     * Loads all organizations from the database.
     */
    private void loadOrganizations() {
        try {
            List<Organization> organizations = organizationService.getAllOrganizations();
            organizationList.setAll(organizations);
            organizationTable.setItems(organizationList);
            statusLabel.setText("Loaded " + organizations.size() + " organizations");
        } catch (SQLException e) {
            statusLabel.setText("Error loading organizations: " + e.getMessage());
        }
    }

    /**
     * Applies all active filters to the organization list.
     */
    private void refreshOrganizations() {
        try {
            List<Organization> organizations = organizationService.getAllOrganizations();
            String searchText = searchField.getText() == null ? "" : searchField.getText().trim().toLowerCase();
            String selectedCategory = categoryFilter.getValue();
            boolean verifiedOnly = verifiedOnlyCheckBox.isSelected();

            List<Organization> filtered = organizations.stream()
                    .filter(org -> !verifiedOnly || org.isVerified())
                    .filter(org -> selectedCategory == null || "All".equals(selectedCategory)
                            || (org.getCategory() != null && org.getCategory().equalsIgnoreCase(selectedCategory)))
                    .filter(org -> searchText.isEmpty()
                            || (org.getName() != null && org.getName().toLowerCase().contains(searchText))
                            || (org.getDescription() != null && org.getDescription().toLowerCase().contains(searchText)))
                    .sorted(Comparator.comparing(Organization::getName, String.CASE_INSENSITIVE_ORDER))
                    .toList();

            organizationList.setAll(filtered);
            organizationTable.setItems(organizationList);

            if (filtered.size() == organizations.size()) {
                statusLabel.setText("Loaded " + filtered.size() + " organizations");
            } else {
                statusLabel.setText("Showing " + filtered.size() + " organizations");
            }
        } catch (SQLException e) {
            statusLabel.setText("Error loading organizations: " + e.getMessage());
        }
    }

    /**
     * Handles the refresh button action.
     * Reloads organizations from the database.
     */
    @FXML
    public void handleRefresh() {
        searchField.clear();
        categoryFilter.getSelectionModel().selectFirst();
        verifiedOnlyCheckBox.setSelected(false);
        refreshOrganizations();
    }

    /**
     * Handles the search field input.
     * Filters organizations based on search text.
     */
    @FXML
    public void handleSearch() {
        refreshOrganizations();
    }

    /**
     * Handles the category filter selection.
     * Filters organizations by selected category.
     */
    @FXML
    public void handleCategoryFilter() {
        refreshOrganizations();
    }

    /**
     * Handles the verified only checkbox.
     * Shows only verified organizations when checked.
     */
    @FXML
    public void handleVerifiedFilter() {
        refreshOrganizations();
    }

    /**
     * Handles organization selection.
     * Shows details of the selected organization.
     */
    @FXML
    public void handleOrganizationSelection(MouseEvent event) {
        if (event.getButton() != MouseButton.PRIMARY || event.getClickCount() < 2) {
            return;
        }

        Organization selected = organizationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Organization Details");
        alert.setHeaderText(selected.getName());
        String description = selected.getDescription() == null ? "No description available" : selected.getDescription();
        alert.setContentText("Category: " + selected.getCategory() + "\n"
                + "Verified: " + (selected.isVerified() ? "Yes" : "No") + "\n"
                + "Registration number: " + selected.getRegistrationNumber() + "\n"
                + "Website: " + selected.getWebsiteUrl() + "\n\n"
                + description);
        alert.showAndWait();
    }
}
