package edu.ntnu.idi.idatt1005.hmh.controller;

import edu.ntnu.idi.idatt1005.hmh.util.AppSession;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import edu.ntnu.idi.idatt1005.hmh.model.User;

import java.io.IOException;

/**
 * Controller for the main application view.
 * Handles navigation between different views and main application functionality.
 * 
 * @author IDATT1005 Group 14
 */
public class MainController {

    @FXML
    private BorderPane mainBorderPane;

    @FXML
    private MenuBar menuBar;

    /**
     * Initializes the controller.
     * Called automatically after FXML loading.
     */
    @FXML
    public void initialize() {
        setupMenu();
        showHome();
    }

    /**
     * Sets up the menu bar with navigation options.
     */
    private void setupMenu() {
        // Menu is defined in FXML; this hook is kept for future dynamic setup.
    }

    /**
     * Loads the home dashboard.
     */
    @FXML
    public void showHome() {
        loadCenterView("/fxml/HomeView.fxml", true);
    }

    /**
     * Navigates to the user profile view.
     */
    @FXML
    public void showUserProfile() {
        loadCenterView("/fxml/UserProfileView.fxml", false);
    }

    /**
     * Navigates to the organization list view.
     */
    @FXML
    public void showOrganizationList() {
        loadCenterView("/fxml/OrganizationListView.fxml", false);
    }

    /**
     * Navigates to the donation view.
     */
    @FXML
    public void showDonationView() {
        loadCenterView("/fxml/DonationView.fxml", false);
    }

    /**
     * Exits the application.
     */
    @FXML
    public void exitApplication() {
        System.exit(0);
    }

    /**
     * Shows the about dialog.
     */
    @FXML
    public void showAbout() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("About Help Me Help");
        alert.setHeaderText("Help Me Help (HmH)");
        User currentUser = AppSession.getInstance().getCurrentUser();
        alert.setContentText("A JavaFX desktop application for managing donations to verified organizations.\nCurrent user: "
                + (currentUser != null ? currentUser.getName() : "Unknown"));
        alert.showAndWait();
    }

    private void loadCenterView(String resourcePath, boolean useCurrentController) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(resourcePath));
            if (useCurrentController) {
                loader.setController(this);
            }

            Parent view = loader.load();

            if (!useCurrentController) {
                Object controller = loader.getController();
                if (controller instanceof UserProfileController userProfileController) {
                    userProfileController.loadUser(AppSession.getInstance().getCurrentUser());
                } else if (controller instanceof DonationController donationController) {
                    donationController.setCurrentUserId(AppSession.getInstance().getCurrentUserId());
                }
            }

            mainBorderPane.setCenter(view);
        } catch (IOException e) {
            showError("Unable to load view", e.getMessage());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
