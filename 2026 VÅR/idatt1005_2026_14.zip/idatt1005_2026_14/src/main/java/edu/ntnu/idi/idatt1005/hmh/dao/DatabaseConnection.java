package edu.ntnu.idi.idatt1005.hmh.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * Singleton class for managing database connections.
 * Implements connection pooling and ensures single database connection instance.
 * 
 * @author IDATT1005 Group 14 
 */
public class DatabaseConnection {
    private static final String DATABASE_URL = "jdbc:sqlite:hmh_database.db";
    private static DatabaseConnection instance;
    private Connection connection;

    /**
     * Private constructor to prevent instantiation.
     * Initializes database connection and schema.
     */
    private DatabaseConnection() {
        try {
            connection = DriverManager.getConnection(DATABASE_URL);
            initializeDatabase();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to establish database connection", e);
        }
    }

    /**
     * Gets the singleton instance of DatabaseConnection.
     *
     * @return the DatabaseConnection instance
     */
    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    /**
     * Gets the database connection.
     *
     * @return the database connection
     * @throws SQLException if connection is closed or invalid
     */
    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(DATABASE_URL);
        }
        return connection;
    }

    /**
     * Initializes the database schema by executing the schema.sql file.
     */
    private void initializeDatabase() {
        try (InputStream inputStream = getClass().getClassLoader()
                .getResourceAsStream("database/schema.sql")) {
            
            if (inputStream == null) {
                System.err.println("schema.sql not found in resources. Database may not be initialized.");
                return;
            }

            Scanner scanner = new Scanner(inputStream).useDelimiter(";");
            Statement statement = connection.createStatement();

            while (scanner.hasNext()) {
                String sql = scanner.next().trim();
                if (!sql.isEmpty()) {
                    statement.execute(sql);
                }
            }
            
            scanner.close();
            statement.close();

            seedOrganizationsIfNeeded();
            
        } catch (SQLException | IOException e) {
            System.err.println("Error initializing database: " + e.getMessage());
        }
    }

    /**
     * Populates the organization table with starter data when the database is empty.
     */
    private void seedOrganizationsIfNeeded() throws SQLException, IOException {
        if (countRows("organizations") > 0) {
            return;
        }

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("database/organizations.csv")) {
            if (inputStream == null) {
                seedFallbackOrganizations();
                return;
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
                String line = reader.readLine();
                if (line == null) {
                    seedFallbackOrganizations();
                    return;
                }

                try (PreparedStatement statement = connection.prepareStatement(
                        "INSERT INTO organizations (name, registration_number, description, category, website_url, is_verified, ik_status) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                    while ((line = reader.readLine()) != null) {
                        if (line.trim().isEmpty()) {
                            continue;
                        }

                        String[] columns = line.split(",", -1);
                        if (columns.length < 7) {
                            continue;
                        }

                        statement.setString(1, columns[0]);
                        statement.setString(2, columns[1]);
                        statement.setString(3, columns[2]);
                        statement.setString(4, columns[3]);
                        statement.setString(5, columns[4]);
                        statement.setInt(6, Boolean.parseBoolean(columns[5]) ? 1 : 0);
                        statement.setString(7, columns[6]);
                        statement.executeUpdate();
                    }
                }
            }
        }
    }

    private int countRows(String tableName) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
            return resultSet.next() ? resultSet.getInt(1) : 0;
        }
    }

    private void seedFallbackOrganizations() throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO organizations (name, registration_number, description, category, website_url, is_verified, ik_status) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
            insertOrganization(statement, "Norwegian Red Cross", "971277882", "Humanitarian organization", "Health", "https://www.redcross.no", true, "APPROVED");
            insertOrganization(statement, "Save the Children Norway", "959468652", "Children's rights organization", "Children", "https://www.reddbarna.no", true, "APPROVED");
            insertOrganization(statement, "WWF Norway", "952419071", "Environmental conservation", "Environment", "https://www.wwf.no", true, "APPROVED");
        }
    }

    private void insertOrganization(PreparedStatement statement, String name, String registrationNumber,
                                    String description, String category, String websiteUrl,
                                    boolean verified, String ikStatus) throws SQLException {
        statement.setString(1, name);
        statement.setString(2, registrationNumber);
        statement.setString(3, description);
        statement.setString(4, category);
        statement.setString(5, websiteUrl);
        statement.setInt(6, verified ? 1 : 0);
        statement.setString(7, ikStatus);
        statement.executeUpdate();
    }

    /**
     * Closes the database connection.
     */
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        }
    }
}
