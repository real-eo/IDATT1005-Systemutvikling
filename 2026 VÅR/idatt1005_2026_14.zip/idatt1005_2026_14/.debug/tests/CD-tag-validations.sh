#!/bin/bash
# set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test counters
PASSED=0
FAILED=0

print_test_header() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_result() {
    local test_name="$1"
    local passing="$2"
    local actual="$3"
    local formating_spaces="$4"
    
    if [ "$passing" = "$actual" ]; then
        echo -e "${GREEN}  $formating_spaces$passing${NC}: $test_name"
        ((PASSED++))
    else
        echo -e "${RED}x $formating_spaces$actual${NC}: $test_name (passing: $passing, got: $actual)"
        ((FAILED++))
    fi
}

# ============================================
# Test 1: Version Format Validation
#  SPEED: #5
# ============================================
test_version_format() {
    local VERSION="$1"
    local PASS_STRING="valid"
    
    # Split into parts
    IFS='.' read -r part1 part2 part3 rest <<< "$VERSION"
    
    # Check we have exactly 3 parts
    if [ -z "$part1" ] || [ -z "$part2" ] || [ -z "$part3" ]; then
        ACTUAL="invalid-missing-parts"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "    "
        return
    fi
    
    # Check for extra parts
    if [ -n "$rest" ]; then
        ACTUAL="invalid-extra-parts"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "      "
        return
    fi
    
    # Check for extra dots (more than 3 parts)
    DOT_COUNT=$(echo "$VERSION" | tr -cd '.' | wc -c | tr -d ' ')
    if [ "$DOT_COUNT" -ne 2 ]; then
        ACTUAL="invalid-extra-dots"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "       "
        return
    fi
    
    # Validate each part matches: number or number-suffix or number-suffix-number
    # Suffix must be exactly: SNAPSHOT, alpha, beta, or rc (lowercase only)
    PART_PATTERN='^[0-9]+(-((SNAPSHOT|alpha|beta|rc)(-[0-9]+)?))?$'
    
    if [[ ! "$part1" =~ $PART_PATTERN ]]; then
        ACTUAL="invalid-format"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "           "
        return
    fi
    
    if [[ ! "$part2" =~ $PART_PATTERN ]]; then
        ACTUAL="invalid-format"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "           "
        return
    fi
    
    if [[ ! "$part3" =~ $PART_PATTERN ]]; then
        ACTUAL="invalid-format"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "           "
        return
    fi
    
    # Count total suffixes (max 1 allowed)
    SUFFIX_COUNT=0
    if [[ "$part1" =~ -(alpha|beta|rc) ]]; then SUFFIX_COUNT=$((SUFFIX_COUNT + 1)); fi
    if [[ "$part2" =~ -(alpha|beta|rc) ]]; then SUFFIX_COUNT=$((SUFFIX_COUNT + 1)); fi
    if [[ "$part3" =~ -(alpha|beta|rc) ]]; then SUFFIX_COUNT=$((SUFFIX_COUNT + 1)); fi
    
    if [ "$SUFFIX_COUNT" -gt 1 ]; then
        ACTUAL="invalid-multiple-suffixes"
        print_result "$VERSION" "$PASS_STRING" "$ACTUAL"
        return
    fi
    
    # If all checks passed
    ACTUAL="valid"
    print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "                    "
}

print_test_header "TEST 1: VERSION FORMAT VALIDATION"

# Valid versions
test_version_format "1.0.0"
test_version_format "1.0.0-alpha"
test_version_format "1.0.0-beta"
test_version_format "1.0.0-rc"
test_version_format "1.4.3-rc-2"
test_version_format "1.0.0-alpha-1"
test_version_format "2-beta-3.0.0"
test_version_format "1.0-rc-5.0"
test_version_format "10.20.30-alpha-99"
test_version_format "0.0.1-alpha"
test_version_format "0.1.0-SNAPSHOT"

# Invalid versions
test_version_format "1-alpha.0-beta.0"
test_version_format "1.0.0-dev"
test_version_format "1.0.0-rc-2-1"
test_version_format "1.0.0-alpha1"
test_version_format "1.0.0-ALPHA"
test_version_format "1.0"
test_version_format "1.0.0.1"
test_version_format "1.0.1."
test_version_format "v1.0.0"
                   
# ============================================
# Test 2: SNAPSHOT Detection
#  SPEED: #2
# ============================================
test_snapshot() {
    local VERSION="$1"
    local PASS_STRING="not-snapshot"
    local ACTUAL
    local SPACES=""
  
    if [[ "$VERSION" == *-SNAPSHOT* ]] || [[ "$VERSION" == *-snapshot* ]]; then
        ACTUAL="is-snapshot"
        SPACES=" "
    else
        ACTUAL="not-snapshot"
    fi

    print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "$SPACES"
}

print_test_header "TEST 2: SNAPSHOT DETECTION"

test_snapshot "1.0.0-SNAPSHOT"
test_snapshot "1.0.0-snapshot"     # lowercase should be included in snapshot detection
test_snapshot "1.0-SNAPSHOT.0"     # suffix can be in any part
test_snapshot "1-snapshot-0.0.0"   # suffix can have any subversion
test_snapshot "1.0.0-alpha"
test_snapshot "1.0.0"
test_snapshot "2.3.1-SNAPSHOT"

# ============================================
# Test 3: Pre-release Detection
#  SPEED: #3
# ============================================
test_prerelease() {
    local VERSION="$1"
    local PASS_STRING="pre-release"
    local ACTUAL
    local SPACES=""
    
    if [[ "$VERSION" =~ -(alpha|beta|rc) ]]; then
        ACTUAL="pre-release"
    else
        ACTUAL="stable"
        SPACES="     "
    fi
    
    print_result "$VERSION" "$PASS_STRING" "$ACTUAL" "$SPACES"
}

print_test_header "TEST 3: PRE-RELEASE DETECTION"

test_prerelease "1.0.0-alpha"
test_prerelease "1-alpha.0.0"
test_prerelease "1.0-beta.0"
test_prerelease "1.0.0-rc-2"
test_prerelease "1.0.0"
test_prerelease "2-rc-5.3.1"
test_prerelease "10.20.30"

# ============================================
# Test 4: Version Comparison
#  SPEED: #4
# ============================================
compare_versions() {
    local ver1="$1"
    local ver2="$2"
    
    # Strip any pre-release suffix (e.g., -alpha, -beta-1, -rc-2)
    local base1=$(echo "$ver1" | sed -E 's/-(alpha|beta|rc)(-[0-9]+)?//g')
    local base2=$(echo "$ver2" | sed -E 's/-(alpha|beta|rc)(-[0-9]+)?//g')

    # Split into major.minor.patch
    IFS='.' read -r major1 minor1 patch1 <<< "$base1"
    IFS='.' read -r major2 minor2 patch2 <<< "$base2"
    
    # Compare major
    if [ "$major1" -gt "$major2" ]; then return 0; fi
    if [ "$major1" -lt "$major2" ]; then return 1; fi
    
    # Compare minor
    if [ "$minor1" -gt "$minor2" ]; then return 0; fi
    if [ "$minor1" -lt "$minor2" ]; then return 1; fi
    
    # Compare patch
    if [ "$patch1" -gt "$patch2" ]; then return 0; fi
    if [ "$patch1" -lt "$patch2" ]; then return 1; fi
    
    # Base versions are equal, now compare suffixes
    # Extract suffix and number from ver1
    local suffix1=""
    local num1=0
    if [[ "$ver1" =~ -((alpha|beta|rc)(-([0-9]+))?) ]]; then
        suffix1="${BASH_REMATCH[2]}"  # alpha, beta, or rc
        if [ -n "${BASH_REMATCH[4]}" ]; then
            num1="${BASH_REMATCH[4]}"  # the number after -suffix-
        fi
    fi
    
    # Extract suffix and number from ver2
    local suffix2=""
    local num2=0
    if [[ "$ver2" =~ -((alpha|beta|rc)(-([0-9]+))?) ]]; then
        suffix2="${BASH_REMATCH[2]}"
        if [ -n "${BASH_REMATCH[4]}" ]; then
            num2="${BASH_REMATCH[4]}"
        fi
    fi
    
    # Stable version (no suffix) > pre-release version (with suffix)
    if [ -z "$suffix1" ] && [ -n "$suffix2" ]; then
        # ver1 is stable, ver2 is pre-release → ver1 > ver2
        return 0
    fi
    
    if [ -n "$suffix1" ] && [ -z "$suffix2" ]; then
        # ver1 is pre-release, ver2 is stable → ver1 < ver2
        return 1
    fi
    
    # Both are stable (no suffixes)
    if [ -z "$suffix1" ] && [ -z "$suffix2" ]; then
        # Same version
        return 1
    fi
    
    # Both have suffixes - compare them
    # Priority: rc (3) > beta (2) > alpha (1)
    local priority1=0
    local priority2=0
    
    case "$suffix1" in
        alpha) priority1=1 ;;
        beta)  priority1=2 ;;
        rc)    priority1=3 ;;
    esac
    
    case "$suffix2" in
        alpha) priority2=1 ;;
        beta)  priority2=2 ;;
        rc)    priority2=3 ;;
    esac
    
    # Compare suffix priority first
    if [ "$priority1" -gt "$priority2" ]; then
        # ver1 has higher priority suffix (e.g., rc vs beta)
        return 0
    fi
    
    if [ "$priority1" -lt "$priority2" ]; then
        # ver1 has lower priority suffix
        return 1
    fi
    
    # Same suffix type, compare numbers
    if [ "$num1" -gt "$num2" ]; then
        # ver1 has higher number (e.g., rc-2 vs rc-1)
        return 0
    fi
    
    if [ "$num1" -lt "$num2" ]; then
        # ver1 has lower number
        return 1
    fi
    
    # Exact same version
    return 1
}

test_version_comparison() {
    local NEW="$1"
    local LATEST="$2"
    local PASS_STRING="greater"
    local ACTUAL
    local SPACES=""
    
    if compare_versions "$NEW" "$LATEST"; then
        ACTUAL="greater"
        SPACES="    "
    else
        ACTUAL="not-greater"
    fi
    
    print_result "$NEW > $LATEST" "$PASS_STRING" "$ACTUAL" "$SPACES"
}

print_test_header "TEST 4: VERSION COMPARISON"

# Basic version bumps
test_version_comparison "1.0.1" "1.0.0"
test_version_comparison "1.1.0" "1.0.0"
test_version_comparison "2.0.0" "1.0.0"
test_version_comparison "1.0.0" "1.0.0"
test_version_comparison "0.9.0" "1.0.0"

# Numeric comparison (not lexicographic)
test_version_comparison "10.0.0" "2.0.0"
test_version_comparison "1.10.0" "1.9.0"
test_version_comparison "1.0.10" "1.0.9"

# Pre-release vs stable
test_version_comparison "1.0.0-alpha" "1.0.0-beta"  # Different pre-releases
test_version_comparison "1.0.0" "1.0.0-alpha"       # Stable > pre-release
test_version_comparison "1.0.0-beta" "1.0.0"        # Pre-release < stable
test_version_comparison "1.0.0-rc-1" "1.0.0-rc-2"   # Different RC versions

# Stable > any pre-release
test_version_comparison "1.0.0" "1.0.0-rc-99"
test_version_comparison "1.0.0" "1.0.0-beta"
test_version_comparison "1.0.0" "1.0.0-alpha"
test_version_comparison "1.1.0" "1.0.0-rc-99"
test_version_comparison "1.1.1" "1.1.0-beta"
test_version_comparison "2.1.1" "2.1.0-alpha"

# Priority: rc > beta > alpha
test_version_comparison "1.0.0-rc" "1.0.0-beta"
test_version_comparison "1.0.0-rc" "1.0.0-alpha"
test_version_comparison "1.0.0-beta" "1.0.0-alpha"
test_version_comparison "1.0.0-alpha" "1.0.0-beta"
test_version_comparison "1.0.0-beta" "1.0.0-rc"
test_version_comparison "1.0.0-alpha" "1.0.0-rc"

# Same suffix, higher number wins
test_version_comparison "1.0.0-alpha-2" "1.0.0-alpha-1"
test_version_comparison "1.0.0-beta-10" "1.0.0-beta-5"
test_version_comparison "1.0.0-rc-3" "1.0.0-rc-2"
test_version_comparison "1.0.0-alpha-1" "1.0.0-alpha-2"


# Higher priority suffix beats lower suffix with higher number
test_version_comparison "1.0.0-rc-1" "1.0.0-beta-99"
test_version_comparison "1.0.0-beta-1" "1.0.0-alpha-99"
test_version_comparison "1.0.0-rc" "1.0.0-beta-99"



# Base version takes priority"
test_version_comparison "1.0.1-alpha" "1.0.0-rc"
test_version_comparison "1.1.0-alpha" "1.0.0"
test_version_comparison "2.0.0-alpha" "1.9.9"

# Complex cases
test_version_comparison "1.8.9" "1.9-alpha.0" 
test_version_comparison "1.9.1" "1.9-beta.0" 
test_version_comparison "1.7.0" "1.7-rc.1"
test_version_comparison "1.7-rc-1.0" "1.7-rc.1" 
test_version_comparison "1.0.0-alpha" "0.9.0"       # Pre-release of higher base
test_version_comparison "2.0.0-alpha" "1.9.9"       # Major bump with pre-release




# ============================================
# Test 5: Tag/POM Matching
#  SPEED: #1
# ============================================
test_tag_match() {
    local TAG_VERSION="$1"
    local POM_VERSION="$2"
    local PASS_STRING="match"
    local ACTUAL
    local SPACES=""

    if [ "$TAG_VERSION" = "$POM_VERSION" ]; then
        ACTUAL="match"
        SPACES="   "
    else
        ACTUAL="mismatch"
    fi
    
    print_result "Tag=$TAG_VERSION, POM=$POM_VERSION" "$PASS_STRING" "$ACTUAL" "$SPACES"
}

print_test_header "TEST 5: TAG/POM VERSION MATCHING"

test_tag_match "1.0.0" "1.0.0"
test_tag_match "1.0.0-alpha" "1.0.0-alpha"
test_tag_match "1.0.0" "2.0.0"
test_tag_match "1.0.0-rc-2" "1.0.0-rc-2" 
test_tag_match "1.0.0" "1.0.0-alpha"

# ============================================
# Summary
# ============================================
print_test_header "TEST SUMMARY"
TOTAL=$((PASSED + FAILED))
echo -e "Total tests: $TOTAL"
echo -e "${GREEN}Passed: $PASSED${NC}"
echo -e "${RED}Failed: $FAILED${NC}"

if [ $FAILED -eq 0 ]; then
    echo -e "\n${GREEN}   All tests passed!${NC}"
    exit 0
else
    echo -e "\n${RED} x Some tests failed${NC}"
    exit 1
fi